with open('C:/Users/h126313/Desktop/NG/Dump_data.txt') as f:
    with open('C:/Users/h126313/Desktop/NG/Test_data1.txt', 'w') as wf:
        for line in f:
            if "<group elementhashname=\"" in line:
                wf.write(line)