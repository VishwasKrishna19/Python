import InitialSupport

from InitialSupport import *
TestName = "E2C_AGMA_0602"
Startsum(TestName)
#============================================================================================================
#                      CONTROL ABSTRACTION LAYER FUNCTION SOFTWARE TEST PLAN/PROCEDURE
Output ("=====================================================================================================")
Output (" TestName       :  E2C_AGMA_0602                                                                     ")
Output ("=====================================================================================================")
Output ("                                   MODIFICATION HISTORY                                              ")
Output ("=====================================================================================================")
Output (" Version   Date       Author              Change Description                            CH_DOC            ")
Output (" ------- ---------  --------------   ----------------------------------               ---------           ")
#Output "    01   21-Jun-15   Harsha M R     Load 1.0: Initial Development             EDS_CALF_EJETE2_VR_251 "   
#Output "    02   28-Sep-15   Harsha M R     Load 1.0: Rework done as per comment to    EDS_CALF_EJETE2_VR_251"
#Output "                                    update TEST ENVIRONMENT SPECIFICATION section                    "
#Output "                                    and Test Procedure for TestCase a10.                             "
#Output "   03   27-Nov-15   Ashutosh   Load 2.0: Updated test cases for SDD_CALF_7639       EDS_CALF_EJETE2_SCR_160"
#Output "                               Added condition for ggf_PrimaryNavSource =#GLS1#     EDS_CALF_EJETE2_VR_551"
#Output "                               and #GLS2#.                                                           "
#Output "    04   30-Nov-15   Ashutosh   Load 2.0: Removed Redundant TestCase b12, b15 & b18  EDS_CALF_EJETE2_SCR_160 " 
#Output "                                Updated Input Conditions of TestCase b11             EDS_CALF_EJETE2_VR_551"
#Output "    05   15-Apr-17   Avinash N V  Load 3.5: Updated test cases b as                  EDS_CALF_EJETE2_SCR_338/EDS_CALF_EJETE2_SCR_393 " 
#Output "                                        per SCR changes                              EDS_CALF_EJETE2_VR_1051"
#Output "    06   20-Apr-17   Avinash N V  Updated logic for g__thisInstance_1                  EDS_CALF_EJETE2_SCR_338/ " 
#Output "                                  and fixed review comments                              EDS_CALF_EJETE2_VR_1051"
#Output "    07   28-Apr-17   Avinash N V  Updated OS comment, included test                  EDS_CALF_EJETE2_SCR_338/ " 
#Output "                                  test case for SDD_CALF_7639.                        EDS_CALF_EJETE2_VR_1051"
Output ("    08   28-Jun-17   Harsha M R   Load 4.0: Test only Update to add test case c        EDS_CALF_EJETE2_VR_1266")
Output ("=====================================================================================================")
#============================================================================================================
#                                 TEST ENVIRONMENT SPECIFICATION
#============================================================================================================
# Environment               : MAU Mini-bench with a AGM3 card || EASE Bench
# ESCAPE Configuration DB   : EJETE2_Configuration_Data.mdb
# ESCAPE Configuration Name : AGMCAL_1 V&V MiniBench, AGMCAL_2 V&V MiniBench, AGMCAL_3 V&V MiniBench, AGMCAL_4 V&V MiniBench 
#                             || EJETE2_EASE
# Hyperstart Name           : agm1.bin || NA for EASE
# Additional Information    : Dtmon.exe to be loaded onto AGM3 card and Agmcal_Vars.txt need to be pointed in TIU Server
#
# The steps required to set-up a Mini bench/EASE Bench are described in Guidelines_For_E2_Bench_Setup document
#
#============================================================================================================
#                                     GENERAL COMMENTS
#------------------------------------------------------------------------------------------------------------
# This test needs be executed on all 4 instances of Agmcal
# To design the generic test cases for all the instances below formula is used to identify the input GGF source
# Call VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
# For example :
#   "(((Instance-1) + 0) Mod 4)" is used To Set GGF1 source.
#   For printing in summary "(((Instance-1) + 0) Mod 4) + 1" is used for GGF1 source.
#============================================================================================================
#                                GENERAL SET-UP COMMANDS
#------------------------------------------------------------------------------------------------------------
# Following files are to be included in the project and should be in the following order:
#
#    1. QualifiedSupport.tsf               
#    2. ComConstantsAndFunctions.tsf       
#    3. E2C_AGMCAL_ASCB_Mapping.tsf  
#    4. E2C_AGMCAL_DatmonMapping.tsf 
#    5. DebounceTestingConstantsAndFunctions.tsf 
#    6. MauCard.tsf                
#    7. E2C_AGMA_0602.tsf           
#
#============================================================================================================
#                                       DEFINE VARIABLES
#------------------------------------------------------------------------------------------------------------
global oCard
Set oCard = New MauCard
oCard.setCardName("Agm1")
oCard.setCardModeDelay(25.0)

global Instance, status, Temp
global Input_condition, Expected_Result, ObjectID, CA_Justification, Category

global ggf_PfdData(4)
global ggf_PrimaryNavSourceStatus(4)
global ggf_PrimaryNavSource(4)
global agmcal_Nav1ChangeBit(4)
global agmcal_Nav2ChangeBit(4)
global dcSelectedPrimaryNavSource
global g__thisInstance_1
#============================================================================================================
#                                      INITIAL CONDITIONS
#------------------------------------------------------------------------------------------------------------
ObjectID_Level_Test() # Object ID level testing
Output ("")

#Read the internal data: g__thisInstance to get the agmcal instance
status = VerifyReadReturnInternal(g__thisInstance, Instance)

ggf_PfdData(0) = ggf1_PfdData_Good_1
ggf_PfdData(1) = ggf2_PfdData_Good_1
ggf_PfdData(2) = ggf3_PfdData_Good_1
ggf_PfdData(3) = ggf4_PfdData_Good_1

ggf_PrimaryNavSourceStatus(0) = ggf1_PrimaryNavSourceStatus_Valid_1
ggf_PrimaryNavSourceStatus(1) = ggf2_PrimaryNavSourceStatus_Valid_1
ggf_PrimaryNavSourceStatus(2) = ggf3_PrimaryNavSourceStatus_Valid_1
ggf_PrimaryNavSourceStatus(3) = ggf4_PrimaryNavSourceStatus_Valid_1

ggf_PrimaryNavSource(0) = ggf1_PrimaryNavSource_1
ggf_PrimaryNavSource(1) = ggf2_PrimaryNavSource_1
ggf_PrimaryNavSource(2) = ggf3_PrimaryNavSource_1
ggf_PrimaryNavSource(3) = ggf4_PrimaryNavSource_1

agmcal_Nav1ChangeBit(0) = agmcal_Nav1ChangeBit_1
agmcal_Nav1ChangeBit(1) = agmcal_Nav1ChangeBit_2
agmcal_Nav1ChangeBit(2) = agmcal_Nav1ChangeBit_3
agmcal_Nav1ChangeBit(3) = agmcal_Nav1ChangeBit_4

agmcal_Nav2ChangeBit(0) = agmcal_Nav2ChangeBit_1
agmcal_Nav2ChangeBit(1) = agmcal_Nav2ChangeBit_2
agmcal_Nav2ChangeBit(2) = agmcal_Nav2ChangeBit_3
agmcal_Nav2ChangeBit(3) = agmcal_Nav2ChangeBit_4

VerifyReadReturnValue(g__thisInstance, g__thisInstance_1)

If ((g__thisInstance_1 = 1) Or (g__thisInstance_1 = 2)):
dcSelectedPrimaryNavSource = dcSelectedPrimaryNavSource_1
#End if
If ((g__thisInstance_1 = 3) Or (g__thisInstance_1 = 4)):
dcSelectedPrimaryNavSource = dcSelectedPrimaryNavSource_2_1
#End if
#============================================================================================================
#                                       TEST CASES AND PROCEDURES
#------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_7638"):

#------------------------------------------------------------------------------------------------------------
# TestCase         : a1
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(VOR1)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a1::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 4, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 4, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(VOR1)")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a2
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = FMS
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(FMS)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a2::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 12, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = FMS")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 12, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(FMS)")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a3
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(VOR2)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a3::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 5, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR2")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 5, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(VOR2)")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a4
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Invalid
#                    ggf<x>_PrimaryNavSource             = VOR2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = FMS
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a4::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 5, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR2")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 0, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Invalid") 
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 12, 0, "PreviousPrimaryNavSource = FMS")
 
 
#bring back to PreviousPrimaryNavSource = VOR2
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
Delay (1.0)
oCard.reinit()  #Process Initiation

#------------------------------------------------------------------------------------------------------------
# TestCase         : a5
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Invalid and Stale
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = FMS
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a5::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 5, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR2")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 0, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Invalid and Stale")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 12, 0, "PreviousPrimaryNavSource = FMS")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a6
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 2 for Agmcal Instance 1, 3 for Agmcal Instance 2, 4 for Agmcal Instance 3, 1 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = FMS
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a6::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PfdData(((Instance-1) + 1) Mod 4), 3, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 1) Mod 4), 1, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid")
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 1) Mod 4), 4, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 12, 0, "PreviousPrimaryNavSource = FMS")
 
#Disable ggf2
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 1) Mod 4), 0, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PrimaryNavSourceStatus = Invalid")
VerifyWrite(ggf_PfdData(((Instance-1) + 1) Mod 4), 0, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PfdData = Invalid and Stale")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a7
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 3 for Agmcal Instance 1, 4 for Agmcal Instance 2, 1 for Agmcal Instance 3, 2 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = FMS
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a7::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PfdData(((Instance-1) + 2) Mod 4), 3, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 2) Mod 4), 1, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid")
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 2) Mod 4), 4, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 12, 0, "PreviousPrimaryNavSource = FMS")
 
#Disable ggf3
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 2) Mod 4), 0, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PrimaryNavSourceStatus = Invalid")
VerifyWrite(ggf_PfdData(((Instance-1) + 2) Mod 4), 0, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PfdData = Invalid and Stale")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a8
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 4 for Agmcal Instance 1, 1 for Agmcal Instance 2, 2 for Agmcal Instance 3, 3 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = FMS
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a8::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PfdData(((Instance-1) + 3) Mod 4), 3, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 3) Mod 4), 1, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid")
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 3) Mod 4), 4, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 12, 0, "PreviousPrimaryNavSource = FMS")
 
#Disable ggf4
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 3) Mod 4), 0, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PrimaryNavSourceStatus = Invalid")
VerifyWrite(ggf_PfdData(((Instance-1) + 3) Mod 4), 0, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PfdData = Invalid and Stale")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a9
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR3
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(VOR3)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a9::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 6, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR3")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 6, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(VOR3)")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a10
# Input Conditions : Set           
#                    process initiation (FALSE)
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Invalid
#                    ggf<x>_PrimaryNavSource             = VOR2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = Retains Previous Value
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_2::TC a10::SDD_CALF_7638]  -  Test By Inspection")
Output ("")

Input_condition  = "process initiation (FALSE)"\
                   "thisInstance = "&Instance\
                   "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData.Good = Fresh And Valid"\				  
                   "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus.Valid = Valid"\
                   "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR3"				  
Expected_Result  = "PreviousPrimaryNavSource = Retains Previous Value"
ObjectID         = "SDD_CALF_7638"
CA_Justification = "PreviousPrimaryNavSource is overridden by the logic present in SDD_CALF_7639"\
                   " so this test case is tested by inspection"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#------------------------------------------------------------------------------------------------------------
# TestCase         : a11
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance                        = Instance
#                    ggf<x>_PfdData.Good                 = Invalid and Stale
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Invalid
#                    ggf<x>_PrimaryNavSource             = VOR2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = FMS
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a11::SDD_CALF_7638]  -  Custom Test")
Output ("")

VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 5, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR2")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 0 , "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Invalid") 
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 0, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Invalid and Stale")
oCard.reinit()  #Process Initiation
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 12, 0, "PreviousPrimaryNavSource = FMS")
 
If (Instance = 1): 
#------------------------------------------------------------------------------------------------------------
# TestCase         : a12
# Input Conditions : Set           
#                    After a process initiation
#                    thisInstance <> 1 or 2 or 3 or 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource          = FMS
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_2::TC a12::SDD_CALF_7638]  -  Test By Inspection")
Output ("")

Input_condition  = "After a process initiation and If thisInstance <> 1 or 2 or 3 or 4"
Expected_Result  = "PreviousPrimaryNavSource = FMS"
ObjectID         = "SDD_CALF_7638"
CA_Justification = "There are only 4 instances of Agmcal available and thisInstance of Agmcal cannot be set to the value other than 1 or 2 or 3 or 4."\
                   " so this test case is tested by inspection"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If #Instance

#End If#CompareObjectID



If (CompareObjectID("SDD_CALF_7639") Or CompareObjectID("DISPLAYS_SW_HLR_12355308") Or CompareObjectID("DISPLAYS_SW_HLR_12426013")):

#------------------------------------------------------------------------------------------------------------
# TestCase         : b1
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = VOR3
#                    PreviousdcSelectedPrimaryNavSource  = VOR3
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    dcSelectedPrimaryNavSource          = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(VOR1)
#                    PreviousdcSelectedPrimaryNavSource  = dcSelectedPrimaryNavSource
#                    agmcal_Nav1ChangeBit                = #change#(1) for 1.5 sec
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b1::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b1::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b1::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

#Set PreviousPrimaryNavSource          = VOR3, as per SDD_CALF_7638
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 6, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR3")
VerifyWrite(dcSelectedPrimaryNavSource, 6, "dcSelectedPrimaryNavSource = 6")
oCard.reinit()  #Process Initiation

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 6, 0, "PreviousPrimaryNavSource = VOR3")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 6, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource = VOR3")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetPulseStart(agmcal_Nav1ChangeBit(Instance-1), 0, 1, 0)
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 4, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
VerifyWrite(dcSelectedPrimaryNavSource, 4, "dcSelectedPrimaryNavSource = 4")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 4, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(VOR1)")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 4, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource = VOR1")
#Verify agmcal_Nav1ChangeBit# = #change# for 1.5 sec
ValidatePulseEnd(1.5, "agmcal_Nav1ChangeBit")
#------------------------------------------------------------------------------------------------------------
# TestCase         : b2
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = VOR1
#                    PreviousdcSelectedPrimaryNavSource  = VOR1
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = LOC1
#                    dcSelectedPrimaryNavSource          = VOR3
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(LOC1)
#                    PreviousdcSelectedPrimaryNavSource  = dcSelectedPrimaryNavSource
#                    agmcal_Nav1ChangeBit                = #change#(1) for 1.5 sec
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b2::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b2::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b2::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 4, 0, "PreviousPrimaryNavSource = VOR1")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetPulseStart(agmcal_Nav1ChangeBit(Instance-1), 0, 1, 0)
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 7, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = LOC1")
VerifyWrite(dcSelectedPrimaryNavSource, 7, "dcSelectedPrimaryNavSource = 6")

Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 7, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(LOC1)")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 7, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource = LOC1")
#Verify agmcal_Nav1ChangeBit# = #change# for 1.5 sec
ValidatePulseEnd(1.5, "agmcal_Nav1ChangeBit")

#------------------------------------------------------------------------------------------------------------
# TestCase         : b3
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = LOC1
#                    PreviousdcSelectedPrimaryNavSource  = LOC1
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = GLS1
#                    dcSelectedPrimaryNavSource          = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(GLS1)
#                    PreviousdcSelectedPrimaryNavSource  = dcSelectedPrimaryNavSource
#                    agmcal_Nav1ChangeBit                = #change#(1) for 1.5 sec
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b3::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b3::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b3::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 7, 0, "PreviousPrimaryNavSource = LOC1")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetPulseStart(agmcal_Nav1ChangeBit(Instance-1), 0, 1, 0)
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 13, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = GLS1")
VerifyWrite(dcSelectedPrimaryNavSource, 13, "dcSelectedPrimaryNavSource = GLS1")

Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 13, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(GLS1)")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 13, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource = GLS1")
#Verify agmcal_Nav1ChangeBit# = #change# for 1.5 sec
ValidatePulseEnd(1.5, "agmcal_Nav1ChangeBit") 

#------------------------------------------------------------------------------------------------------------
# TestCase         : b3a
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS1
#                    PreviousdcSelectedPrimaryNavSource  = GLS1
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = GLS1
#                    dcSelectedPrimaryNavSource          = GLS1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(GLS1)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b3a::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b3a::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b3a::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 13, 0, "PreviousPrimaryNavSource = GLS1")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 13, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = GLS1")
VerifyWrite(dcSelectedPrimaryNavSource, 13, "dcSelectedPrimaryNavSource = GLS1")

Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 13, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(GLS1)")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 13, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource = GLS1")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit")) 

#------------------------------------------------------------------------------------------------------------
# TestCase         : b4
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS1
#                    PreviousdcSelectedPrimaryNavSource  = GLS1
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = LOC2
#                    dcSelectedPrimaryNavSource          = LOC2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(LOC2)
#                    PreviousdcSelectedPrimaryNavSource  = dcSelectedPrimaryNavSource
#                    agmcal_Nav2ChangeBit                = #change#(1) for 1.5 sec
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b4::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b4::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b4::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 13, 0, "PreviousPrimaryNavSource = GLS1")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetPulseStart(agmcal_Nav2ChangeBit(Instance-1), 0, 1, 0)
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 8, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = LOC2")
VerifyWrite(dcSelectedPrimaryNavSource, 8, "dcSelectedPrimaryNavSource = LOC2")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 8, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(LOC2)")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 8, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource = LOC2")
#Verify agmcal_Nav2ChangeBit# = #change# for 1.5 sec
ValidatePulseEnd(1.5, "agmcal_Nav2ChangeBit")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : b5
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = LOC2
#                    PreviousdcSelectedPrimaryNavSource  = LOC2
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR2
#                    dcSelectedPrimaryNavSource          = VOR2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(VOR2)
#                    PreviousdcSelectedPrimaryNavSource  = dcSelectedPrimaryNavSource
#                    agmcal_Nav2ChangeBit                = #change#(1) for 1.5 sec
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b5::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b5::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b5::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 8, 0, "PreviousPrimaryNavSource = LOC2")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 

SetPulseStart(agmcal_Nav2ChangeBit(Instance-1), 0, 1, 0)
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 5, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR2")
VerifyWrite(dcSelectedPrimaryNavSource, 5, "dcSelectedPrimaryNavSource = VOR2")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 5, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(VOR2)")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 5, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource = VOR2")
#Verify agmcal_Nav2ChangeBit# = #change# for 1.5 sec
ValidatePulseEnd(1.5, "agmcal_Nav2ChangeBit")
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : b6
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = VOR2
#                    PreviousdcSelectedPrimaryNavSource  = VOR2
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = GLS2
#                    dcSelectedPrimaryNavSource          = GLS2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(GLS2)
#                    PreviousdcSelectedPrimaryNavSource  = dcSelectedPrimaryNavSource
#                    agmcal_Nav2ChangeBit                = #change#(1) for 1.5 sec
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b6::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b6::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b6::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 5, 0, "PreviousPrimaryNavSource = VOR2")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 

SetPulseStart(agmcal_Nav2ChangeBit(Instance-1), 0, 1, 0)
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 14, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = GLS2")
VerifyWrite(dcSelectedPrimaryNavSource, 14, "dcSelectedPrimaryNavSource = GLS2")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(GLS2)")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav2ChangeBit# = #change# for 1.5 sec
ValidatePulseEnd(1.5, "agmcal_Nav2ChangeBit")

#------------------------------------------------------------------------------------------------------------
# TestCase         : b6a
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = GLS2
#                    dcSelectedPrimaryNavSource          = GLS2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(GLS2)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b6a::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b6a::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b6a::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 

SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 14, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = GLS2")
VerifyWrite(dcSelectedPrimaryNavSource, 14, "dcSelectedPrimaryNavSource = VOR2")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(GLS2)")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit")) 

#------------------------------------------------------------------------------------------------------------
# TestCase         : b7
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh And Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Invalid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    dcSelectedPrimaryNavSource          = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2 (Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b7::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b7::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b7::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh And Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 0, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Invalid") 
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 4, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
VerifyWrite(dcSelectedPrimaryNavSource, 4, "dcSelectedPrimaryNavSource = VOR1")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit")) 

#------------------------------------------------------------------------------------------------------------
# TestCase         : b8
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Invalid and Stale
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = LOC2
#                    dcSelectedPrimaryNavSource          = LOC2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2 (Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b8::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b8::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b8::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 0, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Invalid and Stale")
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 8, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = LOC2")
VerifyWrite(dcSelectedPrimaryNavSource, 8, "dcSelectedPrimaryNavSource = LOC2")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit")) 
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : b9
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Invalid and Stale
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Invalid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    dcSelectedPrimaryNavSource          = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2 (Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b9::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b9::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b9::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 0, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Invalid") 
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 0, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Invalid and Stale")
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 4, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
VerifyWrite(dcSelectedPrimaryNavSource, 4, "dcSelectedPrimaryNavSource = VOR1")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit"))
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : b10
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh and Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    dcSelectedPrimaryNavSource          = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 2 for Agmcal Instance 1, 3 for Agmcal Instance 2, 4 for Agmcal Instance 3, 1 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2 (Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b10::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b10::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b10::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PfdData(((Instance-1) + 1) Mod 4), 3, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PfdData = Fresh and Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 1) Mod 4), 1, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 1) Mod 4), 4, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
VerifyWrite(dcSelectedPrimaryNavSource, 4, "dcSelectedPrimaryNavSource = VOR1")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit"))

#------------------------------------------------------------------------------------------------------------
# TestCase         : b11
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh and Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = LOC2
#                    dcSelectedPrimaryNavSource          = LOC2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 2 for Agmcal Instance 1, 3 for Agmcal Instance 2, 4 for Agmcal Instance 3, 1 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2 (Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b11::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b11::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b11::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PfdData(((Instance-1) + 1) Mod 4), 3, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PfdData = Fresh and Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 1) Mod 4), 1, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 1) Mod 4), 8, "ggf"&((((Instance-1) + 1) Mod 4) + 1)&"_PrimaryNavSource = LOC2")
VerifyWrite(dcSelectedPrimaryNavSource, 8, "dcSelectedPrimaryNavSource = LOC2")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit"))


#------------------------------------------------------------------------------------------------------------
# TestCase         : b12
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh and Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    dcSelectedPrimaryNavSource          = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 3 for Agmcal Instance 1, 4 for Agmcal Instance 2, 1 for Agmcal Instance 3, 2 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2 (Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b12::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b12::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b12::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PfdData(((Instance-1) + 2) Mod 4), 3, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PfdData = Fresh and Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 2) Mod 4), 1, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 2) Mod 4), 4, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
VerifyWrite(dcSelectedPrimaryNavSource, 4, "dcSelectedPrimaryNavSource = VOR1")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit"))
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : b13
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh and Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = LOC2
#                    dcSelectedPrimaryNavSource          = LOC2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 3 for Agmcal Instance 1, 4 for Agmcal Instance 2, 1 for Agmcal Instance 3, 2 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2(Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b13::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b13::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b13::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PfdData(((Instance-1) + 2) Mod 4), 3, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PfdData = Fresh and Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 2) Mod 4), 1, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 2) Mod 4), 8, "ggf"&((((Instance-1) + 2) Mod 4) + 1)&"_PrimaryNavSource = LOC2")
VerifyWrite(dcSelectedPrimaryNavSource, 8, "dcSelectedPrimaryNavSource = LOC2")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit"))

#------------------------------------------------------------------------------------------------------------
# TestCase         : b14
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh and Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR1
#                    dcSelectedPrimaryNavSource          = VOR1
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 4 for Agmcal Instance 1, 1 for Agmcal Instance 2, 2 for Agmcal Instance 3, 3 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2(Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b14::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b14::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b14::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PfdData(((Instance-1) + 3) Mod 4), 3, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PfdData = Fresh and Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 3) Mod 4), 1, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 3) Mod 4), 4, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PrimaryNavSource = VOR1")
VerifyWrite(dcSelectedPrimaryNavSource, 4, "dcSelectedPrimaryNavSource = VOR1")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit"))
 
#------------------------------------------------------------------------------------------------------------
# TestCase         : b15
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    PreviousdcSelectedPrimaryNavSource  = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh and Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = LOC2
#                    dcSelectedPrimaryNavSource          = VOR2
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 4 for Agmcal Instance 1, 1 for Agmcal Instance 2, 2 for Agmcal Instance 3, 3 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = GLS2(Previous value)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b15::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b15::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b15::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PfdData(((Instance-1) + 3) Mod 4), 3, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PfdData = Fresh and Valid")
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 3) Mod 4), 1, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
 
SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 3) Mod 4), 8, "ggf"&((((Instance-1) + 3) Mod 4) + 1)&"_PrimaryNavSource = VOR2")
VerifyWrite(dcSelectedPrimaryNavSource, 8, "dcSelectedPrimaryNavSource = VOR2")
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyReadChkValue(DuRtNav_m_PreviousdcSelectedPrimaryNavSource, 14, 0, "DuRtNav_m_PreviousdcSelectedPrimaryNavSource =GLS2")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit"))


#------------------------------------------------------------------------------------------------------------
# TestCase         : b16
# Input Conditions : Set           
#                    thisInstance                        = Instance
#                    PreviousPrimaryNavSource            = GLS2
#                    ggf<x>_PfdData.Good                 = Fresh and Valid
#                    ggf<x>_PrimaryNavSourceStatus.Valid = Valid
#                    ggf<x>_PrimaryNavSource             = VOR3
#                    Instance is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#                    x is 1 for Agmcal Instance 1, 2 for Agmcal Instance 2, 3 for Agmcal Instance 3, 4 for Agmcal Instance 4
#
# Expected Results : Verify
#                    PreviousPrimaryNavSource            = ggf<x>_PrimaryNavSource(VOR3)
#                    agmcal_Nav1ChangeBit                = #Nochange#(0) (Previous state)
#                    agmcal_Nav2ChangeBit                = #Nochange#(0) (Previous state)
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC b16::SDD_CALF_7639]  -  Custom Test")
Output ("[TP_1::TC b16::DISPLAYS_SW_HLR_12355308]  -  Custom Test")
Output ("[TP_1::TC b16::DISPLAYS_SW_HLR_12426013]  -  Custom Test")
Output ("")

VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 14, 0, "PreviousPrimaryNavSource = GLS2")
VerifyWrite(ggf_PrimaryNavSource(((Instance-1) + 0) Mod 4), 6, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource = VOR3") 
VerifyWrite(ggf_PfdData(((Instance-1) + 0) Mod 4), 3, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PfdData = Fresh and Valid")

SetNoChangeStart(Array(agmcal_Nav1ChangeBit(Instance-1), agmcal_Nav2ChangeBit(Instance-1)), Array(0, 0))
VerifyWrite(ggf_PrimaryNavSourceStatus(((Instance-1) + 0) Mod 4), 1, "ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSourceStatus = Valid") 
Delay (2.0)
VerifyReadChkValue(DuRtNav_m_PreviousPrimaryNavSource, 6, 0, "PreviousPrimaryNavSource = ggf"&((((Instance-1) + 0) Mod 4) + 1)&"_PrimaryNavSource(VOR3)")
#Verify agmcal_Nav1ChangeBit and agmcal_Nav2ChangeBit are not set to change for 1.5 sec
ValidateNoChangeEnd(Array("agmcal_Nav1ChangeBit", "agmcal_Nav2ChangeBit"))
 
#End If #CompareObjectID

If CompareObjectID("SDD_CALF_12827") Or CompareObjectID("SDD_CALF_12597") Or CompareObjectID("DISPLAYS_SW_HLR_12428981") Or CompareObjectID("DISPLAYS_SW_HLR_12427371") Or CompareObjectID("DISPLAYS_SW_HLR_12427372"):
#------------------------------------------------------------------------------------------------------------
# TestCase         : c1
# Input Conditions : Set           
#                    fms_FmsNav<x>_200msec.Good = Fresh and Valid
#                    fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#
#                    mrc<x>_Nav200msec.Good = Fresh and Valid
#                    mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#
#                    mrc<x>_NavChannel Changes
#                    Nav<x>timerActive not active
#
# Expected Results : Verify
#                    fmsAutoTuneNav<x> = FALSE (initial condition)
#                    mrc<x>AutoTune = FALSE (initial condition) 
#                    mrc<x>NavChannelChange = FALSE (initial condition)
#                    agmcal_Nav<x>PreChannel# = Mrc<x>PresetValue
#                    agmcal_Nav<x>ChangeBit# = ‘change’ for 1.5 sec
#                    Nav<x>timerActive = TRUE
#                    Activate Nav<x>NavTuneTimer ( 2 second timer )
#                    agmcal_Nav<x>ChangeBit# = ‘change’ for 1.5 sec
#                    Nav<x>timerActive = FALSE
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC c1::SDD_CALF_12827]  -  Test By Inspection")
Output ("[TP_1::TC c1::SDD_CALF_12597]  -  Test By Inspection")
Output ("[TP_1::TC c1::DISPLAYS_SW_HLR_12428981]  -  Test By Inspection")
Output ("[TP_1::TC c1::DISPLAYS_SW_HLR_12427371]  -  Test By Inspection")
Output ("[TP_1::TC c1::DISPLAYS_SW_HLR_12427372]  -  Test By Inspection")
Output ("")

Input_condition  = "fms_FmsNav<x>_200msec.Good = Fresh and Valid"\
                   "fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#"\
                   "mrc<x>_Nav200msec.Good = Fresh and Valid"\				  
                   "mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#"\
                   "Nav<x>timerActive not active"\
                   "mrc<x>_NavChannel Changes"				  
Expected_Result  = "fmsAutoTuneNav<x> = FALSE (initial condition)"\
                   "mrc<x>AutoTune = FALSE (initial condition) "\
                   "mrc<x>NavChannelChange = FALSE (initial condition)"\
                   "agmcal_Nav<x>PreChannel# = Mrc<x>PresetValue"\
                   "agmcal_Nav<x>ChangeBit# = ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive = TRUE"\
                   "Activate Nav<x>NavTuneTimer ( 2 second timer )"\
                   "agmcal_Nav<x>ChangeBit# = ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive = FALSE"
ObjectID         = "SDD_CALF_12827, SDD_CALF_12597, DISPLAYS_SW_HLR_12428981, DISPLAYS_SW_HLR_12427371, DISPLAYS_SW_HLR_12427372"
CA_Justification = "Internal parameters are not exposed for test environment and cannot be simulated to verify in the test environment"\
                   " so this test case is tested by inspection"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#------------------------------------------------------------------------------------------------------------
# TestCase         : c2
# Input Conditions : Set           
#                    fms_FmsNav<x>_200msec.Good = Invalid and Stale
#                    fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#
#                    mrc<x>_Nav200msec.Good = Fresh and Valid
#                    mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#
#                    mrc<x>_NavChannel Changes
#                    Nav<x>timerActive not active
#
# Expected Results : Verify
#                    fmsAutoTuneNav<x> = FALSE (initial condition)
#                    mrc<x>AutoTune = FALSE (initial condition) 
#                    mrc<x>NavChannelChange = FALSE (initial condition)
#                    agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> TRUE
#                    Not Activate Nav<x>NavTuneTimer ( 2 second timer )
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> FALSE
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC c2::SDD_CALF_12827]  -  Test By Inspection")
Output ("[TP_1::TC c2::SDD_CALF_12597]  -  Test By Inspection")
Output ("[TP_1::TC c2::DISPLAYS_SW_HLR_12428981]  -  Test By Inspection")
Output ("[TP_1::TC c2::DISPLAYS_SW_HLR_12427371]  -  Test By Inspection")
Output ("[TP_1::TC c2::DISPLAYS_SW_HLR_12427372]  -  Test By Inspection")
Output ("")

Input_condition  = "fms_FmsNav<x>_200msec.Good = Invalid and Stale"\
                   "fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#"\
                   "mrc<x>_Nav200msec.Good = Fresh and Valid"\				  
                   "mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#"\
                   "Nav<x>timerActive not active"\
                   "mrc<x>_NavChannel Changes"				  
Expected_Result  = "fmsAutoTuneNav<x> = FALSE (initial condition)"\
                   "mrc<x>AutoTune = FALSE (initial condition) "\
                   "mrc<x>NavChannelChange = FALSE (initial condition)"\
                   "agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> TRUE"\
                   "Not Activate Nav<x>NavTuneTimer ( 2 second timer )"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> FALSE"
ObjectID         = "SDD_CALF_12827, SDD_CALF_12597, DISPLAYS_SW_HLR_12428981, DISPLAYS_SW_HLR_12427371, DISPLAYS_SW_HLR_12427372"
CA_Justification = "Internal parameters are not exposed for test environment and cannot be simulated to verify in the test environment"\
                   " so this test case is tested by inspection"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#------------------------------------------------------------------------------------------------------------
# TestCase         : c3
# Input Conditions : Set           
#                    fms_FmsNav<x>_200msec.Good = Fresh and Valid
#                    fms_Nav<x>Status does not transition from #No Computed Data# to #Normal Operation#
#                    mrc<x>_Nav200msec.Good = Fresh and Valid
#                    mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#
#                    mrc<x>_NavChannel Changes
#                    Nav<x>timerActive not active
#
# Expected Results : Verify
#                    fmsAutoTuneNav<x> = FALSE (initial condition)
#                    mrc<x>AutoTune = FALSE (initial condition) 
#                    mrc<x>NavChannelChange = FALSE (initial condition)
#                    agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> TRUE
#                    Not Activate Nav<x>NavTuneTimer ( 2 second timer )
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> FALSE
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC c3::SDD_CALF_12827]  -  Test By Inspection")
Output ("[TP_1::TC c3::SDD_CALF_12597]  -  Test By Inspection")
Output ("[TP_1::TC c3::DISPLAYS_SW_HLR_12428981]  -  Test By Inspection")
Output ("[TP_1::TC c3::DISPLAYS_SW_HLR_12427371]  -  Test By Inspection")
Output ("[TP_1::TC c3::DISPLAYS_SW_HLR_12427372]  -  Test By Inspection")
Output ("")

Input_condition  = "fms_FmsNav<x>_200msec.Good = Invalid and Stale"\
                   "fms_Nav<x>Status does not transition from #No Computed Data# to #Normal Operation#"\
                   "mrc<x>_Nav200msec.Good = Fresh and Valid"\				  
                   "mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#"\
                   "Nav<x>timerActive not active"\
                   "mrc<x>_NavChannel Changes"				  
Expected_Result  = "fmsAutoTuneNav<x> = FALSE (initial condition)"\
                   "mrc<x>AutoTune = FALSE (initial condition) "\
                   "mrc<x>NavChannelChange = FALSE (initial condition)"\
                   "agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> TRUE"\
                   "Not Activate Nav<x>NavTuneTimer ( 2 second timer )"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> FALSE"
ObjectID         = "SDD_CALF_12827, SDD_CALF_12597, DISPLAYS_SW_HLR_12428981, DISPLAYS_SW_HLR_12427371, DISPLAYS_SW_HLR_12427372"
CA_Justification = "Internal parameters are not exposed for test environment and cannot be simulated to verify in the test environment"\
                   " so this test case is tested by inspection"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#------------------------------------------------------------------------------------------------------------
# TestCase         : c4
# Input Conditions : Set           
#                    fms_FmsNav<x>_200msec.Good = Fresh and Valid
#                    fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#
#                    mrc<x>_Nav200msec.Good = Fresh and Valid
#                    mrc<x>_NavFmsManualAuto does not transition from #Manual# to #Auto#
#                    mrc<x>_NavChannel Changes
#                    Nav<x>timerActive not active
#
# Expected Results : Verify
#                    fmsAutoTuneNav<x> = FALSE (initial condition)
#                    mrc<x>AutoTune = FALSE (initial condition) 
#                    mrc<x>NavChannelChange = FALSE (initial condition)
#                    agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> TRUE
#                    Not Activate Nav<x>NavTuneTimer ( 2 second timer )
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> FALSE
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC c4::SDD_CALF_12827]  -  Test By Inspection")
Output ("[TP_1::TC c4::SDD_CALF_12597]  -  Test By Inspection")
Output ("[TP_1::TC c4::DISPLAYS_SW_HLR_12428981]  -  Test By Inspection")
Output ("[TP_1::TC c4::DISPLAYS_SW_HLR_12427371]  -  Test By Inspection")
Output ("[TP_1::TC c4::DISPLAYS_SW_HLR_12427372]  -  Test By Inspection")
Output ("")

Input_condition  = "fms_FmsNav<x>_200msec.Good = Invalid and Stale"\
                   "fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#"\
                   "mrc<x>_Nav200msec.Good = Fresh and Valid"\				  
                   "mrc<x>_NavFmsManualAuto does not transition from #Manual# to #Auto#"\
                   "Nav<x>timerActive not active"\
                   "mrc<x>_NavChannel Changes"				  
Expected_Result  = "fmsAutoTuneNav<x> = FALSE (initial condition)"\
                   "mrc<x>AutoTune = FALSE (initial condition) "\
                   "mrc<x>NavChannelChange = FALSE (initial condition)"\
                   "agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> TRUE"\
                   "Not Activate Nav<x>NavTuneTimer ( 2 second timer )"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> FALSE"
ObjectID         = "SDD_CALF_12827, SDD_CALF_12597, DISPLAYS_SW_HLR_12428981, DISPLAYS_SW_HLR_12427371, DISPLAYS_SW_HLR_12427372"
CA_Justification = "Internal parameters are not exposed for test environment and cannot be simulated to verify in the test environment"\
                   " so this test case is tested by inspection"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#------------------------------------------------------------------------------------------------------------
# TestCase         : c5
# Input Conditions : Set           
#                    fms_FmsNav<x>_200msec.Good = Fresh and Valid
#                    fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#
#                    mrc<x>_Nav200msec.Good = Invalid and stale
#                    mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#
#                    mrc<x>_NavChannel Changes
#                    Nav<x>timerActive not active
#
# Expected Results : Verify
#                    fmsAutoTuneNav<x> = FALSE (initial condition)
#                    mrc<x>AutoTune = FALSE (initial condition) 
#                    mrc<x>NavChannelChange = FALSE (initial condition)
#                    agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> TRUE
#                    Not Activate Nav<x>NavTuneTimer ( 2 second timer )
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> FALSE
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC c5::SDD_CALF_12827]  -  Test By Inspection")
Output ("[TP_1::TC c5::SDD_CALF_12597]  -  Test By Inspection")
Output ("[TP_1::TC c5::DISPLAYS_SW_HLR_12428981]  -  Test By Inspection")
Output ("[TP_1::TC c5::DISPLAYS_SW_HLR_12427371]  -  Test By Inspection")
Output ("[TP_1::TC c5::DISPLAYS_SW_HLR_12427372]  -  Test By Inspection")
Output ("")

Input_condition  = "fms_FmsNav<x>_200msec.Good = Fresh and Valid "\
                   "fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#"\
                   "mrc<x>_Nav200msec.Good = Invalid and stale"\				  
                   "mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#"\
                   "Nav<x>timerActive not active"\
                   "mrc<x>_NavChannel Changes"				  
Expected_Result  = "fmsAutoTuneNav<x> = FALSE (initial condition)"\
                   "mrc<x>AutoTune = FALSE (initial condition) "\
                   "mrc<x>NavChannelChange = FALSE (initial condition)"\
                   "agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> TRUE"\
                   "Not Activate Nav<x>NavTuneTimer ( 2 second timer )"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> FALSE"
ObjectID         = "SDD_CALF_12827, SDD_CALF_12597, DISPLAYS_SW_HLR_12428981, DISPLAYS_SW_HLR_12427371, DISPLAYS_SW_HLR_12427372"
CA_Justification = "Internal parameters are not exposed for test environment and cannot be simulated to verify in the test environment"\
                   " so this test case is tested by inspection"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#------------------------------------------------------------------------------------------------------------
# TestCase         : c6
# Input Conditions : Set           
#                    fms_FmsNav<x>_200msec.Good = Fresh and Valid
#                    fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#
#                    mrc<x>_Nav200msec.Good = Fresh and Valid
#                    mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#
#                    mrc<x>_NavChannel does not Changes
#                    Nav<x>timerActive not active
#
# Expected Results : Verify
#                    fmsAutoTuneNav<x> = FALSE (initial condition)
#                    mrc<x>AutoTune = FALSE (initial condition) 
#                    mrc<x>NavChannelChange = FALSE (initial condition)
#                    agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> TRUE
#                    Not Activate Nav<x>NavTuneTimer ( 2 second timer )
#                    agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec
#                    Nav<x>timerActive <> FALSE
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC c6::SDD_CALF_12827]  -  Test By Inspection")
Output ("[TP_1::TC c6::SDD_CALF_12597]  -  Test By Inspection")
Output ("[TP_1::TC c6::DISPLAYS_SW_HLR_12428981]  -  Test By Inspection")
Output ("[TP_1::TC c6::DISPLAYS_SW_HLR_12427371]  -  Test By Inspection")
Output ("[TP_1::TC c6::DISPLAYS_SW_HLR_12427372]  -  Test By Inspection")
Output ("")

Input_condition  = "fms_FmsNav<x>_200msec.Good = Fresh and Valid"\
                   "fms_Nav<x>Status transition from #No Computed Data# to #Normal Operation#"\
                   "mrc<x>_Nav200msec.Good = Fresh and Valid"\				  
                   "mrc<x>_NavFmsManualAuto transition from #Manual# to #Auto#"\
                   "Nav<x>timerActive not active"\
                   "mrc<x>_NavChannel does not Changes"				  
Expected_Result  = "fmsAutoTuneNav<x> = FALSE (initial condition)"\
                   "mrc<x>AutoTune = FALSE (initial condition) "\
                   "mrc<x>NavChannelChange = FALSE (initial condition)"\
                   "agmcal_Nav<x>PreChannel# <> Mrc<x>PresetValue"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> TRUE"\
                   "Not Activate Nav<x>NavTuneTimer ( 2 second timer )"\
                   "agmcal_Nav<x>ChangeBit# <> ‘change’ for 1.5 sec"\
                   "Nav<x>timerActive <> FALSE"
ObjectID         = "SDD_CALF_12827, SDD_CALF_12597, DISPLAYS_SW_HLR_12428981, DISPLAYS_SW_HLR_12427371, DISPLAYS_SW_HLR_12427372"
CA_Justification = "Internal parameters are not exposed for test environment and cannot be simulated to verify in the test environment"\
                   " so this test case is tested by inspection"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If #CompareObjectID

#============================================================================================================
#                                        PRINT FINAL RESULTS
#------------------------------------------------------------------------------------------------------------
ReportSummary()
