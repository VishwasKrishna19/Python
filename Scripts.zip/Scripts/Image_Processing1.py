from PIL import Image, ImageFilter

img = Image.open('C:\\Vishwas\\Task_Assigned\\TSC2_0\\Drop2\\Load_5_5\\RFS\\Program_T2L_TGFB_0004\\Actual\\a13.png')

print(img.format)
print(img.size)
print(img.mode)
print(dir(img))

img.save("C:\\Vishwas\\Task_Assigned\\TSC2_0\\Drop2\\Load_5_5\\RFS\\Program_T2L_TGFB_0004\\Newfolder\\a13.png", "png")

