import os
base_path = os.path.dirname(__file__)
cr_txt = os.path.abspath(os.path.join(base_path,"CR_txt_1"))
one_time_res = os.path.abspath(os.path.join(base_path,"Results","onetime_1.txt"))
result_dir = os.path.abspath(os.path.join(base_path,"Results"))
if not os.path.isdir(result_dir):
    os.mkdir(result_dir)
else:
    pass

#this function parses the CR_txt folder to see how many CR.txts are present,the count and returns the same
def cr_txt_tracker():
    list = os.listdir(cr_txt)  # dir is your directory path
    txt_count = 0
    for txts in list:
        if txts.endswith('.txt'):
            txt_count += 1
    #print(txt_count)
    return (list,txt_count)

list,txt_count = cr_txt_tracker()
with open(one_time_res,"w+",encoding="utf-8") as file:
    for txts in list:
        file.write(str(txts)+'\n')
    file.write("NUMBER_INIT:"+str(txt_count))