import re
import os
import sys

with open("C:/Users/h126313/Desktop/Python/Shall_to_object/input.txt") as f:
    with open("C:/Users/h126313/Desktop/Python/Shall_to_object/TSD_S15B_0010_Part1.tsf", "r") as f1:
        with open("C:/Users/h126313/Desktop/Python/Shall_to_object/TSD_S15B_0010_Part1_updated.tsf", "w") as wf:
            for line in f:
                inputline = line.split(",")[0]
                replaceline = line.split(",")[1]
                replaceline = replaceline.rstrip('\n')
                print(inputline)
                for line2 in f1:
                    if inputline in line2:
                        print("Match Found")
                        line2 = line2.replace(inputline, replaceline)
                    wf.write(line2)
                    continue

