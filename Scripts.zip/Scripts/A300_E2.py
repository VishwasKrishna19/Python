from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os
import pandas as pd
import time
start_time = time.clock()

#req_doc1 = 'A300_GGF.XLSX'
#req_doc2 = 'E2_GGF.XLSX'

req_doc1 = 'A300_CALF_REQ.xlsx'
req_doc2 = 'E2_CALF.xlsx'

dataframe1 = pd.read_excel(req_doc1)
dataframe2 = pd.read_excel(req_doc2)

req1 = dataframe1['REQUIREMENT'][:500]
req2 = dataframe2['REQUIREMENT']

tag1 = dataframe1['ID']
tag2 = dataframe2['ID']


def getCosSimilarity(req1, req2):
    corpus = [req1, req2]
    tf = TfidfVectorizer()
    tfidf_matrix = tf.fit_transform([content for content in corpus])
    similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix)[0][1]
    return similarity


#print(len(req1))
#print(len(req2))

sim = []
index_final = []

for index1,requi1 in enumerate(req1):
    sim_fac = 0
    index_fac = 0
    for index2,requi2 in enumerate(req2):
        if not (pd.isnull(requi1) and pd.isnull(requi2)):
           sim_temp = getCosSimilarity(requi1,requi2)
           #print(index2)
           if sim_temp > sim_fac:
               sim_fac = sim_temp
               index_fac = index2
           else:
               continue
    sim.append(sim_fac)
    index_final.append(index_fac)

to_write= []
for index,id in enumerate(index_final):
    to_write.append([tag2[id],req2[id],sim[index]])
    print(tag2[id],req2[id],sim[index])


#total time taken is printed on the screen
print(time.clock() - start_time)
