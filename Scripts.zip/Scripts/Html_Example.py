#import pypandoc
#from tidylib import tidy_document
#
#output = pypandoc.convert('C:/Users/h126313/Desktop/Python/TINK_TOOL/Sample.docx', 'html')
#output, errors = tidy_document(output)
#with open('C:/Users/h126313/Desktop/Python/TINK_TOOL/Sample.html', 'w') as f:
#    f.write(output)

import mammoth

#f = open("C:/Users/h126313/Desktop/Python/TINK_TOOL/Sample.docx", 'rb')
with open("C:/Users/h126313/Desktop/Python/TINK_TOOL/Sample.docx", "rb") as docx_file:
    with open('C:/Users/h126313/Desktop/Python/TINK_TOOL/Sample.html', 'w') as htmlout:
        result = mammoth.convert_to_html(docx_file)
        html = result.value
        print(html)
        htmlout.write(html)