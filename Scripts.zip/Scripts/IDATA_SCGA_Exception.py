import os
import sys
import re
import csv
import xlrd
import os.path

wb = xlrd.open_workbook(os.path.join('C:/Vishwas/TASKS_ASSIGNED/Python/Idata','3_IN_Trace.xlsx'))
with open("C:/Vishwas/TASKS_ASSIGNED/Python/Idata/Artifacts_To_Check/Dump_data.txt") as DumpData:
    with open ('C:/Vishwas/TASKS_ASSIGNED/Python/Idata/Artifacts_To_Check/IDB_Name.txt') as IDBName:
        with open ('C:/Vishwas/TASKS_ASSIGNED/Python/Idata/Artifacts_To_Check/trace_miss.txt') as TraceMiss:
            with open("C:/Vishwas/TASKS_ASSIGNED/Python/Idata/Artifacts_To_Check/Exception_Sheet.csv", "w") as Exception:
                with open("C:/Vishwas/TASKS_ASSIGNED/Python/Idata/Artifacts_To_Check/DumpDataXML.txt") as DumpXML:
                    Exception.write("IDB_NAME,Trace_Tag,HASH_NAME_DECIMAL,ELEMENT_TAG_NAME_DECIMAL,XML_FILE_NAME,XML_LINE_NUMBER,XML_LINE_DATA,XML_GROUP_NAME,XML_TRACE_TAG,EXCEL_TRACE_INFO,EXCEL_TSF_INFO\n")
                    IDBName_Final = IDBName.readline()
                    IDBName_Final = IDBName_Final.rstrip('\n')
                    line1 = DumpXML.readlines()
                    line2 = DumpData.readlines()
                    for tracemissedlines in TraceMiss:
                        tracemissedlines = tracemissedlines.rstrip("\n")
                        tracemissedlines1 = tracemissedlines.split("_")[0]
                        tracemissedlines1 = int(tracemissedlines1,16)
                        Hash_Name_Decimal = str(tracemissedlines1)
                        element_tag_name = tracemissedlines.split("_")[1]
                        element_tag_name = int(str(element_tag_name)[:4])
                        #print(Hash_Name_Decimal)
                        for Dump_XML_data in line1:
                            if Dump_XML_data.__contains__(Hash_Name_Decimal):
                                Dump_XML_data = Dump_XML_data.rstrip('\n')
                                XML_Name = Dump_XML_data.split(",")[0]
                                break
                        #print(Hash_Name_Decimal, Dump_XML_data)
                        XML_line_Search = "elementhashname=\"" +str(Hash_Name_Decimal) + "\" elementtag=\"" + str(element_tag_name) + "\""
                        #print(XML_line_Search)
                        for DumpData in line2:
                            if XML_line_Search in DumpData:
                                Line_Number = DumpData.split(",")[-2]
                                #print(XML_line_Search+ "," +DumpData)
                                XML_Line_Data = DumpData.split(",")[1]
                                #print(XML_line_Search+ "," +DumpData + ","+ XML_Line_Data)
                                #print(XML_Line_Data)
                                Xml_Trace_Tag = DumpData.split(",")[-5]
                                XML_Group_Name = DumpData.split(",")[-6]
                                print(XML_Group_Name)
                        print(XML_Group_Name)

                        #Reading 3_IN_Trace.xlsx for Idata Trace

                        Exception.write(IDBName_Final + "," + tracemissedlines + "," + Hash_Name_Decimal + "," + str(element_tag_name) + "," + str(XML_Name) + "," + str(Line_Number) +"," + str(XML_Line_Data) +"," + str(XML_Group_Name) +","+ str(Xml_Trace_Tag) + "\n"  )




