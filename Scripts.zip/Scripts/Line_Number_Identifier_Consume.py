# -*- coding: utf-8 -*-
"""
Created on Feb 11 14:12:13 2018

@author: E530477
"""

import os
import sys
import re

lineCount = 0
lineCount_printd = 0
tbiFound = False
parsing = False
ratematching = False
ratematching1 = False
Tbi_print = False
foundValues = []
String_in_TBI = 'Verify'
startParsing_Tbidetails = '>  Expected_Result'
fill_line = 'Line No'
path_printed = ''
Function_update = 'PassCriteria: Module and/or Function Name:'
Document_Update = 'Document chapter:'
Input_condition = 'For Input_condition:'
Expected_Results = 'Expected_Result:'
EL = 'Test Infrastructure'
EL_Replaced = '1. The specific test'
Input = ' 2. The conditions that would'
Result = '3. The results of the code'
Failed='No. of Test By Inspection Test Steps Failed'
Passed='No. of Test By Inspection Test Steps Passed'
Total_Test='Total No. of Test By Inspection Test Steps:'
Cpp_Name=''
pattern = 'Expected_Result ['



def getCppInfo(line):
    if (('Consume' in line or 'Produce' in line) and 'Expected_Result:' in line):
        param, key = line.split('the data')
        key, nodata = key.split('Hz')
        param1, param = param.split('Expected_Result:')
        pos = param.find('[')
        param = (param[2:pos + 8]).strip()
        poskey = key.find(' at')
        key2 = (key[0:poskey]).strip()
        key1 = (key[poskey + 4:-1]).strip()
        paramfull = (param + key1 + 'Hz')
        return param, key2, paramfull
    return (None, None, None)

def get_CPP_Name(line):
    param, key = line.split('the data')
    key, nodata = key.split('Hz')
    param1, param = param.split('Expected_Result')
    pos = param.find('[')
    param = (param[2:pos + 8]).strip()
    poskey = key.find(' at')
    key2 = (key[0:poskey]).strip()
    key1 = (key[poskey + 4:-1]).strip()
    paramfull = (param + key1 + 'Hz')
    print(paramfull,param,key2)
    if (paramfull is not None):
       pfull = 'TinkImp_' + user_Process_Input.strip() + '::' + paramfull
    if (param is not None and key2 is not None and pfull is not None):
        ratematching=False
        for root, dirs, files in os.walk(cppFile):
           for file in files:
               lineCount = 0
               ratematching1 = False
               if file.endswith(".cpp"):
                   with open(os.path.join(root, file), 'r+') as cpp:
                       for line1 in cpp:
                           lineCount += 1
                           if (pfull in line1):
                               ratematching = True
                               callermatch = key2 + '.' + param + '('
                           if (ratematching and callermatch in line1):
                               ratematching1 = True
                               ratematching = False
                               parsing = False
                               lineCount_printd = lineCount
                               path_printed = os.path.basename(file)
                               print(path_printed)
                               return path_printed
                               break
                           if (ratematching1):
                               print("4")
                               break


cppFile = r'C:\TSC2.0\Tink\Tink_TBI\Cpp'
tbiFile = r'C:\TSC2.0\Tink\Tink_TBI\TBI'
Software_Version = r'EDS_TSC2_00_001'
CM_Version_Doors = r' Available in DOORS (/36601 AZ - Warner Rd/EPIC_CORE/EPIC_CORE/EPIC_2_TSC)'
Document_chapter = 'TSC_001_Appx_F_TFM_Tink'
Initial='_P_  __SM__'
Name='Saranya M'
strChoiceProdCons = ""

'''cppFile = input("Enter the CPP filename with full path: ")
tbiFile = input("Enter the Sum filename with full path: ")
Software_Version = input("Enter Software_Version: ")
CM_Version_Doors = input("Enter Doors Version: ")
Document_chapter = input("Enter Document_chapter: ")
Initial = input("Enter your Initials: ")
Name=input("Enter your Name: ")
os.getcwd()'''

print("\nGenerate Test Process to:")
print("    1. TGF")
print("    2. TFM")
print("    3. UDPTSC")
print("    4. Udpagm")

strChoiceConsume_Process = input("Enter only one choice: ").strip()


## User Choice allowed are numbers
Check_RE = re.compile("^[0-9\s]*$")

if strChoiceConsume_Process != "":
    if Check_RE.match(strChoiceConsume_Process):
        if int(strChoiceConsume_Process) > 4 or int(strChoiceConsume_Process) < 1:
            print("** Error: Valid choice is not entered **")
            sys.exit()
        else:
            if int(strChoiceConsume_Process) == 1:
                user_Process_Input = r'TscGraphics'
            elif int(strChoiceConsume_Process) == 2:
                user_Process_Input = r'TFM'
            elif int(strChoiceConsume_Process) == 3:
                user_Process_Input = r'TscUdpTsc'
            elif int(strChoiceConsume_Process) == 4:
                user_Process_Input = r'TscUdpAgm'



for root1, dirs1, files in os.walk(tbiFile):
    for file in files:
        if file.endswith(".sum"):
            with open(os.path.join(root1, file), 'r+') as tbi:
                outtbi = open(os.path.basename(file).strip('.sum') + '.tbi', 'w')
                for line in tbi:
                    if String_in_TBI in line:
                        tbiFound = True
                    elif (tbiFound and startParsing_Tbidetails in line):
                        parsing = True
                    elif fill_line in line:
                        Tbi_print = True
                    elif Tbi_print:
                        outtbi.write("%s" % lineCount_printd + '\t' + 'in' + '\t' + pfull + '  ' + path_printed + '\n')
                        Tbi_print = False
                    elif Input_condition in line:
                        Input_condition_used = line[(line.find(': [')) + 3:-1].rstrip("]")
                    elif Expected_Results in line:
                        Expected_Results_Used = line[(line.find(': ['))+3:-1].rstrip("]")
                    elif EL in line:
                        EL_Used = line[(line.find('] Test')) + 2:-1].rstrip("]")
                    elif Total_Test in line:
                        Total_Test_Used = line[(line.find(Total_Test)):-1].split(':')
                    if '>  Expected_Result' in line:
                        Cpp_Name = get_CPP_Name(line)
                        print(Cpp_Name)



                    if (parsing):
                        p, k, pfull = getCppInfo(line)
                        if (pfull is not None):
                            pfull = 'TinkImp_' + user_Process_Input.strip() + '::' + pfull
                        if (p is not None and k is not None and pfull is not None):
                            for root, dirs, files in os.walk(cppFile):
                                for file in files:
                                    lineCount = 0
                                    ratematching1 = False
                                    if file.endswith(".cpp"):
                                        with open(os.path.join(root, file), 'r+') as cpp:
                                            for line1 in cpp:
                                                lineCount += 1
                                                if (pfull in line1):
                                                    ratematching = True
                                                    callermatch = k + '.' + p + '('
                                                if (ratematching and callermatch in line1):
                                                    ratematching1 = True
                                                    ratematching = False
                                                    parsing = False
                                                    lineCount_printd = lineCount
                                                    path_printed = os.path.basename(file)
                                                    break
                                                if (ratematching1):
                                                    print("4")
                                                    break
                    if Function_update in line:
                        outtbi.write(line.replace(line, line[:(line.find(']'))+2].rstrip("]") + Function_update + Cpp_Name+ '\t' + "CM Version:" + Software_Version +'\n'))
                    elif Document_Update in line:
                        var = line[0:(line.find(']')) + 1]
                        outtbi.write(
                            '{0}{1}:{2}\t{3}\n'.format(var, Document_Update, Document_chapter, CM_Version_Doors))
                    elif EL_Replaced in line:
                        outtbi.write(line.replace(line, line.strip() + EL_Used + '\n'))
                    elif Input in line:
                        outtbi.write(line.replace(line, line.strip() + Input_condition_used + '\n'))
                    elif Result in line:
                        outtbi.write(line.replace(line, line.strip() + Expected_Results_Used + '\n'))
                    elif 'Actual Result:' in line:
                        outtbi.write(line.replace(line, line.strip() + Expected_Results_Used + '\n'))
                    elif 'Failure Description' in line:
                        outtbi.write(line.replace(line, line.strip() + 'NA' + '\n'))
                    elif '___' in line and 'Y/N' not in line and 'Name:' not in line:
                        outtbi.write(line.replace(line, line[:(line.find(']'))+2].rstrip("]") + Initial + '\n'))
                    elif  'Y/N'  in line:
                        outtbi.write(line.replace(line, line.strip() + '_Y___' + '\n'))
                    elif Passed in line :
                        outtbi.write(line.replace(line, line.strip() + Total_Test_Used[1] + '\n'))
                    elif Failed in line :
                        outtbi.write(line.replace(line, line.strip() + '0' + '\n'))
                    elif 'Name:' in line :
                        outtbi.write(line.replace(line, line.strip() + Name + '_______'+'\n'))
                    else:
                        outtbi.write(line)
                outtbi.close()
