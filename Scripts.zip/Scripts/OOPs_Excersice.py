
#Base Class
class Pets():
    animals = []
    def __init__(self, animals):
        self.animals = animals

    def walk(self):
        for animal in self.animals:
            print(animal.walk())

class Cat(): #Parent Class
    is_lazy = True

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def walk(self):
        return f'{self.name} is walking around'

class Simon(Cat): #Child Class
    def sing(self, sounds):
        return f'{sounds}'

class Sally(Cat):
    def sing(self, sounds):
        return f'{sounds}'

#1 Add another Cat
class Suzy(Cat):
    def sing(self, sounds):
        return f'{sounds}'

#2 Create a list of all of the pets (create 3 cat instances from the above)
cat1 = Simon('simon', 4)
cat2 = Sally('sally', 8)
cat3 = Suzy('suzy', 10)

my_cats = [cat1, cat2, cat3]

print(cat1.sing("meow"))
print(cat2.sing("Bow Bow"))
print(cat3.sing("caw caw"))
print(cat2.is_lazy)
#3 Instantiate the Pet class with all your cats use variable my_pets
mypets = Pets(my_cats)

#4 Output all of the cats walking using the my_pets instance
mypets.walk()

print("***************")
for char in my_cats:
    print(char.sing("meow"))
    mypets.walk()
