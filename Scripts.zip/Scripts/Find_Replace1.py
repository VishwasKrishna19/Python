import os

texttofind = ''
texttoreplace = ''
texttofindarr = []
texttoreplacearr = []

main_Path = input("Provide the Root Folder Path: ")
os.chdir(main_Path)
print(os.getcwd())
sourcepath = os.listdir('InputFiles/')
#print(sourcepath)

inputfile1 = open("Find_Replace.txt", 'r')

for eachline in inputfile1:
    eachline = eachline.strip()
    texttofind, texttoreplace = eachline.split(",")
    texttofindarr.append(texttofind)
    texttoreplacearr.append(texttoreplace)

inputfile1.close()
print(texttofindarr)
print(texttoreplacearr)

for eachfile in sourcepath:
    destinationPath = 'OutputFiles/' + eachfile
    print(destinationPath)
    with open(destinationPath, 'w') as outputfile:
        for eachfile in sourcepath:
            inputfile = 'InputFiles/' + eachfile
            print("Conversion is Going on for: " +inputfile)
            print(inputfile)
            with open(inputfile, "r") as inputfile:
                filedata = inputfile.read()
                freq =0
                freq = filedata.count(texttofind)
            for texttofind, texttoreplace in zip(texttofindarr, texttoreplacearr):
                print(texttofind, texttoreplace)
                filedata = filedata.replace(texttofind, texttoreplace)

                print("Total %d words Replaced" % freq)
        outputfile.write(filedata)

