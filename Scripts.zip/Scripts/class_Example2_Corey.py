

class Employee():
    raise_amount = 1.05

    def __init__(self, firstname, lastname, pay):
        self.firstname = firstname
        self.lastname = lastname
        self.pay = pay
        self.email = firstname + "." + lastname + "@Honeywell.com"

    def fullname(self):
        return '{} {}'.format(self.firstname, self.lastname)

    def applyraise(self):
        self.pay = int(self.pay * self.raise_amount) #if we want to access class variables we need to access through class itself or from instance
                                    #Emplyoee.raise_amount also works

    @classmethod
    def set_raise_amt(cls, amount):
        cls.raise_amount = amount

    @classmethod #Decorators
    def from_string(cls, emp_Str):
        first, last, pay = emp_Str.split('-')
        return cls(first, last, pay)

    @staticmethod #Decorators
    def is_workday(day):
        if day.weekday() == 5 or day.weekday() == 6:
            return False
        return True

emp1 = Employee('Vishwas', 'Krishna', 50000)
emp2 = Employee('Corey', 'Schafer', 60000)
print(emp1.email)

print(emp1.fullname())  #Here with the instance only we are printing so no arguments required
print(Employee.fullname(emp1)) #Accsing from class only but still as an argument we need to pass instance

print(emp1.pay)
emp1.applyraise()
print(emp1.pay)

print(Employee.raise_amount)
print(emp1.raise_amount)
print(emp2.raise_amount)
emp2.applyraise()
print(emp2.pay)

print('*******************************')
Employee.raise_amount = 1.06
emp1.raise_amount = 1.09
emp1.applyraise()
print(emp1.__dict__)

emp_str_1 = 'vishwas-krishna-5000'
emp_str_2 = 'corey-scahfer-500000'
emp_str_3 = 'steve-smith-30000'

new_emp = Employee.from_string(emp_str_1)
print(new_emp.email)
print(new_emp.pay)

print('*******************************')

import datetime
mydate = datetime.date(2020, 4, 29)
print(Employee.is_workday(mydate))