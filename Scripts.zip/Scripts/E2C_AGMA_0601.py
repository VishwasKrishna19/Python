import InitialSupport

from InitialSupport import *
TestName = "E2C_AGMA_0601"
Startsum(TestName)
#============================================================================================================
 #                      CONTROL ABSTRACTION LAYER FUNCTION SOFTWARE TEST PLAN/PROCEDURE
Output ("=====================================================================================================")
Output (" TestName       :  E2C_AGMA_0601                                                                     ")
Output ("=====================================================================================================")
Output ("                                   MODIFICATION HISTORY                                              ")
Output ("=====================================================================================================")
Output (" Version   Date       Author              Change Description                  CH_DOC                 ")
Output (" ------- ---------  --------------   ----------------------------------       ---------              ")
#Output "    01   21-Jun-15   Harsha M R     Load 1.0: Initial Development           EDS_CALF_EJETE2_VR_181   "   
Output ("    02   06-Mar-17   Harsha M R     Load 3.5: Updated Test case for          EDS_CALF_EJETE2_SCR_269  ")
Output ("                                    ActMiscompare of com and nav radios      EDS_CALF_EJETE2_VR_1010  ")
Output ("=====================================================================================================")
#============================================================================================================
#                                 TEST ENVIRONMENT SPECIFICATION
#============================================================================================================
# Environment               : MAU Mini-bench with a AGM3 card || EASE Bench
# ESCAPE Configuration DB   : EJETE2_Configuration_Data.mdb
# ESCAPE Configuration Name : AGMCAL_1 V&V Mini Bench || EJETE2_EASE
# Hyperstart Name           : agm1.bin || NA for EASE
# Additional Information    : Dtmon.exe to be loaded and Agmcal_Vars.txt need to be pointed in TIU Server
#
# The steps required to set-up a Mini bench/EASE Bench are described in Guidelines_For_E2_Bench_Setup document
#
#============================================================================================================
#                                     GENERAL COMMENTS
#------------------------------------------------------------------------------------------------------------

#============================================================================================================
#                                GENERAL SET-UP COMMANDS
#------------------------------------------------------------------------------------------------------------
# Following files are to be included in the project and should be in the following order:
#
#    1. QualifiedSupport.tsf
#    2. ComConstantsAndFunctions.tsf
#    3. E2C_AGMCAL_DatmonMapping.tsf   
#    4. MauCard.tsf                
#    5. E2C_AGMA_0601.tsf           
#
#============================================================================================================
#                                       DEFINE VARIABLES
#------------------------------------------------------------------------------------------------------------

global Input_condition, Expected_Result, Object_ID, CA_Justification, Category
global oCard

#============================================================================================================
#                                      INITIAL CONDITIONS
#------------------------------------------------------------------------------------------------------------
ObjectID_Level_Test() # Object ID level testing
Output ("")

Set oCard = New MauCard
oCard.setCardName("Agm1")
oCard.setCardModeDelay(25.0)

#============================================================================================================
#                                       TEST CASES AND PROCEDURES
#------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_8849"):
#------------------------------------------------------------------------------------------------------------
# TestCase         : a1
# Input Condition  : Set           
#                    At Process Initialization
#
# Expected Results : Verify
#                    Com1_ChangeBit#    = �Inactive� 1.5 seconds
#                    Com1_InhibitUpdate#= �Inactive� 5 seconds
#                    Com1_MiscompareTmr#= �Inactive� 2 seconds
#                    Com1_StatusTimer#  = �Active� 4 seconds
#                    Com1_SwapActive#   = �Inactive� 1.5 seconds
#                    Com1_ActMiscompare#=  False
#                    Com2_ChangeBit#    = �Inactive� 1.5 seconds
#                    Com2_InhibitUpdate#= �Inactive� 5 seconds
#                    Com2_MiscompareTmr#= �Inactive� 2 seconds
#                    Com2_StatusTimer#  = �Active� 4 seconds
#                    Com2_SwapActive#   = �Inactive� 1.5 seconds
#                    Com2_ActMiscompare#=  False
#                    Dme1_StatusTimer#  = �Active� 4 seconds
#                    Dme2_StatusTimer#  = �Active� 4 seconds
#                    Nav1_ChangeBit#    = �Inactive� 1.5 seconds
#                    Nav1_InhibitUpdate#= �Inactive� 5 seconds
#                    Nav1_MiscompareTmr#= �Inactive� 2 seconds
#                    Nav1_StatusTimer#  = �Active� 4 seconds
#                    Nav1_ActMiscompare#=  False
#                    Nav2_ChangeBit#    = �Inactive� 1.5 seconds
#                    Nav2_InhibitUpdate#= �Inactive� 5 seconds
#                    Nav2_MiscompareTmr#= �Inactive� 2 seconds
#                    Nav2_StatusTimer#  = �Active� 4 seconds
#                    Nav2_ActMiscompare#=  False
#------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_1::TC a1::SDD_CALF_8849] - Custom Test")
Output ("")

# restart the Card.
  oCard.reinit()
 
  # 40Hz * 5 seconds   = 200
  # 40Hz * 2 seconds   = 80
  # 40Hz * 1.5 seconds = 60
  # 40Hz * 4 seconds   = 160
  # AGMCAL Runs at 40Hz rate (SDD_CALF_6911)

   VerifyReadChkValue(m_DuCalComData_InhibitUpdate_TimeWindow_1,200,0,"Verify the timer for Com1_InhibitUpdate")  
   VerifyReadChkValue(m_DuCalComData_MiscompareTmr_TimeWindow_1,80,0,"Verify the timer for Com1_MiscompareTmr")    
   VerifyReadChkValue(m_DuCalComData_ChangeBit_TimeWindow_1,60,0,"Verify the timer for Com1_ChangeBit")
   VerifyReadChkValue(m_DuCalComData_SwapActive_TimeWindow_1,60,0,"Verify the timer for Com1_SwapActive")
   VerifyReadChkValue(m_DuCalComData_StatusTimer_TimeWindow_1,160,0,"Verify the timer for Com1_StatusTimer")
   VerifyReadChkValue(m_DuCalComData_ActMiscompare_1,0,0,"Verify Com1_ActMiscompare = False")
   
   VerifyReadChkValue(m_DuCalComData_InhibitUpdate_TimeWindow_2,200,0,"Verify the timer for Com2_InhibitUpdate")  
   VerifyReadChkValue(m_DuCalComData_MiscompareTmr_TimeWindow_2,80,0,"Verify the timer for Com2_MiscompareTmr")    
   VerifyReadChkValue(m_DuCalComData_ChangeBit_TimeWindow_2,60,0,"Verify the timer for Com2_ChangeBit")
   VerifyReadChkValue(m_DuCalComData_SwapActive_TimeWindow_2,60,0,"Verify the timer for Com2_SwapActive")
   VerifyReadChkValue(m_DuCalComData_StatusTimer_TimeWindow_2,160,0,"Verify the timer for Com2_StatusTimer")  
   VerifyReadChkValue(m_DuCalComData_ActMiscompare_2,0,0,"Verify Com2_ActMiscompare = False")
 
   VerifyReadChkValue(m_DuDmeData_StatusTimer_TimeWindow_1,160,0,"Verify the timer for Dme1_StatusTimer")  
   VerifyReadChkValue(m_DuDmeData_StatusTimer_TimeWindow_2,160,0,"Verify the timer for Dme2_StatusTimer")  
   
   VerifyReadChkValue(m_DuNavData_InhibitUpdate_TimeWindow_1,200,0,"Verify the timer for Nav1_InhibitUpdate")
   VerifyReadChkValue(m_DuNavData_MiscompareTmr_TimeWindow_1,80,0,"Verify the timer for Nav1_MiscompareTmr")
   VerifyReadChkValue(m_DuNavData_ChangeBit_TimeWindow_1,60,0,"Verify the timer for Nav1_ChangeBit")
   VerifyReadChkValue(m_DuNavData_StatusTimer_TimeWindow_1,160,0,"Verify the timer for Nav1_StatusTimer")  
   VerifyReadChkValue(m_DuNavData_ActMiscompare_1,0,0,"Verify Nav1_ActMiscompare = False")
   
   VerifyReadChkValue(m_DuNavData_InhibitUpdate_TimeWindow_2,200,0,"Verify the timer for Nav2_InhibitUpdate")
   VerifyReadChkValue(m_DuNavData_MiscompareTmr_TimeWindow_2,80,0,"Verify the timer for Nav2_MiscompareTmr")
   VerifyReadChkValue(m_DuNavData_ChangeBit_TimeWindow_2,60,0,"Verify the timer for Nav2_ChangeBit")
   VerifyReadChkValue(m_DuNavData_StatusTimer_TimeWindow_2,160,0,"Verify the timer for Nav2_StatusTimer")
   VerifyReadChkValue(m_DuNavData_ActMiscompare_2,0,0,"Verify Nav2_ActMiscompare = False")

#-------------------------------------------------------------------------------------------------------------
# TestCase         : a2
# Input Condition  : Set           
#                    At Process Initialization
#
# Expected Results : Verify
#                    Com1_ChangeBit# = �Inactive� 1.5 seconds
#                    Com1_InhibitUpdate#= �Inactive� 5 seconds
#                    Com1_MiscompareTmr#= �Inactive� 2 seconds
#                    Com1_StatusTimer# = �Active� 4 seconds
#                    Com1_SwapActive# = �Inactive� 1.5 seconds
#                    Com2_ChangeBit# = �Inactive� 1.5 seconds
#                    Com2_InhibitUpdate#= �Inactive� 5 seconds
#                    Com2_MiscompareTmr#= �Inactive� 2 seconds
#                    Com2_StatusTimer# = �Active� 4 seconds
#                    Com2_SwapActive# = �Inactive� 1.5 seconds
#                    Dme1_StatusTimer# = �Active� 4 seconds
#                    Dme2_StatusTimer# = �Active� 4 seconds
#                    Nav1_ChangeBit# = �Inactive� 1.5 seconds
#                    Nav1_InhibitUpdate#= �Inactive� 5 seconds
#                    Nav1_MiscompareTmr#= �Inactive� 2 seconds
#                    Nav1_StatusTimer# = �Active� 4 seconds
#                    Nav2_ChangeBit# = �Inactive� 1.5 seconds
#                    Nav2_InhibitUpdate#= �Inactive� 5 seconds
#                    Nav2_MiscompareTmr#= �Inactive� 2 seconds
#                    Nav2_StatusTimer# = �Active� 4 seconds
#-------------------------------------------------------------------------------------------------------------
Output ("")
Output ("[TP_2::TC a2::SDD_CALF_8849] - Test By Inspection")
Output ("")

 Input_condition  = "At Process Initialization"

 Expected_Result  =  " The Timers used for each radio are initialized" \ 
                     " Com1_ChangeBit# = �Inactive� 1.5 seconds  " \ 
                     " Com1_InhibitUpdate#= �Inactive� 5 seconds " \ 
                     " Com1_MiscompareTmr#= �Inactive� 2 seconds " \ 
                     " Com1_StatusTimer# = �Active� 4 seconds    " \ 
                     " Com1_SwapActive# = �Inactive� 1.5 seconds " \ 
                     " Com2_ChangeBit# = �Inactive� 1.5 seconds  " \ 
                     " Com2_InhibitUpdate#= �Inactive� 5 seconds " \ 
                     " Com2_MiscompareTmr#= �Inactive� 2 seconds " \ 
                     " Com2_StatusTimer# = �Active� 4 seconds    " \ 
                     " Com2_SwapActive# = �Inactive� 1.5 seconds " \ 
                     " Dme1_StatusTimer# = �Active� 4 seconds    " \ 
                     " Dme2_StatusTimer# = �Active� 4 seconds    " \ 
                     " Nav1_ChangeBit# = �Inactive� 1.5 seconds  " \ 
                     " Nav1_InhibitUpdate#= �Inactive� 5 seconds " \ 
                     " Nav1_MiscompareTmr#= �Inactive� 2 seconds " \ 
                     " Nav1_StatusTimer# = �Active� 4 seconds    " \ 
                     " Nav2_ChangeBit# = �Inactive� 1.5 seconds  " \ 
                     " Nav2_InhibitUpdate#= �Inactive� 5 seconds " \ 
                     " Nav2_MiscompareTmr#= �Inactive� 2 seconds " \ 
                     " Nav2_StatusTimer# = �Active� 4 seconds    "

 Category  = EL

 Object_ID = "SDD_CALF_8849"

 CA_Justification = " It is not possible to check the initialized values of timers exactly after process initialization"\
                    " Timers will be started immediately after a process start up and TATs does not have the control to watch for the timers"\
                    " immediately after process start. so this test case is tested by inspection."

 Call TCodeA.TestByInspectionOutput1(Input_condition, Expected_Result, Object_ID, CA_Justification, Category)
 
 #End If #CompareObjectID

#============================================================================================================
#                                        PRINT FINAL RESULTS
#------------------------------------------------------------------------------------------------------------
ReportSummary()
#------------------------------------------------------------------------------------------------------------