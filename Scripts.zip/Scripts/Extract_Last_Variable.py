import os
import sys
import fileinput
import re
import pandas
import pandas as pd
from numpy import *
import csv

with open("C:/Users/h126313/Desktop/Python/VC_Config/Config.txt") as config:
    with open("C:/Users/h126313/Desktop/Python/VC_Config/Config_Updated.txt", "w") as Updatedconfig:
        lines_seen = set()
        for line in config:
            if line not in lines_seen:
                line = line.split('\\')[:-1]
                line1 = "\\".join(line)
                Updatedconfig.write(line1 + '\n')
                print(line1)