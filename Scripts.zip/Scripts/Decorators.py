#Decorators can be used to enhance or add features in the function

def my_decorator(func):
    def wrap_func():
        print('***********')
        func()
        print('***********')
    return wrap_func

@my_decorator
def hello():
    print('helloooooooooo')

@my_decorator
def bye():
    print("bye bye")

#hello()
bye()

hello2 = my_decorator(hello)
hello2()
print('////////////////////////////////')
from time import time

def performance(func):
    def wrap_func(*args, **kwargs):
        t1 = time()
        result = func(*args, **kwargs)
        t2 = time()
        print(f'took {t2- t1} s')
        return result
    return wrap_func


@performance
def longtime():
    for i in range(1000):
        i*5

longtime()

# Create an @authenticated decorator that only allows the function to run is user1 has 'valid' set to True:
user1 = {
    'name': 'Sorna',
    'valid': True
}

def authenticated(fn):
  def wrapper(*args, **kwargs):
    if args[0]['valid']:
        return fn(*args, **kwargs)
  return wrapper

@authenticated
def message_friends(user):
    print('message has been sent')

message_friends(user1)

# Create an @authenticated decorator that only allows the function to run is user1 has 'valid' set to True:
user1 = {
    'name': 'Sorna',
    'valid': True #changing this will either run or not run the message_friends function.
}

def authenticated(fn):
  def wrapper(*args, **kwargs):
      if args[0]['valid']:
          return fn(*args, **kwargs)
  return wrapper

@authenticated
def message_friends(user):
    print('message has been sent')

message_friends(user1)