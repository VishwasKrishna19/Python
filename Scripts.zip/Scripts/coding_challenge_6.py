# Question 20
### **Question:**
'''
>***Define a class with a generator which can iterate the numbers, which are divisible by 7, between a given range 0 and n.***
----------------------
### Hints:
>***Consider use class, function and comprehension.***
'''

class Divisor():
    def divide(self, num):
        for i in range(num+1):
            if i % 7 == 0:
                yield i

d1 = Divisor()
d2 = d1.divide(7)
for n in d2:
    print(n)

# Question 21
### **Question:**
'''
>***A robot moves in a plane starting from the original point (0,0). The robot can move toward UP, DOWN, LEFT and RIGHT with a given steps. The trace of robot movement is shown as the following:***
UP 5
DOWN 3
LEFT 3
RIGHT 2
>***The numbers after the direction are steps. Please write a program to compute the distance from current position after a sequence of movement and original point. If the distance is a float, then just print the nearest integer.***
***Example:***
***If the following tuples are given as input to the program:***
UP 5
DOWN 3
LEFT 3
RIGHT 2
>***Then, the output of the program should be:***
'''
import  math

# x,y = 0,0
# while True:
#     s = input().split()
#     if not s:
#         break
#     if s[0]=='UP':                  # s[0] indicates command
#         x-=int(s[1])                # s[1] indicates unit of move
#     if s[0]=='DOWN':
#         x+=int(s[1])
#     if s[0]=='LEFT':
#         y-=int(s[1])
#     if s[0]=='RIGHT':
#         y+=int(s[1])
#                                     # N**P means N^P
# dist = round(math.sqrt(x**2 + y**2))  # euclidean distance = square root of (x^2+y^2) and rounding it to nearest integer
# print(dist)

# Question 22
### **Question:**
'''
>***Write a program to compute the frequency of the words from the input. The output should output after sorting the key alphanumerically.***
>***Suppose the following input is supplied to the program:***
New to Python or choosing between Python 2 and Python 3? Read Python 2 or Python 3.
>***Then, the output should be:***
2:2
3.:1
3?:1
New:1
Python:5
Read:1
and:1
between:1
choosing:1
or:2
to:1
'''
inputstr = "New to Python or choosing between Python 2 and Python 3? Read Python 2 or Python 3."
inputstr = inputstr.split(' ')
dict= {}
for eachstr in inputstr:
    eachstr = dict.setdefault(eachstr, inputstr.count(eachstr))

# print(dict)
dict = sorted(dict.items())
for i in dict:
    print("%s:%d"%(i[0],i[1]))

print('************************************')
in1 = sorted(inputstr)
# print(in1)
# print(in1.count('Python'))
lis2 = []
for eachelement in in1:
    new1 = in1.count(eachelement)
    newstr = eachelement + ":" + str(new1)
    lis2.append(newstr)

newset = set(lis2)
lis3 = list(newset)
lis4 = sorted(lis3)

for eachelement1 in lis4:
    print(eachelement1)

# Question 23
### **Question:**
'''
>***Write a method which can calculate square value of number***
----------------------
### Hints:
Using the ** operator which can be written as n**p where means n^p
'''

def square(num):
    squ = num ** 2
    return squ

print(square(4))


# Question 24

### **Question:**
'''
>***Python has many built-in functions, and if you do not know how to use it, you can read document online or find some books. But Python has a built-in document function for every built-in functions.***
>***Please write a program to print some Python built-in functions documents, such as abs(), int(), raw_input()***
>***And add document for your own function***
### Hints: 
The built-in document method is __doc__
'''
print(pow.__doc__)
print(str.__doc__)

# Question 25
### **Question:**
'''
>***Define a class, which have a class parameter and have a same instance parameter.***
'''

class Company:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def fullname(self):
        return True

emp1 = Company('Vishwas', 31)
print(emp1.name)

# Question 26

### **Question:**
'''
>***Define a function which can compute the sum of two numbers.***
'''
def sumoftwo(a,b):
    return a+b

print(sumoftwo(3,6))

sum = lambda n1,n2 : n1 + n2
print(sum(1,2))

# Question 30
### **Question:**
#>***Define a function that can accept two strings as input and print the string with maximum length in console. If two strings have the same length, then the function should print all strings line by line.***
#----------------------
#### Hints:
#>***Use len() function to get the length of a string.***

intstrvar1 = "test123"
intstrvar2 = "test123"

if len(intstrvar1) > len(intstrvar2):
    print(intstrvar1)
elif len(intstrvar2) > len(intstrvar1):
    print(intstrvar2)
else:
    print(intstrvar1 + '\n' + intstrvar2)