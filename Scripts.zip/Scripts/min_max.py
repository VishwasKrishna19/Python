print(min(2,1,3)) #Returns 1
print(min(3.14,-1.5,-300)) #Returns -300
print(max(2,1,3)) #Returns 3
print(max(3.14,-1.5,-300)) #Returns 3.14