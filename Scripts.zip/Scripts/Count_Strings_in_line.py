import collections
import os
import codecs

def word_count(str):
    counts = dict()
    words = str.split()

    for word in words:
        if word in counts:
            counts[word] += 1
        else:
            counts[word] = 1

    if (counts == 2):
        print(counts)

    return counts


cppread = input("Drag and Drop the folder Containing Summaries: ")
os.getcwd()
for root, dirs, files in os.walk(cppread):
        for file in files:
            if file.endswith(".cpp"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as cpp:
                    for line in cpp:
                        if 'VCAST_BRANCH_INSTRUMENTATION_POINT_BUFFERED' in line:
                            #results = collections.Counter("VCAST_BRANCH_INSTRUMENTATION_POINT_BUFFERED")
                            #print(results)
                            word_count("VCAST_BRANCH_INSTRUMENTATION_POINT_BUFFERED")




