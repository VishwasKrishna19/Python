#*********************************************************************
# Utility to convert WINBOSS BTS Scripts to HMATS PYTHON Scripts
# Author: Karthik Harivasahan
#*********************************************************************

import string
from os import listdir
from os.path import isfile, join

import csv, sys

def find_signal_type(signal_name):
        #print "Going to fetch the type of the signal", signal_name, len(signal_name)
        flag = 0
        filename = "data_dictionary.csv"
        reader = csv.reader(open(filename, "rb"))
        for row in reader:
                if row == '':
                        print "row is empty"
                else:
                        #print "I am here", row[0]
                        label_par = row[0]
                        label_par = label_par.upper()
                        signal_name = signal_name.upper()
                        if ((label_par) == (signal_name)):
                                signal_type = row[1]
                                #print "Label Name:",label_par
                                #print "Signal Type:",signal_type
                                flag = 1
                                return signal_type
        if (flag == 0):
                print "##############################################"
                print "SIGNAL NOT FOUND IN DICTIONARY :",signal_name
                print "##############################################"


current_working_directory = '.\\bts_directory'
onlyfiles = [f for f in listdir(current_working_directory) if (f.endswith('.BTS') or f.endswith('.bts'))]
total_files = len(onlyfiles)
z=0

dict = {}
testcase_list = []
test_flag = 0
def_test_case_flag = 0

while z<total_files:
        onlyfiles[z] = onlyfiles[z].upper()
        onlyfiles[z] = onlyfiles[z].replace(".BTS","")

        Infilepath = '.\\bts_directory\\' + onlyfiles[z] +'.BTS'
        Outfile = '.\\py_directory\\' + onlyfiles[z] + '.PY'
        fw = open(Outfile,"w+")

        fd = open(Infilepath,"r")
        line = fd.readline()

        while line:
                length = len(line)
                line1 = line.upper()
                splitted_words = line1.split()
                splitted_words_length = len(splitted_words)

                if (splitted_words_length == 0 and test_flag == 0):
                        test_flag = 1
                if (splitted_words_length >= 1 and splitted_words[0] == "//" ):
                        if (test_flag == 0):
                                line2 = line1.replace("//", "##", 1)
                                fw.write(line2)
                        if (splitted_words_length == 4 and splitted_words[1] == "TEST" and splitted_words[2] == "CASE" and (line1.find("END")==-1)):
                                def_test_case_flag = 1
                                #print"line:", line1

                elif ((splitted_words_length == 2 and splitted_words[0] == "INCLUDE") or
                        (splitted_words_length >= 3 and splitted_words[0] == "USE" and splitted_words[1] == "SCRIPT")):
                        #print "#######INCLUDE SENTENCE:", splitted_words[1]
                        if (line1.find("PROGRAMSCRIPTS") != -1):
                                words2 = line1.split("\\")

                                if (splitted_words_length > 3):
                                        words3 = words2[1].split()
                                        words2[1] = words3[0]
                                        #print "Parsed Data", words2[1]

                                #print "#######INCLUDE SENTENCE:", words2[1]
                                if(words2[1] == "$AC_TYPE$_INIT.BTS\n"):
                                        words2[1] = "BIMMR_Init.BTS"
                                line2 = words2[1].replace(".BTS", " ", 1)
                                line2 = line2.strip()
                                line3 = line2[0]+line2[1]
                                dict[line2]=line3
                        else :
                                #print "words2", splitted_words[1]
                                line2 = splitted_words[1].replace(".BTS", " ", 1)
                                line2 = line2.strip()
                                line3 = line2[0]+line2[1]
                                dict[line2]=line3

                line = fd.readline()

        print "Dictionary", dict
        fw.write("\n##Include the Program Specific libraries\n")
        index = 0
        for the_key, the_val in dict.iteritems():
                index = index + 1
                dict[the_key] = the_val + str(index)
        #print "Modified Dictionary", dict
        for the_key, the_val in dict.iteritems():
                #print the_key, 'corresponds to', the_val
                fw.write("import " + the_key + " as " + the_val + "\n")

        #reset the local variables
        index = 0
        test_flag = 0

        fw.write("\n##Include the HMATS standard libraries\n")
        fw.write("import Test_harness as TH\n")
        fw.write("import a429comm\n")
        fw.write("import daqcomm\n")
        fw.write("import cvtcomm\n")
        fw.write("import hmatsapp\n")

        fw.write("\n##Include the Python Standard libraries\n")
        fw.write("import os\n")
        fw.write("import sys\n")
        fw.write("import time\n")
        fw.write("import math\n")
        fw.write("import string\n")

        if (def_test_case_flag == 1):
                fw.write("\ndef Test_Driver_Initialize():\n")
                fw.write("  cvtcomm.DISPLAY_ERRORS = 0\n")
                fw.write("  a429comm.DISPLAY_ERRORS = 0\n")
                fw.write("  daqcomm.DISPLAY_ERRORS = 0\n")
                fw.write("  xCvtDriver =cvtcomm.DeviceDriver( )\n")
                fw.write("  xArinc429Driver =a429comm.DeviceDriver( )\n")
                fw.write("  xDaqDriver =daqcomm.DeviceDriver( )\n")
                fw.write("  CVT = xCvtDriver.GetDeviceChannel(0)\n")
                fw.write("  ARINC = xArinc429Driver.GetDeviceChannel(0)\n")
                fw.write("  DAQ = xDaqDriver.GetDeviceChannel(0)\n")

        if(def_test_case_flag == 1):
                fw.write("\ndef Test_Environment_Initialize():\n")
        else:
                temp_word3 = "\ndef " + str(onlyfiles[z]) + "():\n"
                fw.write(temp_word3)

        fd.close()

        fd = open(Infilepath, "r")
        line = fd.readline()
        while line:
                line1 = line.upper()
                splitted_words = line1.split()
                splitted_words_length = len (splitted_words)

                if (splitted_words_length == 0 and test_flag == 0):
                        test_flag = 1

                if (splitted_words_length >= 1 and splitted_words[0] == "//" and test_flag == 1 ):
                        line2 = line1.replace("//", "  ##", 1)
                        fw.write(line2)

                if ((splitted_words_length == 2 and splitted_words[0] == "INCLUDE") or
                            (splitted_words_length >= 3 and splitted_words[0] == "USE" and splitted_words[1] == "SCRIPT")):
                        #print "#######INCLUDE SENTENCE:", splitted_words[1]
                        if (line1.find("PROGRAMSCRIPTS") != -1):
                                line1 = line1.split("\\")

                                #Special Handling for $AC_TYPE$_INIT.BTS, CHANGE_SDI.BTS and ConfigProgramPins.BTS
                                if (splitted_words_length > 3):
                                        words3 = line1[1].split()
                                        if (words3[0] == "CONFIGPROGRAMPINS"):
                                                line1[1] = words3[0]+"("+words3[1]+","+words3[2]+","+words3[3]+","+words3[4]+","+words3[5]+","+words3[6]+","+words3[7]+","+words3[8]+","+words3[9]+").BTS\n"
                                        if (words3[0] == "CHANGE_SDI"):
                                                line1[1] = words3[0]+"("+words3[1]+").BTS\n"
                                if (line1[1] == "$AC_TYPE$_INIT.BTS\n"):
                                        line1[1] = "BIMMR_Init.BTS"

                                line2 = line1[1].replace(".BTS", "()", 1)
                                for the_key, the_val in dict.iteritems():
                                        line3 = line2[:-3]
                                        #print the_key, 'corresponds to', the_val, line3
                                        if (the_key == line3):
                                                fw.write("  " + the_val + "." + line2)
                                        elif (line3.find(the_key)!= -1):
                                                fw.write("  " + the_val + "." + line3 + "\n")
                        else:
                                line2 = splitted_words[1].replace(".BTS", "()\n", 1)
                                #print "words2", line2
                                for the_key, the_val in dict.iteritems():
                                        line3 = line2[:-3]
                                        if (the_key == line3):
                                                fw.write("  " + the_val + "." + line2)

                elif (splitted_words_length == 4 and splitted_words[1] == "TEST" and splitted_words[2] == "CASE" and (line1.find("END")==-1)):
                                splitted_words[3]=splitted_words[3].rstrip("\:")
                                temp_word = "\ndef Test"+splitted_words[3]+"():\n"
                                fw.write(temp_word)
                                #print "TEST CASE", line1, splitted_words[3]
                                def_test_case_flag = 1
                                testcase_list.append ( int(splitted_words[3]) )


                elif (splitted_words_length == 5 and splitted_words[0] == "TERM" and splitted_words[1] == "SEND" and splitted_words[2].lstrip("\"") == "COV"):
                        temp_word = splitted_words[4].split("\\")
                        #print "#######TERM SEND COV:", splitted_words[4], temp_word[0]
                        words2 = "  CVT[" + splitted_words[3] + "] =" + temp_word[0]+"\n"
                        fw.write(words2)

                elif (splitted_words_length == 4 and splitted_words[0] == "TERM" and splitted_words[1] == "SEND" and splitted_words[2].lstrip("\"") == "COD"
                                                                                 and splitted_words[3].rstrip("\\R\"") == "ALL"):
                        words2 = "  CVT.REMOVE_OVERRIDE(ALL)\n"
                        fw.write(words2)

                elif (splitted_words_length == 4 and splitted_words[0] == "VIEWS2" and splitted_words[1] == "SEND" and splitted_words[2].lstrip("\"") == "COD"
                                                                                 and splitted_words[3].rstrip("\\R\"") != "ALL"):
                        words2 = "  CVT.REMOVE_OVERRIDE("+splitted_words[3].rstrip("\\R\"")+")\n"
                        #print "###COD CVT SIGNAL:###", words2
                        fw.write(words2)

                elif (splitted_words_length == 1 and splitted_words[0].startswith("/")== 1):
                        splitted_words[0] = splitted_words[0].lstrip("/")
                        words2 = "  "+ splitted_words[0] + "\n"
                        words4 = splitted_words[0].split("=")
                        words4[0] = "  global " + words4[0] + "\n"
                        #print "###Set Global Data ###", splitted_words[0], words2, words4[0]
                        if(len(words2) != 3): #to awoid writing spaces in the test_environment_initialize
                                fw.write(words4[0])
                                fw.write(words2)

                elif (splitted_words_length == 3 and splitted_words[0] == "SET"):
                        temp_word3 = splitted_words[1].split(".")
                        #print "Line", line1, temp_word3
                        if(temp_word3[0] != "RF2" and temp_word3[0] != "RF1"):
                                type = find_signal_type(splitted_words[1])
                                words2 = "  "+type+"[" + splitted_words[1] + "] =" + splitted_words[2] + "\n"
                                #print "###SET SIGNAL:###", words2
                                fw.write(words2)
                        else:
                                line1 = line1.rstrip("\n")
                                words2 = "  OS.System (" + line1 + ")\n"
                                # print "###SET SIGNAL:###", words2
                                fw.write(words2)

                elif (splitted_words_length == 7 and splitted_words[0] == "SET" and splitted_words[2] == "UPDRAT"):
                        type = find_signal_type(splitted_words[1])

                        words2 = "  "+type+"[" + splitted_words[1] + ".RATE] =" + splitted_words[3] + "\n"
                        fw.write(words2)

                        if (splitted_words[4] == "TEST"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".SSM] =" + "0" + "\n"
                                fw.write(words2)
                        if (splitted_words[4] == "NORM"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".SSM] =" + "1" + "\n"
                                fw.write(words2)
                        if (splitted_words[4] == "NCD"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".SSM] =" + "2" + "\n"
                                fw.write(words2)
                        if (splitted_words[4] == "FAIL"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".SSM] =" + "3" + "\n"
                                fw.write(words2)


                        if (splitted_words[5] == "SDI0"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".SDI] =" + "0" + "\n"
                                fw.write(words2)
                        if (splitted_words[5] == "SDI1"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".SDI] =" + "1" + "\n"
                                fw.write(words2)
                        if (splitted_words[5] == "SDI2"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".SDI] =" + "2" + "\n"
                                fw.write(words2)
                        if (splitted_words[5] == "SDI3"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".SDI] =" + "3" + "\n"
                                fw.write(words2)


                        if(splitted_words[6] == "ODD"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".PARITY] =" + "1" + "\n"
                                fw.write(words2)
                        if (splitted_words[6] == "EVEN"):
                                words2 = "  " + type + "[" + splitted_words[1] + ".PARITY] =" + "2" + "\n"
                                fw.write(words2)


                elif ((splitted_words_length == 5 or splitted_words_length == 6) and splitted_words[0] == "TEST" and splitted_words[1] == "IF"):
                        if(splitted_words[3]=='EQ'):
                                type = find_signal_type(splitted_words[2])
                                #print "type of the signal:", type
                                fw.write("  TH.VERIFY ("+type+"["+splitted_words[2]+"]"+", "+splitted_words[4]+", \"verification of signal:\")")
                                fw.write("\n")
                        if (splitted_words[3] == 'NE'):
                                type = find_signal_type(splitted_words[2])
                                # print "type of the signal:", type
                                fw.write("  TH.VERIFYNE (" +type+"["+splitted_words[2]+"]"+", "+splitted_words[4]+", \"verification of signal:\")")
                                fw.write("\n")
                        if (splitted_words[3] == 'IN'):
                                type = find_signal_type(splitted_words[2])
                                # print "type of the signal:", type
                                fw.write("  TH.VERIFYRANGE (" +type+"["+splitted_words[2]+"]"+", "+splitted_words[4]+", "+splitted_words[5]+", \"verification of signal:\")")
                                fw.write("\n")


                elif (splitted_words_length == 8 and splitted_words[0] == "TEST" and splitted_words[1] == "IF" and splitted_words[5] == "DC"):
                        if(splitted_words[3]=='EQ'):
                                type = find_signal_type(splitted_words[2])
                                splitted_words[6] = "0x"+splitted_words[6]
                                splitted_words[4] = "0x" + splitted_words[4]
                                #print "####Verification line", line1
                                temp_word2 = "  temp_val = " + type + "[" + splitted_words[2] + ".word]\n"
                                fw.write(temp_word2)
                                temp_word2 = "  arinc_word_val = temp_val & " + splitted_words[6] + "\n"
                                fw.write(temp_word2)
                                #words2 = int(splitted_words[4]) & temp_word
                                temp_word2 = "  TH.VERIFY ( arinc_word_val, " + (splitted_words[4]) + ", \" Verification of signal:\")\n"
                                fw.write(temp_word2)

                elif ( (splitted_words_length >= 7 and splitted_words[0] == "TEST" and splitted_words[1] == "COUNT") or
                               (splitted_words_length == 6 and splitted_words[0] == "TEST" and splitted_words[1] == "COUNTER")):
                        fw.write ("  ##******** HMATS IS NOT SUPPORTED TO VERIFY RATE OF ARINC TRANSMISSION********\n")


                elif (splitted_words_length == 2 and splitted_words[0] == "DELAY"):
                        time_in_seconds = float(splitted_words[1])/1000
                        #print "time_in_seconds",time_in_seconds
                        words2 = "  TH.PAUSE("+str(time_in_seconds)+")"+"\n"
                        #print "words2", words2
                        fw.write(words2)

                elif (splitted_words_length == 2 and splitted_words[0] == "LOG"):
                        type = find_signal_type(splitted_words[1])
                        #print "type of the signal:", type
                        words2 = "  "+type+".LOG"+"("+splitted_words[1]+")"+"\n"
                        #print "words2", words2
                        fw.write(words2)

                line = fd.readline()

        if(def_test_case_flag == 1):
                #Define RunTest
                fw.write("\n\ndef TestExecutor():\n")
                fw.write("  Test_Driver_Initialize()\n")
                fw.write("  Test_Environment_Initialize()\n")
                for index in range(len(testcase_list)):
                        temp_word = "  Test"+str(testcase_list[index])+"()\n"
                        #print "Test Case", temp_word
                        fw.write(temp_word)
                fw.write("\n")
                #Define main function
                fw.write("if __name__ == '__main__':\n")

                file_name = onlyfiles[z] + ".log"
                description = "Verify the values are set as per requirements."
                command = '  TH.RunTest(TestExecutor, "' + file_name + '","' + description + '",True,True)\n'
                fw.write(command)


        fd.close()    #close the file
        fw.close()    #close the file
        test_flag = 0
        index = 0
        dict.clear()
        def_test_case_flag = 0
        while len(testcase_list) > 0: testcase_list.pop()
        z+=1

