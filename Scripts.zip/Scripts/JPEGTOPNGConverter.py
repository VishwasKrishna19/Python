from PIL import Image, ImageFilter
import sys
import os

#grab the first and second Argument
path = sys.argv[1]
directory = sys.argv[2]

#Check if folder exists, if not create it
if not os.path.exists(directory):
    os.makedirs(directory)

# Loop throught the input folder and Convert to PNG
for filenames in os.listdir(path):
    cleanname = os.path.splitext(filenames)[0]
    img = Image.open(f'{path}{filenames}')

#Save it to the New
    # added the / in case user doesn't enter it. You may want to check for this and add or remover it.
    img.save(f'{directory}/{cleanname}.png', 'png')
    print('all done!')
