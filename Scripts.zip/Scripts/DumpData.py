import os
import csv
import codecs
import re
import glob


def getfilelist(path):
    files = glob.glob(os.path.join(path, '*.*'))
    #print(files)
    XML_files = [x for x in files if os.path.splitext(x)[1].lower() == '.idl_xml']
    #print(XML_files)
    return XML_files


def get_xml_data(file):
    groupName = ""
    with codecs.open(file, "r", encoding='UTF8', errors='ignore') as XML_FileName:
        filename = os.path.basename(file)
        for line in XML_FileName:
            print(line)
            if (line.__contains__('<group name')):
                groupName = line.rstrip('\n')
                groupName = groupName.lstrip('\n')
                #print(groupName)

        return [filename, groupName]



def write_to_file(XML_Dump_Data):
    with open("Dump_data.txt", 'w', newline='', encoding="utf-8") as xml_dump_details:
        w = csv.writer(xml_dump_details)
        w.writerow(
            ["FileName", "line", "group_name", "trace_tag", "Hash_name", "element_tag", "line_number"])
        for data in XML_Dump_Data:
            w.writerow(data)


if __name__ == '__main__':
    if os.path.exists('Dump_data.txt'): os.remove('Dump_data.txt')
    XML_path = input("Drag and Drop the folder Containing XML Files: ")
    XML_files = getfilelist(XML_path)
    XML_Dump_Data = []
    for file in XML_files:
        XML_Dump_Data.append(get_xml_data(file))

    # write to file
    write_to_file(XML_Dump_Data)


'''import os

XMLRead = input("Drag and Drop the root folders of the XML or Enter the full folders Name with path: ")
os.getcwd()

if os.path.exists('Dump_data.txt'): os.remove('Dump_data.txt')
for root, dirs, files in os.walk(XMLRead):
        for file in files:
            if file.endswith(".IDL_XML") or file.endswith(".idl_xml"):
                with open(os.path.join(root, file), "r", encoding="utf-16") as DatadmpInpt:
                    with open('TraceTagList.txt', 'a') as DatadmpOtpt:
                        for XMLlines in DatadmpInpt: '''
                            
