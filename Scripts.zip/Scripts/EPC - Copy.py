import os
import codecs

pythonpath = "C:\\Vishwas\\Task_Assigned\\Python\\Prem\\Database\\PY\\Test\\"
#pythonpath = input("Drag and drop the folder containing testfile : ")
symbolpath = "C:\\Vishwas\\Task_Assigned\\Python\\Prem\\Database\\STB\\"
#symbolpath = input("Drag and drop the folder containing Symbols : ")

allfiles = []
symbollist = []
symbollistdb = []
prevline = ""
prevlinedata = ""
symb_arr = []

def getallfiles():
    for root, dirs, files in os.walk(pythonpath):
        #print(files)
        for file in files:
             if file.endswith('.py') or file.endswith('.PY'):
                file_s = os.path.join(root, file)
                allfiles.append(file_s)

def convert_array_Value(symbols):
    print(prevlinedata)
    symbol_array = symbols
    print(symbol_array)
    if ',' in prevlinedata:
        data1 = prevlinedata.split(',')[0]
        data2 = prevlinedata.split(',')[1]
        if ',' in data2:
            data2 = data2.split(',')[0]
        #print(data1, data2)
        data1_status = data1.strip().isnumeric()
        data2_status = data2.strip().isnumeric()
        if data1_status and data2_status:
            for i in range(int(data1), int(data2)):
                symbols_array = symbol_array.replace('%d', "% s" %i)
                symb_arr.append(symbols_array)
                #print(symbols_array)
    else:
        data3_status = prevlinedata.isnumeric()
        if data3_status:
            for i in range(int(prevlinedata)):
                symbols_array = symbol_array.replace('%d', "% s" % i)
                symb_arr.append(symbols_array)
        else:
            symbols_array = symbol_array.split('[')[0]
            symb_arr.append(symbols_array)
    print(symb_arr)
    return symb_arr

def symbollistpopulate():
    for root, dirs, files in os.walk(symbolpath):
        for file in files:
            if file.endswith('.stb'):
                with open(os.path.join(root, file), 'r') as fileopen:
                    for eachval in fileopen:
                        symbollistdata = eachval.split(' ')[0]
                        #print(symbollistdata)
                        symbollistdb.append(symbollistdata)

getallfiles()

for eachfile in allfiles:
    filename = eachfile.split('\\')[-1]
    print(f'processsing.. {filename}')
    with codecs.open(eachfile, 'r', encoding='UTF-8') as fileread:
        for eachline in fileread:
            if 'for' in eachline and 'in range' in eachline:
                prevlinedata = eachline.split('(')[1].split(')')[0]
                #print(prevlinedata)
            if 'TH.NGC' in eachline:
                if '\"' in eachline:
                    symbols = eachline.split('\"')[1]
                    symbols = symbols.split('\"')[0]
                elif '\'' in eachline:
                    symbols = eachline.split('\'')[1]
                    symbols = symbols.split('\'')[0]
                else:
                    symbols = ""
                if '%d' in symbols:
                    temp = convert_array_Value(symbols)
                    symbollist = symbollist + temp
                else:
                    symbollist.append(symbols)

symbollist = [x.upper() for x in symbollist]
set_from_file = set(symbollist)
symbollistpopulate()
symbollistdb = [x.upper() for x in symbollistdb]
set_from_db = set(symbollistdb)


Missed_in_symboldb = set_from_file.difference(set_from_db)
Missed_in_symboldb = set([x for x in list(Missed_in_symboldb) if x])

fw = open('Missed_in_database.txt', 'w')
if len(Missed_in_symboldb) != 0:
    fw.write('Below symbols missed in the Database:' + '\n')
    for eachval in Missed_in_symboldb:
        fw.write(eachval + '\n')
else:
    fw.write('There is no symbols missed in the Database:' + '\n')

fw.close()
print('Completed Processing')

