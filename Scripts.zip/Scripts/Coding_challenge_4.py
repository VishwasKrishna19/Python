#Phone Number identify in long Method
#phonenumber : 456-123-5555

def isPhonenumber(text):
    if len(text) != 12:
        return False #as its not the Phone Number size'
    for i in range(0,3):
        if not text[i].isdecimal():
            return False # first 3 digits is not decimal
    if text[3] != '-':
        return False
    for i in range(4,7):
        if not text[i].isdecimal():
            return False # No first 3 Digits
    if text[7] != '-':
        return False
    for i in range(8, 12):
        if not text[i].isdecimal():
            return False
    return True

print(isPhonenumber('961-110-7396'))

message = 'call me at 452-555-98889 or else call me at asadsadasd 244-655-55444'
foundnumber = False
for i in range(len(message)):
    chunk = message[i:i+12]
    if isPhonenumber(chunk):
        print('phne number found :'+ chunk )
        foundnumber = True

if not foundnumber:
    print('could not find any phone number')

#using Regular Expression:
import re

phonenumberpattren = re.compile(r'[\d]{3}-[\d]{3}-[\d]{5}')

matchobject = phonenumberpattren.findall(message)
matchobject = phonenumberpattren.search(message)
print(matchobject.group())
