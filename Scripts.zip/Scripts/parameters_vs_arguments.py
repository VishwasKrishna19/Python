def ask_something(something):
    print(something)



ask_something("What is your quest?")