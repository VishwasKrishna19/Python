import os
import codecs
import chardet


XMLRead = input("Drag and Drop the root folders of the XML or Enter the full folders Name with path: ")
os.getcwd()
if os.path.exists('TraceTagList.txt'): os.remove('TraceTagList.txt')
for root, dirs, files in os.walk(XMLRead):
        for file in files:
            if file.endswith(".IDL_XML") or file.endswith(".idl_xml"):
                with codecs.open(os.path.join(root, file), "r", encoding="utf-16-le") as auto:
                    with open('ElementTag.txt', 'a') as wf:
                        for XMLlines in auto:
                            if XMLlines.__contains__('elementhashname="'):
                                tracetag = XMLlines.split('elementhashname="')[1]
                                tracetag = tracetag.split("\"")[0]
                                print(tracetag)
                                wf.write(file + "," + tracetag + '\n')