fruit = ['apple','orange','banana','pear','lemon','watermelon']

first_fruit = fruit[0]
#apple
print(first_fruit)

last_fruit = fruit[-1]
#watermelon
print(last_fruit)

fifth_fruit = fruit[4]
#lemon
print(fifth_fruit)

third_fruit_from_end = fruit[-3]
#pear
print(third_fruit_from_end)