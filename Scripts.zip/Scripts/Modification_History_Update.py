import os
import re

arr_txt = [x for x in os.listdir() if x.endswith(".tsf")]
print (arr_txt)
if(not os.path.exists('Updated')): os.mkdir('Updated')
for i in arr_txt:
    old=i
    #new=i.split('.')[0]+'_updated.tsf'
    new = os.path.join('Updated', i)
    file = open(old)
    ll = []
    # [o,O]utput\s*\"\s*[0-9]+
    count = 0
    ptag_count = 0
    line_num = 0
    y = 0
    temp = 0
    for line in file:
        count = count + 1
        ptag_count = ptag_count + 1
        if re.search("output\s*\"\s*[0-9]", line, re.IGNORECASE):
            line_num = count
        if re.search("output\s*\"\s*['--','==']", line, re.IGNORECASE):
            if (line_num > 0) and (count > line_num) and (temp == 0):
                print(line_num)
                ptag_line_num = count
                temp = 1
    print("lastline " + str(line_num))
    print("==== " + str(ptag_line_num))
    file.close()

    file = open(old)
    file_update = open(new, "w")
    sample_txt = open("sample.txt")
    count = 0
    x = 0
    for line in file:
        count = count + 1
        if (count == ptag_line_num):
            file_update.write("\n")
            for sl in sample_txt:
                file_update.write(sl)
        if (count >= line_num) and (count < ptag_line_num):
            file_update.write("\'" + line)
        else:
            file_update.write(line)



