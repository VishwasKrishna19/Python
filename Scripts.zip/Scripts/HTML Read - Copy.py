import os
import sys
import fileinput
import re
import pandas
import pandas as pd
from numpy import*
import csv

#Logic to Convert HTML TO TEXT FILE
with open("C:/Users/h126313/Desktop/NG/Reports/TgfDspFMS.idb.html") as html:
    with open("C:/Users/h126313/Desktop/NG/XML1.txt", "w") as fs:
        for line1 in html:
            fs.write(line1)

#Read Text File and and write required Data as Elementhash name and Stats(Executed or Not_Executed)in XML2.txt
with open("C:/Users/h126313/Desktop/NG/XML1.txt", "r") as f:
    with open("C:/Users/h126313/Desktop/NG/XML2.txt", "w") as wf:
        for line in f:
            if '<th> Trace Tags Name' in line:
                if '<td align="center">' in line:
                    line = line.split("<td align=\"center\">", 1)[1]
                    user = re.findall(r'(?:<tr><td>|.html">)([A-F0-9]{8})', line)
                    user1 = re.findall(r'<td align="center">([EXECUTEDNot_Executed]+)', line)
                    new_list = []
                    if len(user1) != len(user):
                        print ('list length mismatch')
                    else:
                        for each in range(0, len(user1)):
                            new_list.append(user[each] + "  " +  str(user1[each]))
                    wf.write("\n".join(new_list))

#Read XML2.txt and Split the Executed Count and Total count in XML2_2.txt and XML2_1.txt respectively
with open("C:/Users/h126313/Desktop/NG/XML2.txt") as f1:
    with open("C:/Users/h126313/Desktop/NG/XML2_1.txt", "w") as wf:
        with open("C:/Users/h126313/Desktop/NG/XML2_2.txt", "w") as wf1:
            lis = []
            lis1 = []
            for line in f1:
                line = line.rstrip('\n')
                XML = line.split('  ')
                lis.append(XML[0])
                lis1.append(XML[1])
            df = pd.DataFrame({'Status':lis1, 'XML_Name' : lis})
            df1 = df[df.Status != 'Not_Executed']
            group = df1.groupby(['XML_Name', 'Status']).size()
            group1 = df.groupby(['XML_Name']).size()
            wf.write(str(group1))
            wf1.write(str(group))

#Read XML2_2.txt and XML2_1.txt and write the matched count data in Final_Count.txt
with open("C:/Users/h126313/Desktop/NG/XML2_1.txt") as f2:
    with open("C:/Users/h126313/Desktop/NG/XML2_2.txt") as f3:
        with open("C:/Users/h126313/Desktop/NG/Final_Count.txt", "w") as fs:
            line2 = f2.readlines()
            line3 = f3.readlines()
            for Total_count_line in line2:
                if 'XML_Name' not in Total_count_line or 'dtype:' not in Total_count_line:
                    Total_count_line_1 = re.sub(' +',' ',Total_count_line)
                    Total_count_line_1 = Total_count_line_1.rstrip('\n')
                    Total_count_line_1 = Total_count_line_1.split(" ")[0]
                    temp = Total_count_line.split(" ")[-1]
                    Total_count_line = Total_count_line_1 + "," + temp
                    Total_count_line = Total_count_line.rstrip('\n')
                for Executed_line_count in line3:
                    if Executed_line_count.startswith(Total_count_line_1):
                        Executed_line_count = Executed_line_count.rstrip('\n')
                        Executed_line_count = Executed_line_count.split(" ")[-1]
                        break
                    else:
                        Executed_line_count = 0
                fs.write(Total_count_line + "," + str(Executed_line_count) + '\n')

#Read Final_Count.txt and map to the respective XML name and Calculatte the Percentage
with open("C:/Users/h126313/Desktop/NG/Final_Count.txt") as f4:
    with open("C:/Users/h126313/Desktop/NG/Dump_data.txt") as f5:
        with open("C:/Users/h126313/Desktop/NG/Final_XML_DATA.csv", "w") as fp:
            fp.write("XML_NAME,ELEMENTHASH_NAME,TOTAL_TAGS_COUNT,EXECUTED_TAG_COUNT,PERCENT_COVERAGE\n")
            line4 = f4.readlines()
            line5 = f5.readlines()
            for count_line in line4:
                if count_line.__contains__('XML_Name') or count_line.__contains__('dtype:')or count_line.__contains__('Length:'):
                    continue
                count_line_1 = count_line.rstrip('\n')
                count_line_1 = count_line_1.split(",")[0]
                countline = int(count_line_1, 16)
                countline = str(countline)
                Executed_Count = count_line.split(",")[-1]
                Executed_Count = Executed_Count.rstrip('\n')
                Total_Count = count_line.split(",")[-2]
                Total_XML_Percentage = (int(Executed_Count)/int(Total_Count))*100
                Total_XML_Percentage = str(Total_XML_Percentage).rstrip('\n')
                countline = countline.rstrip('\n')
                count_line = count_line.rstrip('\n')
                for Dump_data in line5:
                    if Dump_data.__contains__(countline):
                        Dump_data = Dump_data.rstrip('\n')
                        Dump_data = Dump_data.split(",")[0]
                        break
                fp.write(Dump_data + "," + count_line + "," + Total_XML_Percentage + '\n')