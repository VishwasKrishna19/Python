#Series: its a Single Dimensional Array

import numpy as np
import pandas as pd

s = ([1, np.nan, ' Pandas Library'])
s1 = pd.Series(s)
print(s1)
s2 = np.array([2, np.nan, 'b'])
s2 = pd.Series(s2)
print(s2)