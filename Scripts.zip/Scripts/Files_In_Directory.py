import os
f = open('names.txt', 'w')

for root, dirs, files in os.walk('C:\Vishwas\TASKS_ASSIGNED\Verification_Deliverables\Baseline_Files\EDS_TSC_GVII_01_001\EDS_TSC_GVII_01_001_TEST-BL_0'):
	for newname in files:
		filename = os.path.join(newname)
		newstring = filename + '\n'
if newstring.endswith(".tsf"):
		f.write(newstring)
		
		