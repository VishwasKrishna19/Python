"""
__version__ = "$Revision: 1.3 $"
__date__ = "$Date: 2003/07/09 02:08:02 $"
"""

from PythonCardPrototype import model

#
# VB constants
True = 1
False = 0

class MAINFORM(model.Background):
    """The main form for the application"""

    def on_btnClose_mouseClick(self, event):
        """Sub"""
        
        Unload Me

        
if __name__ == '__main__':
    app = model.PythonCardApp(MAINFORM)
    app.MainLoop()
