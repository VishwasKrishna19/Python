from sample_main_module import testval

var1 = testval(1, 2, 0)
var2 = testval(1, 2, 1)
print(var1)
print(var2)