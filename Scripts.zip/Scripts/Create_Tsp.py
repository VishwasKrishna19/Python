import string
import os
import sys
import re
import shutil

fileListName = "C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\FileList.txt"
fileList = open(fileListName, "r")

while True:
    fileLine = fileList.readline()
    lineLength = len(fileLine)
    if fileLine == '':
        break
    else:
        tsfFileNameWithExt = fileLine[0:17]
        tsfFileNameWithoutExt = fileLine[0:13]

        if (os.path.exists(tsfFileNameWithoutExt) != True):
            os.mkdir(tsfFileNameWithoutExt)

        if (os.path.exists("/" + tsfFileNameWithoutExt + "/" + tsfFileNameWithExt) != True):
            shutil.copyfile("C:/Vishwas/TASKS_ASSIGNED/TSC2_0/Python_Tools_TSC2/Create_TSp/HLR/" + tsfFileNameWithExt,
                            tsfFileNameWithoutExt + "/" + tsfFileNameWithExt)

        tsfFile = open(tsfFileNameWithoutExt + "/" + tsfFileNameWithExt, "r")
        tspFile = open(tsfFileNameWithoutExt + "/" + tsfFileNameWithoutExt + ".tsp", "w")
        configFile = open(tsfFileNameWithoutExt + "/" + "Config_file.txt", "w")

        tspFile.write("1.0")
        while True:
            tsfLine = tsfFile.readline()

            if ("DEFINE " in tsfLine):
                break
            else:
                if (".tsf" in tsfLine):
                    tsfLine.lstrip()
                    re.sub('[^a-zA-Z-_*.]', '', tsfLine)
                    tsfLine.lstrip()
                    tsfWord = tsfLine.split('.')
                    print(tsfWord)
                    tspFile.write("\n")
                    if (tsfFileNameWithoutExt in tsfWord[1]):
                        tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\\" +tsfFileNameWithoutExt+ "\\" + tsfWord[1].lstrip() + ".tsf\"")
                    else:
                        tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\\" + tsfWord[1].lstrip() + ".tsf\"")
                    if ("QualifiedSupport" in tsfWord[1]):
                        tspFile.write("\n0, 1, 0")
                    else:
                        tspFile.write("\n0, 0, 0")

        configFile.writelines(
            "<Config>\n<g__thisInstance_check>2</g__thisInstance_check>\n<g__thisInstance_path></g__thisInstance_path>\n<TestEnvironment>12</TestEnvironment>\n")
        configFile.writelines("<CtAuto></CtAuto>\n<CtAutoTarget></CtAutoTarget>\n<EASE_WARM>2</EASE_WARM>\n")
        configFile.writelines("<Test_Anchor>" + tsfFileNameWithoutExt + "</Test_Anchor>\n")
        configFile.writelines("<Software_Version>EDS_PRD_TSC2_00_001</Software_Version>\n")
        configFile.writelines(
            "<ExecutorName>Vishwas Krishna</ExecutorName>\n<VC_BCT_Flag_Enabled>1</VC_BCT_Flag_Enabled>\n<TargetName>tsc1</TargetName>\n")
        configFile.writelines(
            "<ResourceName>VECTOR_SPACE_TGF</ResourceName>\n<SC_Variable_Path>dtmon\TscGraphics\vcast_dump_coverage_exe</SC_Variable_Path>\n</Config>")

        tsfFile.close()
        tspFile.close()
        configFile.close()

fileList.close()
