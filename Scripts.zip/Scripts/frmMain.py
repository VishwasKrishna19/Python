"""
__version__ = "$Revision: 1.3 $"
__date__ = "$Date: 2003/07/09 02:08:02 $"
"""

from PythonCardPrototype import model

#
# VB constants
True = 1
False = 0

class MAINFORM(model.Background):
    """The main form for the application"""

    def on_btnChange_mouseClick(self, event):
        """Sub"""
        
        if self.components.chkAdd.checked :
            self.components.txtValue.text = str(self.doAnAdd(int(self.components.txtValue.text), 1))
        elif self.components.chkSub.checked :
            self.components.txtValue.text = str(self.doAnAdd(int(self.components.txtValue.text), -1))
        

    def on_btnDirectHide_mouseClick(self, event):
        """Sub"""
        
        self.components.btnDirectHide.visible = False

    def on_btnDoIt_mouseClick(self, event):
        """Sub"""
        
        self.components.lblLabel.Caption = self.components.txtName.text + self.components.txtSecond.text

    def on_btnHideMe_mouseClick(self, event):
        """Sub"""
        
        #self.HideSomething (self.components.btnHideMe)

    def on_btnSecond_mouseClick(self, event):
        """Sub"""
        
        frmSecond.Show

    def HideSomething(self, btn):
        """Sub"""
        
        btn.Visible = False

    def on_btnZeroIt_mouseClick(self, event):
        """Sub"""
        
        self.components.txtValue.text = "0"

    def on_Command1_mouseClick(self, event):
        """Sub"""
        
        frmRadio.Show

    def doAnAdd(self, Value, Adding):
        """Sub"""
        
        doAnAdd = Value + Adding
        
        return doAnAdd

        
if __name__ == '__main__':
    app = model.PythonCardApp(MAINFORM)
    app.MainLoop()
