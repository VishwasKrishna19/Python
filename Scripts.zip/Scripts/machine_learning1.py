from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics

iris = load_iris()

# X = Inputs
# Y = Outputs in Machine Learning
X = iris.data
y = iris.target
featurename = iris.feature_names
targetnames = iris.target_names

print(featurename)
print(targetnames)
print(type(X))
# f(x) = y

X_train, X_test, y_train, y_test = train_test_split(X,y, test_size = 0.1)
print(X_train.shape)
print(X_test.shape)
#create the Model
knn = KNeighborsClassifier(n_neighbors=4)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)
print(y_pred)
print(metrics.accuracy_score(y_test, y_pred))