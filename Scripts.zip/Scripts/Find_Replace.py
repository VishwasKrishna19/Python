import os
import sys
import fileinput

print("Text to Search For :")
texttosearch = input ("> ")

print("Text to Replace in the File:")
texttoreplace = input("> ")

print("File to Perform Find and Replace (Please provide the path): ")

#filetosearch = input("> ")
filetosearch = 'C:/Users/h126313/Desktop/Python/Shall_to_object/TSD_S15B_0010_Part1.tsf'

tempFile = open(filetosearch, 'r+' )

for line in fileinput.input(filetosearch):
    if texttosearch in line :
        print("Match Found")
    else:
        print("Match Not Found")

    tempFile.write(line.replace(texttosearch, texttoreplace))
tempFile.close()

input ('\n\n Press Enter to Exit....')