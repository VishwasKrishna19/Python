import pandas as pd
import numpy as np
import glob

list_of_Xls = glob.glob("C:\\Vishwas\\Task_Assigned\\TSC2_0\Drop2\\Load_5_5\\Trace\\For_Trace\*.xlsx")
print(list_of_Xls)

all_data = pd.DataFrame()

for f in list_of_Xls:
    df = pd.read_excel(f)
    all_data = all_data.append(df, ignore_index=True)
    all_data = all_data[['ID', 'Object Type', 'Change_Request_ID']]
    print(all_data.describe())
    all_data.head()
    all_data.to_excel("C:\\Vishwas\\Task_Assigned\\TSC2_0\\Drop2\\Load_5_5\\Trace\For_Trace\\Final_Trace1.xlsx")