import os

inputfile1 = input("Drag and drop the input tsf file: ")
os.getcwd()
outputfile1 = "Updated.tsf"
inputfile = open(inputfile1, "r", encoding="utf8", errors='ignore')
outputfile = open(outputfile1, "w", encoding="utf8")
for line in inputfile:
    print(line)
    if line.startswith("PassFail") or line.startswith("Passfail") or line.startswith("passFail") or line.startswith("PASSFAIL"):
        ImageName = line.split('\'')[1]
        ImageName = ImageName.split('\'')[0]
        ImageName = ImageName.replace(" ", "_")
        line = "If GATE_AUTO = 0 Then" + "\n" + line + "Else" + "\n" + "Call SVerify(" + "\"" + ImageName + "\", \"EQ\")" + "\n" + "End If" + "\n"
    outputfile.write(line)