import pandas as pd

df = pd.read_excel('C:\\Vishwas\\Task_Assigned\\Python\\Pandas\\EDS_TSC2_00_002_Consolidated_RA.xlsx')

print(df.head(3))
print(df.tail(3))

#reading the columns
print(df.columns)
print(df[['Shall tag/Object ID', 'Functionality']])
print(df['Test Name'])