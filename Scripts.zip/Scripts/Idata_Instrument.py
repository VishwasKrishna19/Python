import subprocess
import codecs
import os, re
from chardet import detect

srcpath = "C:\\Vishwas\\Task_Assigned\\Initiatives\\IDATA\\tgf_orig"
dstpath = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\IDATA\\Output\\'
command = 'start ' + "robocopy " + srcpath + " " + dstpath + " /E *.IDW_XML *.IDT_XML *.hit *.lwt_xml *.col_xml *.grd_xml"
print(command)
p = subprocess.Popen(command, stdout=subprocess.PIPE, shell = True)
p.communicate()

# get file encoding type
def get_encoding_type(file):
    with open(file, 'rb') as f:
        rawdata = f.read()
    return detect(rawdata)['encoding']

def get_value(key_val, dictionary_name):
    for key, value in dictionary_name.items():
        if key_val == key:
            return value

def get_XML_group_Count(filename):
    if filename in countdict:
        for key, value in countdict.items():
            if filename == key:
                return value
    return False

def get_element_count(key_val):
    for key, value in countdict.items():
        if key_val == key:
            return value

    return "Value doesn't exist"

def main_dictionary_count():
    with codecs.open(os.path.join(root, file), 'r', encoding=from_codec) as f:d
        filedata = f.read()
        tagcount = filedata.count("elementtag=\"")
        # print(file + " , " +  str(tagcount))
        dict[file] = str(tagcount)
    return dict

main_XML = []
countdict = {}
dict = {}
for root, dirs, files in os.walk(srcpath):
    for file in files:
        if file.endswith(".IDL_XML") or file.endswith(".idl_xml"):
            from_codec = get_encoding_type(os.path.join(root, file))
            if (from_codec != 'UTF-8'):
                main_dictionary_count()
print(dict)

for root, dirs, files in os.walk(srcpath):
    xml_group = []
    main_xml = ""
    for file in files:
        destination_folder = dstpath + root.split('\\')[-1] + "\\" + file
        mainxml = False
        parsing = False
        if file.endswith(".IDW_XML") or file.endswith(".idw_xml"):
            from_codec = get_encoding_type(os.path.join(root, file))
            if (from_codec != 'UTF-8'):
                with codecs.open(os.path.join(root, file), 'r', encoding=from_codec) as idwfile:
                    for eachline in idwfile:
                        if '<project name' in eachline:
                            parsing = True
                            mainxml = True
                        if '</project>' in eachline:
                            mainxml = False
                        if '</workspace>' in eachline:
                            parsing = False
                        if parsing:
                            # print(file)
                            # print(eachline)
                            if '<file name=' in eachline:
                                xmlname = re.findall(r'[ \w-]+\.IDL_XML', eachline, re.IGNORECASE)[0]
                                # print(xmlname)
                                xml_group.append(xmlname)
                        if mainxml:
                            if '<file name=' in eachline:
                                main_xml = re.findall(r'[ \w-]+\.IDL_XML', eachline, re.IGNORECASE)[0]
                                main_XML.append(main_xml)

    val = 0
    prevval = 0
    finalval = 0
    print(xml_group)
    for eachlistgroup in xml_group:
        val = get_value(eachlistgroup, dict)
        finalval = int(val) + int(prevval)
        prevval = int(finalval)
        #print(finalval)
    if main_xml and finalval:
        countdict[main_xml] = finalval

print(countdict)




for root, dirs, files in os.walk(srcpath):
    for file in files:
        count = 0
        destination_folder = dstpath + root.split('\\')[-1] + "\\" + file
        #print(destination_folder)
        if file.endswith(".IDL_XML") or file.endswith(".idl_xml"):
            from_codec = get_encoding_type(os.path.join(root, file))
            if (from_codec != 'UTF-8'):
                with codecs.open(os.path.join(root, file), 'r', encoding=from_codec) as f:
                    with codecs.open(destination_folder, 'w', encoding=from_codec) as fw:
                        filename = f.name.split("\\")[-1]
                        xmlgroupcount = get_XML_group_Count(filename)
                        #print(f'{filename} - {xmlgroupcount}')
                        for eachxmlline in f:
                            if 'elementtag="' in eachxmlline:
                                pattren = re.search(r'elementtag="(\d+)"', eachxmlline)
                                if xmlgroupcount != False and int(xmlgroupcount) > 9999:
                                    element_tag = "elementtag=\"" + str(hex(count)) + "\""
                                else:
                                    element_tag = "elementtag=\"" + str(count) + "\""
                                eachxmlline = eachxmlline.replace(pattren.group(), element_tag)
                                count += 1
                            if 'externalgroup name=\"' in eachxmlline and 'filename=\"' in eachxmlline:
                                newxmlsearch = re.findall(r'[ \w-]+\.IDL_XML', eachxmlline, re.IGNORECASE)[0]
                                elementtag_incr = get_value(newxmlsearch, dict)
                                count =  count + int(elementtag_incr)
                                #print(f'{newxmlsearch}- {elementtag_incr}')
                            if 'elementoptions elementindexvalue="' in eachxmlline:
                                 ptrn1 = re.search(r'elementindexvalue="(\d+)"', eachxmlline)
                                 if filename in countdict.keys():
                                     #print(filename)
                                     elementtagcount = get_element_count(filename)
                                     #print(elementtagcount)
                                 else:
                                    elementtagcount = get_value(filename, dict)
                                 #print(elementtagcount)

                                 if xmlgroupcount != False and int(xmlgroupcount) > 9999:
                                     finaltagcount = "elementindexvalue=\"" + str(hex(elementtagcount)) + "\""
                                 else:
                                    finaltagcount = "elementindexvalue=\"" + str(elementtagcount) + "\""
                                 eachxmlline = eachxmlline.replace(ptrn1.group(), finaltagcount)
                            if '<generateoptions bytecodefilename=' in eachxmlline:
                                #print(eachxmlline)
                                IDBCheck = eachxmlline.split('"')[1]
                                IDBCheck = IDBCheck.split('"')[0]
                                if len(IDBCheck.strip()) != 0 and ('idb' in IDBCheck or 'IDB' in IDBCheck):
                                    IDBName = re.findall(r'[\w-]+\.IDB|idb', eachxmlline, re.IGNORECASE)[0]
                                else:
                                    IDBName = ""
                                change_line = eachxmlline.split('bytecodefilename="')[1]
                                change_line = change_line.split("\"")[0]
                                replace_line = srcpath + "\\IDB\\" + IDBName
                                eachxmlline = eachxmlline.replace(change_line, replace_line)
                            fw.write(eachxmlline)

print("Instrumentation Completed")