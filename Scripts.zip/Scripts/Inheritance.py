#inheritance is the inheritting the Properties or methods of one class in another class

class user():
    def __init__(self, email):
        self.email = email
    def sign_in(self):
        print("Logged in Fucker")

class Wizard(user):
    def __init__(self, name, power, email):
        user.__init__(self, email)
        self.name = name
        self.power = power

    def attack(self):
        print(f'attacking with power {self.power} by {self.name}')

class Archer(user):
    def __init__(self, name, num_arrows, email):
        super().__init__(email)
        self.name = name
        self.num_arrows = num_arrows

    def attack(self):
        print(f'attacking with arrows {self.num_arrows} by {self.name}')

wizard1 = Wizard("Vishwas", 50, "vishwas1119@gmail.com")
archer = Archer("Krishna", 100, "krishna@gmail.com")
print(isinstance(wizard1, Wizard))
print(wizard1.email)
print(archer.email)
print(wizard1.name)
print(wizard1.power)
wizard1.sign_in()
wizard1.attack()
archer.attack()

## Object Introspection - is the ability to determine the type of the object at runtime
print(dir(wizard1))


