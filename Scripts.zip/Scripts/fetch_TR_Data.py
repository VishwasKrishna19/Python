import win32con, win32api,os
import os # for os functions
import subprocess # For calling batch file
import string #For string operations
import sys # for system functions
import re # for Regular expression
import glob # for Directory walk through

def Read_TR_Action_description():
    TR_list = open("C:/Users/h126313/Desktop/NG/TRs/Baseline_input.txt", "r")
    TR_bat = open("C:/Users/h126313/Desktop/NG/TRs/Get_TRR_Action_Description.bat", "w")
    TR_list_line = TR_list.readline()
    while (TR_list_line):
        TR_no = TR_list_line.strip()
        TR_no = TR_list_line.strip("\n")
        print(TR_no)
        TR_bat.write("SCWS " + '"' + "EDS_TSC:_WORK_MAIN" + '"' + " /NODEFAULT" + "\n")
        if "_TR_" in TR_no and re.search(r"\d+$", TR_no):
            TR_bat.write(
                "BC " + '"' + TR_no + '"' + " /FILENAME=" + '"' + "C:\\TRR\\TRinfo\\" + TR_no + ".txt" + '"' + "\n")
        TR_list_line = TR_list.readline()
    TR_list.close()
    TR_bat.close()
    temp = subprocess.call(['PVCS_Login.bat', Username, Password, Server, DB_name, DB_connection,
                            "C:\TRR_Automation_final2\Get_TRR_Action_Description.bat"])
    os.remove("C:\TRR_Automation_final2\Get_TRR_Action_Description.bat")
    if temp:
        tm.showerror("Fetching TR's action Description is not successful")
    else:
        tm.showinfo("Baseline in progress", "Fetching TRR action Description is successful")


Read_TR_Action_description()