import codecs
import os
from chardet import detect

# get file encoding type
def get_encoding_type(file):
    with open(file, 'rb') as f:
        rawdata = f.read()
    return detect(rawdata)['encoding']

XMLRead = input("Drag and Drop the root folders of the XML or Enter the full folders Name with path: ")
os.getcwd()
if os.path.exists('TraceTagList.txt'): os.remove('TraceTagList.txt')
for root, dirs, files in os.walk(XMLRead):
        for file in files:
            if file.endswith(".IDL_XML") or file.endswith(".idl_xml"):
                from_codec = get_encoding_type(os.path.join(root, file))
                if (from_codec != 'UTF-8'):
                    with open(os.path.join(root, file), 'r', encoding=from_codec) as f, open(os.path.join(root, file + '1'), 'w', encoding='utf-8') as e:
                        text = f.read()  # for small files, for big use chunks
                        e.write(text)
                    os.remove(os.path.join(root, file))  # remove old encoding file
                    os.rename(os.path.join(root, file + '1'), os.path.join(root, file))  # rename new encoding

                with codecs.open(os.path.join(root, file), "r", encoding="utf8", errors='ignore') as auto:
                    linenumberparsing = False
                    with open('TraceTagList.txt', 'a') as wf:
                        groupName = ''
                        TraceTag = ''
                        ElementHashname = ''
                        ElementTag = ''
                        cnt = 0
                        xmlstartline = 0
                        xmlendline = 0
                        LineData =  ''
                        group_started = False
                        orig_linedata = ''
                        groupName_array = []
                        Tracetag_Array = []
                        ElementHashname_Array = []
                        ElementTag_Array = []

                        for XMLlines in auto:
                            cnt = cnt + 1
                            #print(cnt)
                            XMLlines = XMLlines.strip()
                            if XMLlines.__contains__('elementhashname') and XMLlines.__contains__(
                                    'elementtag') and XMLlines.__contains__('<group name='):
                                #xmlendline = cnt - 1
                            #if (XMLlines.__contains__('elementhashname') and XMLlines.__contains__('elementtag')):
                                LineData = XMLlines.strip()
                                #LineData = LineData.strip('\r\n')
                                #print(LineData)
                                if LineData.startswith('<group name') and group_started is True:
                                    group_started = False
                                    xmlendline = cnt - 1
                                    print(xmlstartline, " to ", xmlendline)
                                    wf.write(
                                        file + "," + orig_linedata + "," + groupName + "," + TraceTag + "," + ElementHashname + "," + ElementTag + "," + str(
                                            xmlstartline) + " to " + str(xmlendline) + '\n')



                                if LineData.startswith('<group name') and group_started is False:
                                    group_started = True
                                    orig_linedata = LineData
                                    groupName = LineData.split("\"")[1]
                                    #print(f"Group : {groupName}")
                                    groupName = groupName.split("\"")[0]
                                    xmlstartline = cnt
                                    #print(groupName)
                                if LineData.__contains__('tracetag=') and group_started is True:
                                    TraceTag = LineData.split("tracetag=")[1]
                                    TraceTag = TraceTag.split("\"")[1]
                                    TraceTag = TraceTag.split("\"")[0]
                                    #print(TraceTag)
                                if LineData.__contains__('elementhashname=') and group_started is True:
                                    ElementHashname = LineData.split("elementhashname=")[1]
                                    ElementHashname = ElementHashname.split("\"")[1]
                                    ElementHashname = ElementHashname.split("\"")[0]
                                    #print(ElementHashname)
                                if LineData.__contains__('elementtag=') and group_started is True:
                                    ElementTag = LineData.split("elementtag=\"")[1]
                                    #ElementTag = ElementTag.split("\"")[1]
                                    ElementTag = ElementTag.split("\"")[0]
                            #else:
                            #    continue

                            #wf.write(file + "," + LineData + "," + groupName + "," + TraceTag + "," + ElementHashname + "," + ElementTag + "," + str(xmlstartline) + " to "+ str(xmlendline) +'\n')

                        xmlendline = cnt - 1
                        wf.write(
                            file + "," + orig_linedata + "," + groupName + "," + TraceTag + "," + ElementHashname + "," + ElementTag + "," + str(
                                xmlstartline) + " to " + str(xmlendline) + '\n')