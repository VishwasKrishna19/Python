import pandas as pd
import openpyxl
import xlrd

Actual_data = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\Actual1.xlsx'
Template_xls = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\ASTC1217.xls'
temp_xls = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\Temp.xls'

df = pd.read_excel(Actual_data)
#mylist_Name = df.loc[14, :].values.tolist()
#print(len(mylist_Name))
#xlsdata = openpyxl.load_workbook(Template_xls)
xlsdata = xlrd.open_workbook(Template_xls)
#readsheet = xlsdata['Sheet1']
readsheet = xlsdata.sheet_by_index(0)
writeWorkbook = openpyxl.Workbook()
writesheet = writeWorkbook.active
templist = df.columns.values.tolist()
templist = [x.upper() for x in templist]
templist_index = dict()

for col in range(0, readsheet.ncols):
    if readsheet.cell(15, col).value != None:
        if readsheet.cell(15, col).value.strip().upper().replace('_SRD', "") in templist:
            templist_index[readsheet.cell(15, col).value.strip().upper().replace('_SRD', "")] = col

row = 0
for colref in templist_index.keys():
    col_Values = list(df[colref])
    for col_Value in col_Values:
        row += 1
        print(colref)
        print(row)
        print(templist_index[colref])
        writesheet.cell(row=row, column=templist_index[colref]+1).value = col_Value
    row = 0

writeWorkbook.save(temp_xls)
writeWorkbook.close()
