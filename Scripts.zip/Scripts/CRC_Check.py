# import hashlib
# m = hashlib.md5()
# for line in open('C:\\Vishwas\\Task_Assigned\\TSC2_0\\Drop2\\Load_5_5\\IDATA\\Coverage_TRC\\TgfDspMainFrame.IDB\\MainFrame.TRC', 'rb'):
#     m.update(line)
# print(m.hexdigest())


import zlib
file = "C:\\Vishwas\\Task_Assigned\\TSC2_0\\Drop2\\Load_5_5\\IDATA\\Coverage_TRC\\TgfDspMainFrame.IDB\\MainFrame.TRC"
checksum = ""
def crc32(filename, chunksize=65536):
    """Compute the CRC-32 checksum of the contents of the given filename"""
    with open(filename, "rb") as f:
        checksum = 0
        while (chunk := f.read(chunksize)) :
            checksum = zlib.crc32(chunk, checksum)
        print(checksum)
        #return checksum


crc32(file)
print(checksum)