from PIL import Image, ImageFilter

img = Image.open('D:\\Vishwas\\Python\\Projects\\Images\\Squireel.jpg')

print(img.format)
print(img.size)
print(img.mode)
print(dir(img))

filteredImage = img.filter(ImageFilter.BLUR)
filteredImage = img.filter(ImageFilter.SMOOTH)
resize = filteredImage.resize((300,300))
filteredImage.save("blur.png", "png")
#resize.save("resize.png", 'png')
#resize = filteredImage.resize(100,100)
filteredImage.show()

img1 = Image.open('D:\\Vishwas\\Python\\Projects\\Images\\astro.jpg')
img1.thumbnail((400,400))
img1.save('thumbnail.jpg')

