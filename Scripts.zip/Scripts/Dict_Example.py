dict1 = {a:1, b:2, c:3}
dict2 = {a:2, b:3, c:4, d:5}
dict3 = {a:6, b:3, e:5}
