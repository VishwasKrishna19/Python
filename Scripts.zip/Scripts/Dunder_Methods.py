## Dunder Methods (Dunder Magic methods)

class Toy():
    def __init__(self, color, age):
        self.color = color
        self.age = age
        self.my_dict = {
            'name': 'Yoyo',
            'has_pets': False,
        }

    def __str__(self):
        return f'{self.color}'

    def __len__(self):
        return 5

    def __call__(self):
        print("deleted")

    def __getitem__(self, item):
        return self.my_dict[item]

action_figure = Toy('red', 1)
print(action_figure.__str__()) #special methods that python recognize
print(str(action_figure))
print(len(action_figure))
del(action_figure)
