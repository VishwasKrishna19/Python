import os

Trace_Txt = input("Enter the path with filename of Trace.txt file(missed tags list in Text file): ")
TRC_FILE = input("Enter the Sample TRC file which has Correct idbcrc: ")

#Trace_Txt = "C:\\Users\\h126313\\Desktop\\Python\\IDATA\\Trace.txt"
#TRC_FILE = "C:\\Users\\h126313\\Desktop\\Python\\IDATA\\TSG_S13B_0053_1.TRC"

os.getcwd()
idbCRC = ""
TraceTag_List = []
tracefile = open(Trace_Txt, "r")
trcfile = open(TRC_FILE, "r")
outputfile = open("Output.TRC", "w", newline='')
outputfile.write("<?xml version=\"1.0\"?>" + '\n' + "<tracetags>" + '\n')
for line in trcfile:
    if line.__contains__("idbcrc=\""):
        idbCRC = line.split("idbcrc=\"")[1]
        idbCRC = idbCRC.split("\"")[0]
    if line.__contains__("<tracetaglog tag=\""):
        tracetags = line.split("<tracetaglog tag=\"")[1]
        tracetags = tracetags.split("\" idbcrc=")[0]
        TraceTag_List.append(tracetags)
print(TraceTag_List)
for eachline in tracefile:
    eachline = eachline.strip()
    TraceTag_List.append(eachline)

TraceTag_List.sort()
print(TraceTag_List)

for missedtracetags in TraceTag_List:
    LineData = "<tracetaglog tag=\"" + missedtracetags + "\" idbcrc=\"" + idbCRC + "\">" + '\n' + "</tracetaglog>" + '\n'
    print(LineData)
    outputfile.write(LineData)

outputfile.write("</tracetags>" + '\n' + "ABCD1234")
outputfile.close()