#Author - Vishwas Krishna
#Purpose - Split the rows in Xls sheet with semicolon(;) and inset the row after that


import pandas as pd
import glob

filename = "C:\\Users\\h126313\\Desktop\\Python\\Excel\\CA4_TSC_EDSTSC_GS_00_002_Consolidated_RA_Test.xlsx"
writer = pd.ExcelWriter('C:\\Users\\h126313\\Desktop\\Python\\Excel\\Test_Merge_Updated.xlsx', engine='xlsxwriter')


all_data = pd.DataFrame()

for f in glob.glob(filename):
    df = pd.read_excel(f, keep_default_na=False)
    df = df.astype(str)
    #coulumnName = df.columns
    #print(coulumnName)
    all_data = all_data.append(df, ignore_index=True)
    #all_data.describe()
    print(all_data['Shall tag/Object ID'])
    df = df.groupby('Test Name').agg({'Functionality':'first','CR/SCR/TR/VR No':'first','CR/SCR/TR/VR Title':'first',
                                      'CR/SCR/TR/VR Status':'first','CR/SCR/TR/VR Type':'first','PTag':'first','IMID':";".join,
                                      'Object type':'first','Software Requirement Document Name':",".join,'Shall tag/Object ID':";".join,
                                      'SUT (Executable/Library)':'first','Source File':",".join,'Function':";".join,
                                      'Comments (If any)':'first'}).reset_index()

    print(df)
df.to_excel(writer, sheet_name='Sheet1')
workbook = writer.book
worksheet = writer.sheets['Sheet1']