from tiucoreintfc import TIUFunctions
from qualifiedsupport import TestCompare
import socket
import platform


class ComConstantsAndFunctions:

    tiu = TIUFunctions()
    tstCmp = TestCompare()

    def __init__(self):
        self.verifyWriteStatus = False
        self.verifyReadReturnValueStatus = False
        self.verifyReadCheckValueLst = []
        self.verifyReadCheckValueStatus = False
        self.verifyReadChkValueMin = 0
        self.verifyReadChkValueMax = 0
        self.intFailAnomaly = 0
        self.assignStatus = False
        self.connectTIUStatus = False
        self.tiuSeverVersionLst = []
        self.datmonVersionLst = []

    def GlobalDocumentTestEnvironment(self):
        ''' Function to print the header section of the summary file '''
        # Print Desktop test environment
        print('*************  Test Environment  **************')
        print('** User''s Computer: ' + socket.gethostname())
        print('** Python Version: ' + platform .python_version())

    def connectTIU(self, tiuIP):
        ''' Function to connect to TIU Server '''
        self.connectTIUStatus = ComConstantsAndFunctions.tiu.connect(tiuIP)
        return self.connectTIUStatus

    def getTIUDetails(self):
        ''' Function to print the TIU specific details '''
        self.tiuSeverVersionLst = ComConstantsAndFunctions.tiu.readvalue(r" TIU Server\Info\Revision")
        self.datmonVersionLst = ComConstantsAndFunctions.tiu.readvalue(r"Datmon\ Info\Data Monitor Version")
        print('** TIU Server Version: ' + str(self.tiuSeverVersionLst[1]))
        print('** Datmon Version: ' + str(self.datmonVersionLst[1]))

    #def PassFail(self, displayString):


    def VerifyReadChkValue(self, readParam, exptValue, tol, testID):
        ''' Function to return the boolean status of read and compare the actual value is within the defined tolerance of the expected value '''
        # Read the actual value from the parameter
        self.intFailAnomaly = ComConstantsAndFunctions.tstCmp.NumOfAnomaly + ComConstantsAndFunctions.tstCmp.NumOfFail
        self.verifyReadCheckValueLst = self.VerifyReadReturnValue(readParam)

        # Check read was performed without any error
        if not self.verifyReadCheckValueLst[0]:
            return False
        else:
            # compute the min and max expected value based on the tolerance value
            self.verifyReadChkValueMin = exptValue - tol
            self.verifyReadChkValueMax = exptValue + tol

            if tol == 0:
                # if tolerance is zero
                self.verifyReadCheckValueStatus = ComConstantsAndFunctions.tstCmp.CMP(self.verifyReadCheckValueLst[1],
                                                                                       'EQ', exptValue, testID)
            else:
                self.verifyReadCheckValueStatus = ComConstantsAndFunctions.tstCmp.LCMP(self.verifyReadCheckValueLst[1],
                                                                                       self.verifyReadChkValueMin,
                                                                                       self.verifyReadChkValueMax,
                                                                                       testID,
                                                                                       type(self.verifyReadCheckValueLst[1]))

        if ComConstantsAndFunctions.tstCmp.NumOfAnomaly + ComConstantsAndFunctions.tstCmp.NumOfFail > self.intFailAnomaly:
            print(' More information for [' + testID + '] Read/Compare    ')
            print('    Param: ' + readParam)
            print('    Value was: ' + str(self.verifyReadCheckValueLst[1]) + '; s/b: ' + str(exptValue) + ', with +/-Toler: ' + str(tol))
            return False
        else:
            return True

    def VerifyReadReturnValue(self, readParam):
        ''' Function to return the boolean status of the read operation and values read from the parameter '''
        # Read value from the variable
        self.verifyReadReturnValueStatus = ComConstantsAndFunctions.tiu.readvalue(readParam)

        # Check read was performed without any error
        if not self.verifyReadReturnValueStatus:
            # Error on read
            print('\n VerifyReadReturnValue, TIU Read ' + ComConstantsAndFunctions.tstCmp.AccountForNewAnomaly())
            print('** Note Using Parameter {' + readParam + '} Type ' + type(self.verifyReadReturnValueStatus[1]))

        return self.verifyReadReturnValueStatus

    def VerifyWrite(self, writeParam, writeValue, testID):
        ''' Function to write data onto a TIU variable '''
        # Write value to specific write parameter
        self.verifyWriteStatus = ComConstantsAndFunctions.tiu.writevalue(writeParam, writeValue)

        # Check write was performed without any error
        if not self.verifyWriteStatus:
            # Error on write
            print('\n in [VerifyWrite<-' + testID + '] Anomaly on write of [' + writeValue + '] To {' + writeParam + '}' + ComConstantsAndFunctions.tstCmp.AccountForNewAnomaly())
            print('** Note Using Parameter {' + writeParam + '} Type ' + type(writeValue))

        return self.verifyWriteStatus

    def Assign(self, var, value, varType, testID):
        ''' Function to write value onto a glossary ot internal variable '''

        if (varType == 'glossary') or (varType == 'internal'):
            self.assignStatus = self.VerifyWrite(var, value, testID)

        return self.assignStatus


    #def VerifyReadChkInternal(self, internalParam, exptValue, toler, testID):
    #    ''' Function to return the boolean status of read and compare the actual value is within the defined tolerance of the expected value (for internal variable) '''
    #    print('VerifyReadChkInternal Called by ' + testID)
    #    print(' -- Parm:' + internalParam + '; s/b = ' + exptValue + '; Tolerance = ' + toler)