import pandas as pd

# Define a dictionary containing employee data
data1 = {'Name': ['Jai', 'Princi', 'Gaurav', 'Anuj'],
         'Age': [27, 24, 22, 32],
         'Address': ['Nagpur', 'Kanpur', 'Allahabad', 'Kannuaj'],
         'Qualification': ['Msc', 'MA', 'MCA', 'Phd']}

# Define a dictionary containing employee data
data2 = {'Name': ['Abhi', 'Ayushi', 'Dhiraj', 'Hitesh'],
         'Age': [17, 14, 12, 52],
         'Address': ['Nagpur', 'Kanpur', 'Allahabad', 'Kannuaj'],
         'Qualification': ['Btech', 'B.A', 'Bcom', 'B.hons']}

# Convert the dictionary into DataFrame
df = pd.DataFrame(data1,index=[0,1,2,3])
df1 = pd.DataFrame(data2, index=[2, 3, 6, 7])
res2 = pd.concat([df, df1], axis=1, join='inner')
res2 = pd.concat([df, df1], axis=1, sort=False)
res3 = pd.concat([df, df1], axis=1, join_axes=[df.index])
res = pd.merge(df, df1, on='Name')
#print(res)


df12 = pd.DataFrame({'A': [1, 1, 2, 2],
                   'B': [1, 2, 3, 4]})
df12.groupby('A').agg('min')
print(df12)