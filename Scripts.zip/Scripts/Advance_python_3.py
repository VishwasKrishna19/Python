#Generators and Generator Comprehension

#why we wanted to use Generator

def find_even(n):
    output= []
    for i in range(n):
        if i%2 == 0:
            output.append(i)
    return output

#evenno = find_even(10000000000000)
#print(evenno)

#using Generator

def find_even_gen(n):
    output= []
    for i in range(n):
        if i%2 == 0:
            yield i

gene_obj = find_even_gen(10000000000000)
print(type(gene_obj))
print(next(gene_obj))

#for i in gene_obj:
    #print(i)


## generator comprehension
gen_obj = (x for x in range(10) if x%2 ==0)

#Decorators : Perform some additional execution before a function call

def sample_deco(func):
    def inner(n1,n2):
        if n2 == 0:
            print("can't divide by zero")
        else:
            return func(n1, n2)
    return inner

@sample_deco
def divides(n1, n2):
    return n1/n2

print(divides(100,0))


