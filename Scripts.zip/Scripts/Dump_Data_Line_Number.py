#***************************************************************************************************
#Author: Vishwas Krishna(H126313)
#Purpose: Generate the IDATA Plan and exception sheet
#***************************************************************************************************

import codecs
import os
import glob
import chardet
import sys
import fileinput
import re
import pandas
import pandas as pd
from numpy import *
import csv
from chardet import detect

class SmartReader(object):
    def __init__(self, function_to_call, default_return):
        self.fun = function_to_call
        self.default_return = default_return

    def read(self, file):
        return self._open_and_execute(file)

    def _predict_encoding(self, file, nLines=1000):
        # Open the file as binary data
        with open(file, 'rb') as f:
            rawdata = b''.join([f.readline() for _ in range(nLines)])
            # print(chardet.detect(rawdata)['encoding'])
            return chardet.detect(rawdata)['encoding']

    def _open_and_execute(self, file):
        """
        Open the different encoding files and invoke the call back function
        with the file handler.
        """

        # Get encoding
        encd = self._predict_encoding(file)
        try:
            with open(file, 'r', encoding=encd) as f:
                return self.fun(f)
        except:
            pass
        try:
            with open(file, 'r') as f:
                return self.fun(f)
        except:
            pass
        try:
            with open(file, 'r', encoding='utf-8') as f:
                return self.fun(f)
        except:
            pass
        print('Not able to read', file)
        # Return default
        return self.default_return


sreder = SmartReader(lambda x: x.readlines(), [])


def getfilelist(path):
    files = glob.glob(os.path.join(path, r'**'), recursive=True)
    # print(files)
    XML_Files = [x for x in files if os.path.splitext(x)[1].lower() == '.idl_xml']
    return XML_Files


def get_XML_data(file, fp):
    print(os.path.basename(file))
    filename = os.path.basename(file)
    fdata = sreder.read(file)
    Elementhashname_file_write(fdata, filename)
    TraceTag = ''
    groupName_List = []
    ElementHashname_List = []
    ElementTag_List = []
    TraceTag_List= []
    xmlstartline_List = []
    xmlActual_Line_List = []
    Pattren_List = []
    ElementHashname_PattrenList = []
    ElementTag_PattrenList = []
    linenum_Pattren = []
    xmlActual_Line_PattrenList = []
    ElementTag_dict = {}
    cnt = 0
    for line in fdata:
        Line = line.strip()
        #Elementhashname_file_write(fdata, filename)
        cnt = cnt + 1
        if Line.__contains__("elementhashname") and Line.__contains__("elementtag"):
            if Line.startswith("<group"):
                xmlActual_Line_List.append(Line)
                xmlstartline_List.append(cnt)
                ElementHashname = Line.split("elementhashname=")[1]
                ElementHashname = ElementHashname.split("\"")[1]
                ElementHashname = ElementHashname.split("\"")[0]
                ElementHashname_List.append(ElementHashname)
                ElementTag = Line.split("elementtag=\"")[1]
                ElementTag = ElementTag.split("\"")[0]
                ElementTag_List.append(ElementTag)
                if Line.startswith('<group name'):
                    groupName = Line.split("\"")[1]
                    groupName = groupName.split("\"")[0]
                    groupName_List.append(groupName)
                else:
                    groupName_List.append('')
                if Line.__contains__('tracetag='):
                    TraceTag = Line.split("tracetag=")[1]
                    TraceTag = TraceTag.split("\"")[1]
                    TraceTag = TraceTag.split("\"")[0]
                    TraceTag_List.append(TraceTag)
                else:
                    TraceTag_List.append(TraceTag)
            else:
                linenum_Pattren.append(cnt)
                xmlActual_Line_PattrenList.append(Line)
                data = Line.split()[0].replace("<", '')
                #if data not in Pattren_List:
                Pattren_List.append(data)
                ElementHashname_Pattren = Line.split("elementhashname=")[1]
                ElementHashname_Pattren = ElementHashname_Pattren.split("\"")[1]
                ElementHashname_Pattren = ElementHashname_Pattren.split("\"")[0]
                ElementHashname_PattrenList.append(ElementHashname_Pattren)
                ElementTag_Pattren = Line.split("elementtag=\"")[1]
                ElementTag_Pattren = ElementTag_Pattren.split("\"")[0]
                ElementTag_PattrenList.append(ElementTag_Pattren)
        if len(ElementTag_List) > 0:
            if Line.__contains__("</group>"):
                Key = int(ElementTag_List[-1])
                xml_startline = xmlstartline_List.pop()
                ElementTag_dict[Key] = filename + "," + xmlActual_Line_List.pop() + "," + groupName_List.pop() + "," +TraceTag_List.pop() + "," + ElementHashname_List.pop() + "," + ElementTag_List.pop() + "," + str(xml_startline) + " to " + str(cnt) + "," + str(xml_startline) + '\n'
            #fp.write(filename + ";" + xmlActual_Line_List.pop() + ";" + groupName_List.pop() + ";" +TraceTag_List.pop() + ";" + ElementHashname_List.pop() + ";" + ElementTag_List.pop() + ";" + str(xmlstartline_List.pop()) + " to " + str(cnt) + '\n')
        if len(Pattren_List) > 0:
            if Line.__contains__("</" + Pattren_List[-1]):
                Pattren_List.pop()
                key = int(ElementTag_PattrenList[-1])
                xml_startline = linenum_Pattren.pop()
                ElementTag_dict[key] = filename + "," + xmlActual_Line_PattrenList.pop() + "," + groupName_List[-1] + "," + TraceTag_List[-1] + "," + ElementHashname_PattrenList.pop() + "," + ElementTag_PattrenList.pop() + "," + str(xml_startline) + " to " + str(cnt) +  "," + str(xml_startline)+ '\n'
                #fp.write(filename + ";" + xmlActual_Line_PattrenList.pop() + ";" + groupName_List[-1] + ";" + TraceTag_List[-1] + ";" + ElementHashname_PattrenList.pop() + ";" + ElementTag_PattrenList.pop() + ";" + str(linenum_Pattren.pop()) + " to " + str(cnt) + '\n')
    return ElementTag_dict

def Elementhashname_file_write(fdata, filename):
    with open('DumpDataXML.txt', 'a') as wf:
        for XMLlines in fdata:
            if XMLlines.startswith('<group elementhashname='):
                wf.write(filename + "," + XMLlines)
                break

def IDB_Read(Htmlread):
    os.getcwd()
    #Htmlread = input("Drag and Drop the .idb.html file or Enter the full filename with path: ")
    # Logic to Convert HTML TO TEXT FILE
    with open(Htmlread) as html:
        with open("Html_text.txt", "w") as fs:
            with open("IDB_Name.txt", "w") as fs1:
                filename = html.name
                filename = filename.split('\\')[-1]
                filename = filename.split('.html')[0]
                print(filename)
                fs1.write(filename)
                for line1 in html:
                    fs.write(line1)

def HTML_DUMP():
    # Read Text File and and write required Data as Elementhash name and Status(Executed or Not_Executed)in XML2.txt
    with open("Html_text.txt", "r") as f:
        with open("Html_Dump.txt", "w") as wf:
            for line in f:
                if '<th> Trace Tags Name' in line:
                    if '<td align="center">' in line:
                        line = line.split("<td align=\"center\">", 1)[1]
                        user = re.findall(r'(?:<tr><td>|.html">)([A-F0-9]{8})', line)
                        user1 = re.findall(r'<td align="center">([EXECUTEDNot_Executed]+)', line)
                        new_list = []
                        if len(user1) != len(user):
                            print('list length mismatch')
                        else:
                            for each in range(0, len(user1)):
                                new_list.append(user[each] + "  " + str(user1[each]))
                        wf.write("\n".join(new_list))

def status_count():
    # Read XML2.txt and Split the Executed Count and Total count in XML2_2.txt and XML2_1.txt respectively
    with open("Html_Dump.txt") as f1:
        with open("TotalTags_Count.txt", "w") as wf:
            with open("Executed_TagCount.txt", "w") as wf1:
                lis = []
                lis1 = []
                for line in f1:
                    line = line.rstrip('\n')
                    XML = line.split('  ')
                    lis.append(XML[0])
                    lis1.append(XML[1])
                df = pd.DataFrame({'Status': lis1, 'XML_Name': lis})
                df1 = df[df.Status != 'Not_Executed']
                group = df1.groupby(['XML_Name', 'Status']).size()
                group1 = df.groupby(['XML_Name']).size()
                with pd.option_context('display.max_rows', 100):  # Maximum 100 XMLS considering in a program
                    wf.write(str(group1))
                    wf1.write(str(group))

def Tag_Count():
    # Read XML2_2.txt and XML2_1.txt and write the matched count data in Final_Count.txt
    with open("TotalTags_Count.txt") as f2:
        with open("Executed_TagCount.txt") as f3:
            with open("Final_Count.txt", "w") as fs:
                Total_count_line_1 = ''
                Executed_line_count = ''
                line2 = f2.readlines()
                line3 = f3.readlines()
                for Total_count_line in line2:
                    if 'XML_Name' not in Total_count_line or 'dtype:' not in Total_count_line:
                        Total_count_line_1 = re.sub(' +', ' ', Total_count_line)
                        Total_count_line_1 = Total_count_line_1.rstrip('\n')
                        Total_count_line_1 = Total_count_line_1.split(" ")[0]
                        temp = Total_count_line.split(" ")[-1]
                        Total_count_line = Total_count_line_1 + "," + temp
                        Total_count_line = Total_count_line.rstrip('\n')
                    for Executed_line_count in line3:
                        if Executed_line_count.startswith(Total_count_line_1):
                            Executed_line_count = Executed_line_count.rstrip('\n')
                            Executed_line_count = Executed_line_count.split(" ")[-1]
                            break
                        else:
                            Executed_line_count = 0
                    fs.write(Total_count_line + "," + str(Executed_line_count) + '\n')

def Final_Count(LoadId, Analyst_name, choice, Date):
    # Read Final_Count.txt and map to the respective XML name and Calculatte the Percentage
    with open("Final_Count.txt") as f4:
        with open("DumpDataXML.txt") as f5:
            with open("Final_TAGCOUNT_DATA.csv", "w") as fp:
                with open("IDB_Name.txt", "r") as fIDBName:
                    Dump_data = ''
                    line = fIDBName.readline()
                    line = line.rstrip('\n')
                    fp.write(
                        "IDB_NAME,XML_NAME,LOAD_ID,ANALYST_NAME,SITE,DATE,ELEMENTHASH_NAME,TOTAL_TAGS_COUNT,EXECUTED_TAG_COUNT,PERCENT_COVERAGE\n")
                    line4 = f4.readlines()
                    line5 = f5.readlines()
                    for count_line in line4:
                        if count_line.__contains__('XML_Name') or count_line.__contains__(
                                'dtype:') or count_line.__contains__('Length:'):
                            continue
                        count_line_1 = count_line.rstrip('\n')
                        count_line_1 = count_line_1.split(",")[0]
                        countline = int(count_line_1, 16)
                        countline = str(countline)
                        Executed_Count = count_line.split(",")[-1]
                        Executed_Count = Executed_Count.rstrip('\n')
                        Total_Count = count_line.split(",")[-2]
                        Total_XML_Percentage = (int(Executed_Count) / int(Total_Count)) * 100
                        Total_XML_Percentage = str(Total_XML_Percentage).rstrip('\n')
                        countline = countline.rstrip('\n')
                        count_line = count_line.rstrip('\n')
                        for Dump_data in line5:
                            if Dump_data.__contains__(countline):
                                Dump_data = Dump_data.rstrip('\n')
                                Dump_data = Dump_data.split(",")[0]
                                break
                        fp.write(
                            line + "," + Dump_data + "," + LoadId + "," + Analyst_name + "," + site + "," + Date + "," + count_line + "," + Total_XML_Percentage + '\n')

def All_tag_List():
    # Read Text File and and write required Data as Elementhash name and Stats(Executed or Not_Executed)in All Tags.txt
    with open("Html_text.txt", "r") as ftext:
        with open("All_Tags.txt", "w") as wfwrite:
            for line in ftext:
                if '<th> Trace Tags Name' in line:
                    if '<td align="center">' in line:
                        line = line.split("<td align=\"center\">", 1)[1]
                        user = re.findall(r'(?:<tr><td>|.html">)([A-F0-9_-]+)', line)
                        user1 = re.findall(r'<td align="center">([EXECUTEDNot_Executed]+)', line)
                        new_list = []
                        if len(user1) != len(user):
                            print('list length mismatch')
                        else:
                            for each in range(0, len(user1)):
                                new_list.append(user[each] + "  " + str(user1[each]))
                        wfwrite.write("\n".join(new_list))

def Missed_Tracetag():
    with open("All_Tags.txt", "r") as ftext1:
        with open("trace_miss.txt", "w") as wfwrite2:
            for line in ftext1:
                if line.__contains__('Not_Executed'):
                    line = line.split(" ")[0]
                    wfwrite2.write(line + '\n')

def Exception_Analysis():
    os.getcwd()
    with open("Dump_data.txt") as DumpData:
        with open('IDB_Name.txt') as IDBName:
            with open('trace_miss.txt') as TraceMiss:
                with open("Exception_Sheet.csv", "w") as Exception:
                    with open("DumpDataXML.txt") as DumpXML:
                        Exception.write(
                            "IDB_NAME,Trace_Tag,HASH_NAME_DECIMAL,ELEMENT_TAG_NAME_DECIMAL,XML_FILE_NAME,XML_LINE_NUMBER,XML_LINE_DATA,XML_GROUP_NAME,XML_TRACE_TAG,EXCEL_TRACE_INFO,EXCEL_TSF_INFO\n")
                        Line_Number = ''
                        XML_Line_Data = ''
                        XML_Name = ''
                        XML_Group_Name = ''
                        Xml_Trace_Tag = ''
                        IDBName_Final = IDBName.readline()
                        IDBName_Final = IDBName_Final.rstrip('\n')
                        line1 = DumpXML.readlines()
                        line2 = DumpData.readlines()
                        for tracemissedlines in TraceMiss:
                            tracemissedlines = tracemissedlines.rstrip("\n")
                            tracemissedlines1 = tracemissedlines.split("_")[0]
                            tracemissedlines1 = int(tracemissedlines1, 16)
                            Hash_Name_Decimal = str(tracemissedlines1)
                            element_tag_name = tracemissedlines.split("_")[1]
                            element_tag_name = int(str(element_tag_name)[:4])
                            # print(Hash_Name_Decimal)
                            for Dump_XML_data in line1:
                                if Dump_XML_data.__contains__(Hash_Name_Decimal):
                                    Dump_XML_data = Dump_XML_data.rstrip('\n')
                                    XML_Name = Dump_XML_data.split(",")[0]
                                    break
                            # print(Hash_Name_Decimal, Dump_XML_data)
                            XML_line_Search = "elementhashname=\"" + str(Hash_Name_Decimal) + "\" elementtag=\"" + str(
                                element_tag_name) + "\""
                            # print(XML_line_Search)
                            for DumpData in line2:
                                if XML_line_Search in DumpData:
                                    Line_Number = DumpData.split(",")[-2]
                                    # print(XML_line_Search+ "," +DumpData)
                                    XML_Line_Data = DumpData.split(",")[1]
                                    # print(XML_line_Search+ "," +DumpData + ","+ XML_Line_Data)
                                    # print(XML_Line_Data)
                                    Xml_Trace_Tag = DumpData.split(",")[-5]
                                    XML_Group_Name = DumpData.split(",")[-6]
                                    print(XML_Group_Name)
                            Exception.write(
                                IDBName_Final + "," + tracemissedlines + "," + Hash_Name_Decimal + "," + str(
                                    element_tag_name) + "," + str(XML_Name) + "," + str(Line_Number) + "," + str(
                                    XML_Line_Data) + "," + str(XML_Group_Name) + "," + str(Xml_Trace_Tag) + "\n")

if __name__ == '__main__':
    try:
        XMLRead = sys.argv[1]
        Htmlread = sys.argv[2]
        LoadId = sys.argv[3]
        Analyst_name = sys.argv[4]
        choice = sys.argv[5]
        Date = sys.argv[6]
    except IndexError:
        XMLRead = input("Drag and Drop the root folders of the XML or Enter the full folders Name with path: ")
        Htmlread = input("Drag and Drop the .idb.html file or Enter the full filename with path: ")
        LoadId = input("Enter the SW LoadID\n")
        Analyst_name = input("Enter the Analyst Name\n")
        choice = input("Enter the Site Option \n1:Bangalore (EDS)\n2:Madurai (EDS)\n3:Hyderabad (EDS)\n")
        choice = int(choice)
        if choice == 1:
            site = "Bangalore (EDS)"
        elif choice == 2:
            site = "Madurai (EDS)"
        elif choice == 3:
            site = "Hyderabad (EDS)"
        Date = input("Enter the Date in DD-MM-YYYY Format\n")
    #XMLRead = r'C:/Vishwas/TASKS_ASSIGNED/TSC2_0/RL4/IDATA_SC/IDATA/EDS_PRD_TSC2_00_004_Bytecode_Artifacts/'
    XML_Files = getfilelist(XMLRead)
    XML_Data = []
    fp = open('Dump_data.txt', 'w')
    for file in XML_Files:
        ElementTag_dict = get_XML_data(file, fp)
        dict_list = list(ElementTag_dict.keys())
        #dict_list.sort()
        for key in sorted(dict_list):
            fp.write(ElementTag_dict[key])
    fp.close()

    IDB_Read(Htmlread)
    HTML_DUMP()
    status_count()
    Tag_Count()
    Final_Count(LoadId, Analyst_name, choice, Date)
    All_tag_List()
    Missed_Tracetag()
    Exception_Analysis()
    if os.path.exists('Html_text.txt'): os.remove('Html_text.txt')
    if os.path.exists('Html_Dump.txt'): os.remove('Html_Dump.txt')
    if os.path.exists('All_Tags.txt'): os.remove('All_Tags.txt')
    if os.path.exists('Dump_data.txt'): os.remove('Dump_data.txt')
    if os.path.exists('DumpDataXML.txt'): os.remove('DumpDataXML.txt')
    if os.path.exists('Final_Count.txt'): os.remove('Final_Count.txt')
    if os.path.exists('IDB_Name.txt'): os.remove('IDB_Name.txt')
    if os.path.exists('TotalTags_Count.txt'): os.remove('TotalTags_Count.txt')
    if os.path.exists('trace_miss.txt'): os.remove('trace_miss.txt')
    if os.path.exists('Executed_TagCount.txt'): os.remove('Executed_TagCount.txt')

    print("Completed")