str = "hELLo".capitalize()
print(str)

str = "hELLo".lower()
print(str)

str = "hELLo".swapcase()
print(str)

str = "hello world".title()
print(str)

str = "hELLo".upper()
print(str)

str = "mom".replace("m","b")
print(str)

str = " hello ".strip()
print(str)

str = "hello".lstrip("h")
print(str)

str = "hello".rstrip("o")
print(str)