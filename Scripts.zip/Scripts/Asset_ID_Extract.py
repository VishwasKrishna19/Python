import sys
import os
import csv

with open('C:/Users/h126313/Desktop/NG/Assets.txt', 'r') as AssetsOrig:
  with open('C:/Users/h126313/Desktop/NG/Assets_Data.csv','w') as Assets:
      for line in AssetsOrig:
          if not line.isspace():
            Sl_No = line.split(" ")[0]
            #print(Sl_No)
            Asset_ID = line.split(" ")[1]
            #print(Asset_ID)
            AssetDesc = line.split(",")[0]
            AssetDesc = AssetDesc.split(" ")
            AssetDesc = [x for (i, x) in enumerate(AssetDesc) if i not in (0,1,2)]
            #print(AssetDesc)
            AssetDesc_str = ""
            for i in AssetDesc:
                AssetDesc_str += str(i) + "-"
            AssetDesc_str = AssetDesc_str[:-1]
            print(AssetDesc_str)
            Assets.write(Sl_No + ',' + Asset_ID + ','+ AssetDesc_str + '\n')