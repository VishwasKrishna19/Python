import os
import sys
import fileinput
import re

with open("C:/Users/h126313/Desktop/NG/Reports/TgfDspDatalink.idb.html") as html:
    with open("C:/Users/h126313/Desktop/NG/XML1.txt", "w") as fs:
        for line1 in html:
            fs.write(line1)

with open("C:/Users/h126313/Desktop/NG/XML1.txt", "r") as f:
    with open("C:/Users/h126313/Desktop/NG/XML2.txt", "w") as wf:
        for line in f:
            if '<th> Trace Tags Name' in line:
                if '<td align="center">' in line:
                    line = line.split("<td align=\"center\">", 1)[1]
                    user = re.findall(r'<tr><td>([A-Z0-9_-]+)', line)
                    print (user)
                    user1 = re.findall(r'<td align="center">([A-Za-z_]+)', line)
                    new_list = []
                    if len(user1) != len(user):
                        print ('list length mismatch')
                    else:
                        for each in range(0, len(user1)):
                            new_list.append(user[each] + "  " +  str(user1[each]))
                    wf.write("\n".join(new_list))