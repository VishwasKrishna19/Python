#--------------------------------------------------------------
#Author : Vishwas, Shrithi
#Purpose: Replacing the Shall tag to Object ID
#       Find_Replace.csv needs to be created, where first column should be find item and 2nd column should be replace Item
#       Create InputFiles and OutputFiles folder, can keep n number of files in InputFiles
#       Provide the root folder where folder should contain InputFiles, OutputFiles and Find_Replace.csv
#       OutputFiles will be created in folder
#-------------------------------------------------------------
import os
import re
import codecs
import shutil
texttofind = ''
texttoreplace = ''
texttofindarr = []
texttoreplacearr = []

#main_Path = input("Provide the Root Folder Path: ")
main_Path = "C:\\Vishwas\\Task_Assigned\\CA4\MMECL\\Scripts\\Files\\Tool\\InputFiles\\"
os.chdir(main_Path)
#print(os.getcwd())
#sourcepath = os.listdir('InputFiles/')
#print(sourcepath)
main_Sourcepath = os.getcwd() + '\\InputFiles'

inputfile1 = open("Find_Replace.csv", 'r')

def read_inputcsv():
    for eachline in inputfile1:
        eachline = eachline.strip()
        texttofind = eachline.split(",")[0]
        texttoreplace = eachline.split(',')[1]
        TR_Number = eachline.split(',')[2]
        if len(texttoreplace) != 0:
            if len(texttofind) != 0:
                texttofindarr.append(texttofind.strip())
                texttoreplacearr.append(texttoreplace.strip())

read_inputcsv()
inputfile1.close()

print(texttofindarr)
print(texttoreplacearr)

def replace_FileContent():
    for eachfile in sourcepath:
        destinationPath = 'OutputFiles/' + eachfile
        with open(destinationPath, 'w', encoding='UTF-8', errors='ignore', newline='') as outputfile:
            for eachfile in sourcepath:
                inputfile = 'InputFiles/' + eachfile
                print("Conversion is Going on for: " +inputfile)
                with codecs.open(inputfile, "r", encoding='UTF-8', errors='ignore') as inputfile:
                    filedata = inputfile.read()
                for texttofind, texttoreplace in zip(texttofindarr, texttoreplacearr):
                    print(texttofind, texttoreplace)
                    pattren = r'\b' + texttofind + r'\b'
                    filedata = re.sub(pattren, texttoreplace, filedata, flags=re.I)
                    print("Replaced Successfully")
            outputfile.write(filedata)

#replace_FileContent()

def Replace_Folders_FileNames(folder_path):
    import glob
    all_files = glob.glob(os.path.join(folder_path, '**', '*'), recursive=True)
    for f in all_files[::-1]:
        old_name = f
        new_name = f
        for fi, re in zip(texttofindarr, texttoreplacearr):
            if fi in new_name:
                new_name = new_name.replace(fi, re)
        os.rename(old_name, new_name)


Replace_Folders_FileNames(main_Path)