#Encapsulation
#Abstraction

class PlayerCharacter:
    membership = True #Class object Attribute
    def __init__(self, name= 'anonymus', age='0'): #Constructor Method, Automatically Called in this block when we instanciate
        #if (self.membership) or (PlayerCharacter.membership):
        if (age > 18):
            self.name = name            #Attributes
            self.age = age

    def run(self):
        print('run') #we get none if Function Doesn't return anything
        return ''
    def introduce(self):
        print(f'My Name is {self.name}')

    # @classmethod,cls will be the first argument in any the user defined function
    # its same as slef but what is the difference is if we self we need to instanciate the class
    #if we use cls the we need not to instanciate the class directly we can use classmethod.functionmethod
    def add_things(cls, num1, num2):
        return cls('VishwasKrishna', num1 + num2)

    # @static Method - this Doesnt have access to the cls variable
    def add_things2(cls, num1, num2):
        return num1 + num2

player1 = PlayerCharacter('Vishwas', 31)
player2 = PlayerCharacter('Krishna', 52)
player1.attack = 50
print(player1.name)
print(player1.run())
print(player2.age)
print(player1.attack)
print(player1.membership)
print(player1.introduce())

#Abstraction is the Hiding the methods from the user, in the Below Example we only know Player 1 has access to the
# Introduce method
player1.introduce= "VKKK"
print(player1.introduce)

print(player1.add_things(4,5))

print(PlayerCharacter.add_things(2,3)) #if we use cls we can use this without instanciate the class

player3 = PlayerCharacter.add_things(6,7)
print(player3)