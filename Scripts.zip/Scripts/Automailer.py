import os
import PVCS_Login as pl
import win32com.client as win32
cwd = os.getcwd()

base_path = os.path.dirname(__file__)
result_path = os.path.abspath(os.path.join(base_path,"Results"))
result_excel = os.path.abspath(os.path.join(result_path,"Requirements_Impacted.xls"))
comp_result_txt = os.path.abspath(os.path.join(result_path,"difference.txt"))
CR_status = os.path.abspath(os.path.join(result_path,"CR_Status.csv"))
report_txt = os.path.abspath(os.path.join(result_path,"report_source.txt"))


def Send_Mail(mail_index):
    pl.read_config()
    outlook = win32.Dispatch('outlook.application')
    mail = outlook.CreateItem(0)
    #print(pl.EID)
    mail.To = pl.EID
    #mail.CC  = 'Manikantaswamy.Patnana@Honeywell.com;Shrikanth.S@Honeywell.com;Priyanka.P@Honeywell.com'
    mail.Subject = 'Requirements Monitor BOT'
    mail.HTMLBody = '<h2><br>Hello!!! This is your Requirements Monitor BOT</br><br>PFA for latest impact requirements list</br><br>Have a great Day</br><br></br><br></br><br>Always at your service,</br><br>Requirements Monitor BOT</br></h2>'# this field is optional
    #In case you want to attach a file to the email
    mail.Attachments.Add(result_excel)
    mail.Attachments.Add(CR_status)
    mail.Attachments.Add(report_txt)
    if mail_index == 1:
        mail.Attachments.Add(comp_result_txt)
    mail.Send()
