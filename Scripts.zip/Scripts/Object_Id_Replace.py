import os
import openpyxl

Mapping_File = input("Enter the full path of Mapping file: ")
wb = openpyxl.load_workbook(Mapping_File)
sheet = wb.get_sheet_by_name('Sheet1')

Texttofind_Array = []
TexttoReplace_Array = []
def TextToFind(Texttofind_Array, TexttoReplace_Array):
    for row in range (1,sheet.max_row+1):
        Texttofind = str(sheet.cell(row=row, column=1).value).strip()
        TexttoReplace = str(sheet.cell(row=row, column=2).value).strip()
        Texttofind = Texttofind + "]"
        TexttoReplace = TexttoReplace + "]"
        if (Texttofind == 'None]'):
            print("End of File")
            return Texttofind_Array, TexttoReplace_Array
        Texttofind_Array.append(Texttofind)
        TexttoReplace_Array.append(TexttoReplace)

texttofind = TextToFind(Texttofind_Array, TexttoReplace_Array)

Text_to_Find = ''
Text_To_Replace = ''
listlength = len(Texttofind_Array)
print(len(Texttofind_Array))
sourcepath = os.listdir('InputPath/')
lendata = 0
for file in sourcepath:
    inputfile = 'InputPath/' + file
    print("Conversion is Ongoing on: " +inputfile)
    if (lendata < listlength):
        Text_to_Find  = Texttofind_Array[lendata]
        Text_To_Replace = TexttoReplace_Array[lendata]
    with open(inputfile, 'r') as inputfile:
        filedata = inputfile.read()
        filefreq = 0
        filefreq = filedata.count(Text_to_Find)
    destinationPath = 'OutputPath/' + file
    filedata = filedata.replace(Text_to_Find, Text_To_Replace)
    with open(destinationPath, 'w') as file:
        file.write(filedata)
    print("Total %d Record replaced" %filefreq)
    lendata = lendata + 1