import csv

with open('C:/Users/h126313/Desktop/NG/Dump_data.txt') as f:
    with open('C:/Users/h126313/Desktop/NG/Test_data.csv', 'w', newline='') as wf:
        writer = csv.writer(wf)
        #writer.writerow("XML NAME")
        writer.writerow(["XML NAME", "ELEMENTHASHNAME(DECIMAL)", "ELEMENTHASHNAME(HEX)"])
        #writer.writeheader()
        for line in f:
            if "<group elementhashname=\"" in line:
                sample1 = line.split(',',1)[0]
                sample2 = line.split("elementhashname=\"",2)[1]
                sample3 = sample2.split("\"",1)[0]
                sample4 = int(sample3)
                sample5 = hex(sample4)
                sample6 = sample5.split('x')[-1]
                #wf.write(sample6 + '\n')
                wf.write(sample1 + ',' + sample3 + ',' + sample6 + '\n')