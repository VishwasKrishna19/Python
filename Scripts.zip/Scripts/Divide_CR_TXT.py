import re
import os
cwd = os.getcwd()
path = cwd + "\\CR_log1.txt"
def Divide_CR_txt():
	global parse
	parse = 0
	file = open(path,'r')
	try :
		os.mkdir("./CR_txt_1")
		os.chdir("./CR_txt_1")
	except:
		os.chdir("./CR_txt_1")
	for line in file:
		Request_id = re.findall( r"REQUEST ID:", line )
		END_OF_CHANGE_REQUEST = re.findall(r"END OF CHANGE REQUEST",line)
		if Request_id:
			CR = line.split( ":" )[1].strip()
			new_cr = open(CR+".txt",'w')
			parse = 1
		if END_OF_CHANGE_REQUEST:
			new_cr.write( line )
			parse = 0
			new_cr.close()
		if parse ==1:
			new_cr.write(line)
	file.close()
	os.chdir("..")