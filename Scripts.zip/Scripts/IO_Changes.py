#Author: Vishwas
#Purpose: Get the Test Names based on the Parameter present in the Parameter_Name.txt

import os
import glob
import codecs

parametertxt = "C:\\Vishwas\\Task_Assigned\\Python\\2_IO_CHanges\\Parameter_Name.txt"
Mappingpath = "C:\\Vishwas\\Task_Assigned\\Python\\2_IO_CHanges\\GGF_Tests\\Mapping\\"
Test_path = "C:\\Vishwas\\Task_Assigned\\Python\\2_IO_CHanges\\GGF_Tests\\Tests"
output = "C:\\Vishwas\\Task_Assigned\\Python\\2_IO_CHanges\\Output_ggf.csv"
file = open(output, "w")

def get_test_files(folder_path: str) -> list:
    all_files = glob.glob(os.path.join(folder_path, '**', '*.*'), recursive=True)
    return all_files


def getMappingfilelist(Mappingpath):
    filenames = os.listdir(Mappingpath)
    mappingfilelist = []
    for eachfile in filenames:
        filelist = Mappingpath + eachfile
        mappingfilelist.append(filelist)
    return mappingfilelist


def get_parameters(param_file: str) -> list:
    with open(param_file) as f:
        lines = f.readlines()
    return lines


def search_file(parameters: list, mapping_file: str) -> dict:
    print(mapping_file)
    with codecs.open(mapping_file, 'r') as f:
        lines = f.readlines()
    found = {}
    for line in lines:
        for param in parameters:
            if line.endswith(param):
                line = line.split(':')[0]
                line = line.replace('Dim', '').strip()
                found[param] = line
                break
    return found


def merge_dict(source: dict, dc: dict) -> dict:
    for key in dc:
        if not key in source:
            source[key] = dc[key]
    return source


def search_mapping_files(parameters: list, mapping_files: list) -> dict:
    found_params = dict()
    for file in mapping_files:
        found = search_file(parameters, file)
        found_params = merge_dict(found_params, found)
    return found_params


def search_test_file(paramaters: dict, test_file: str) -> dict:
    dc = {}
    print(test_file)
    with codecs.open(test_file, 'r', encoding="cp1252", errors='ignore') as f:
        lines = f.readlines()
    for line in lines:
        for key, val in paramaters.items():
            if val in line:
                dc[key] = os.path.basename(test_file)
    return dc


def search_test_files(params: dict, test_files: list) -> dict:
    dc = {}
    for file in test_files:
        found = search_test_file(params, file)
        for key in found:
            if key in dc:
                dc[key].append(found[key])
            else:
                dc[key] = [found[key]]

    return dc


def process():
    parameters = get_parameters(parametertxt)
    mapping_files = getMappingfilelist(Mappingpath)
    parameters = list(map(lambda x: f'\\{x.strip()}"\n', parameters))
    print(parameters)
    found_params = search_mapping_files(parameters, mapping_files)
    print(found_params)
    test_files = get_test_files(Test_path)
    print(test_files)
    found_test = search_test_files(found_params, test_files)
    print(found_test)
    for key, val in found_test.items():
        key = key.split("\"\n")[0]
        key = key.split("\\")[1]
        file.write(key + "," + str(val) + '\n')


process()

