import os
import errno
import json
basePath = os.path.dirname(__file__)

def make_sure_path_exists(path):
    try:
        os.makedirs(path)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
         raise

make_sure_path_exists(os.path.abspath(os.path.join(basePath, "..", "Data")))
make_sure_path_exists(os.path.abspath(os.path.join(basePath, "..", "Results")))

inputpath = os.path.abspath(os.path.join(basePath, "..", "Data", "Output.json"))
file = open(inputpath,'r')
inputscontent = file.read()
file.close()
inputs = json.loads(inputscontent)
TestXMLPath = ''
TestFilePath = ''
if inputs['TestXMLPath'] != None:
    TestXMLPath = str((inputs['TestXMLPath']).strip())
if inputs['TestFilePath'] != None:
    TestFilePath = str((inputs['TestFilePath']).strip())