import os
import codecs, re
from chardet import detect

srcpath = "C:\Vishwas\Task_Assigned\CA4\Load3_0\Builds\TSC_20210226\TSC\GTSC\Software\Tgf"


# get file encoding type
def get_encoding_type(file):
    with open(file, 'rb') as f:
        rawdata = f.read()
    return detect(rawdata)['encoding']


for root, dirs, files in os.walk(srcpath):
    for file in files:
        if file.endswith(".IDL_XML") or file.endswith(".idl_xml"):
            from_codec = get_encoding_type(os.path.join(root, file))
            if (from_codec != 'UTF-8'):
                with codecs.open(os.path.join(root, file), 'r', encoding=from_codec) as xmlfile:
                    for eachline in xmlfile:
                        if "<generateoptions bytecodefilename=" in eachline:
                            IDBNAME = re.findall(r'[A-Za-z0-9]+.idb', eachline)
                            print(file, IDBNAME)