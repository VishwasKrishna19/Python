from openpyxl import Workbook
import openpyxl

filename = "C:\\Users\\h126313\\Desktop\\Python\\IDATA\\Exception_Sheet.csv"
#wb = openpyxl.load_workbook(filename)
#sheet = wb.get_sheet_by_name('Sheet1')
f = open(filename, "r")
firstline = True
for line in f:
    if firstline:
        firstline = False
        continue
    print(line)