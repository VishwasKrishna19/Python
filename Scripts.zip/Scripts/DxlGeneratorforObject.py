#Updated to For summary without TBI
import string
import os
import sys
import re

Updated_path = "C:/Vishwas/TASKS_ASSIGNED/Load_735.3_Activities/Filter.dxl"
List_path = "C:/Vishwas/TASKS_ASSIGNED/Load_735.3_Activities/Object_list.txt"
#Open Ease File
fd = open(Updated_path,"w")
fd.write("Module m = current")
fd.write("\n")
fd.write("int x,y")
fd.write("\n")
book = open(List_path,"r")
line = book.readline()
line = line.strip()
fd.write("Filter f = contains(attribute" + '"' + "Object Text" + '"' + ',' + '"' + line + '"' + ',' + 'false' + ")")
#fd.write("||")
#fd.write("\n")
line = book.readline()
line = line.strip()

# Loop if either file1 or file2 has not reached EOF
while line:
   fd.write("||"+ "contains(attribute" + '"' + "Object Text" + '"' + ',' + '"' + line + '"' + ',' + 'false' + ")")
   #fd.write("\n")
   line = book.readline()
   line = line.strip()
fd.write("\n")
fd.write("set"+"("+ "m" + "," + "f" + "," + "x" +"," +"y" + ")")
fd.write("\n")
fd.write("filtering on")
fd.write("\n")
fd.write('print' + " " + '"' + "Accepted" + " " + "-" + " " + '"' + " " + "x" + '"' + '"' + " " + '"'+ "\\" + "n" + '"')
fd.write("\n")
fd.write('print' + " " + '"' + "Rejected" + " " + "-" + " " + '"' + " " + "y" + '"' + '"' + " " + '"'+ "\\" + "n" + '"')
fd.close()
book.close()