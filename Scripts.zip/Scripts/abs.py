print(abs(-5)) #Returns 5
print(abs(5)) #Returns 5
print(abs(-5.5)) #Returns 5.5
print(abs(5.5)) #Returns 5.5