# -*- coding: utf-8 -*-

import re

delimiters = ['IF', 'THEN', 'ENDIF', 'ELSEIF', "ELSE IF", 'ELSE', "END IF"]
allDelimiter = []
conditionMapping = {}
stringParsed = 0
statementNodeArray = []


# finds the position of next delimiter
def findNextDelimeter(string):
    global delimiters
    a = [(string.find(x), x) for x in delimiters]
    elseList = []
    elseifList = []
    for deli in a:
        if deli[1] == 'ELSE' and deli[0] != -1:
            elseList.append(deli)
        elif deli[1] == 'ELSEIF' and deli[0] != -1:
            elseifList.append(deli)
    for x in elseifList:
        if (x[0], 'ELSE') in elseList:
            a.remove((x[0], 'ELSE'))
    a.sort()
    for x in a:
        if x[0] >= 0:
            return x
    return -1


# Finds Positions of Delimiters in the string
def findAllPositions(string):
    global allDelimiter
    global stringParsed
    while True:
        currDeli = findNextDelimeter(string[stringParsed:])
        if currDeli == -1:
            break
        currStringParsed = stringParsed
        stringParsed = stringParsed + currDeli[0] + len(currDeli[1])
        currDeli = (currDeli[0] + currStringParsed, currDeli[1])
        allDelimiter.append(currDeli)


# Node is made with delimiters, 'IF','ELSEIF','ELSE', 'IF'  is positive while 'ELSEIF','ELSE' are negative
class Node:
    def __init__(self, condition, parent):
        self.condition = condition
        self.positiveChild = []
        self.negativeChild = None
        self.parent = parent
        self.easyArray = []
        self.statement = ''
        self.delimiter = None

    def addPositiveChild(self, child):
        self.positiveChild.append(child)

    def addNegativeChild(self, child):
        self.negativeChild = child

    def addParent(self, parent):
        self.parent = parent


# Fixing the Debounce input case : Causes errors and not required for the Truth Table
def debounceBabyBounce(string):
    temp = string.lower()
    bounce = "debouncedon"
    index = temp.find(bounce)
    if index < 0:
        return string
    else:
        tatti = string[index:]
        if tatti.find(')') >= 0:
            test = string[:index] + string[tatti.find(')') - len(tatti):]
            return test
        else:
            return string[:index]


# Root Node of the Tree
genesis = Node(None, None)
# Input the file and find all delimeter positions
with open('input.txt', 'r') as myfile:
    dat = myfile.read()
dat = re.sub('[\t|\r| ]+', '', dat)
dat = re.sub('[\n ]+', '  ', dat)
findAllPositions(dat)


# MAIN function that parses the expression
def generateConditionTree():
    global genesis
    global allDelimiter
    currentNode = genesis
    global statementNodeArray
    for y in range(0, len(allDelimiter)):
        x = allDelimiter[y]
        if x[1] == 'IF':
            ############UPDATE2#############
            if y != 0:
                aboveDelimiter = allDelimiter[y - 1]
                data_between_Delimiters = dat[aboveDelimiter[0] + len(aboveDelimiter[1]):x[0]]
                if len(data_between_Delimiters.strip().split()) > 0:
                    currentNode.statement += data_between_Delimiters.strip()
            ############UPDATE2#############
            condition = dat[x[0] + 2:allDelimiter[y + 1][0]]
            condition = debounceBabyBounce(condition)
            newNode = Node(condition, currentNode)
            currentNode.addPositiveChild(newNode)
            newNode.addParent(currentNode)
            currentNode = newNode
            currentNode.easyArray.extend(currentNode.parent.easyArray)
            currentNode.easyArray.append((currentNode.condition, True))
            currentNode.easyArray = list(set(currentNode.easyArray))
            currentNode.delimiter = x[1]
        elif x[1] == 'ELSEIF' or x[1] == 'ELSE IF':
            ############UPDATE2#############
            aboveDelimiter = allDelimiter[y - 1]
            data_between_Delimiters = dat[aboveDelimiter[0] + len(aboveDelimiter[1]):x[0]]
            if len(data_between_Delimiters.strip()) > 0:
                currentNode.statement += data_between_Delimiters.strip()
            ############UPDATE2#############
            condition = dat[x[0] + len(x[1]):allDelimiter[y + 1][0]]
            condition = debounceBabyBounce(condition)
            newNode = Node(condition, currentNode)
            currentNode.addNegativeChild(newNode)
            newNode.addParent(currentNode)
            currentNode = newNode
            currentNode.condition = condition
            currentNode.easyArray.extend(currentNode.parent.easyArray)
            currentNode.easyArray.append((currentNode.condition, True))
            currentNode.easyArray.remove((currentNode.parent.condition, True))
            currentNode.easyArray.append((currentNode.parent.condition, False))
            currentNode.easyArray = list(set(currentNode.easyArray))
            currentNode.delimiter = 'ELSEIF'
            pass
        elif x[1] == 'ENDIF' or x[1] == 'END IF':
            ############UPDATE2#############
            aboveDelimiter = allDelimiter[y - 1]
            data_between_Delimiters = dat[aboveDelimiter[0] + len(aboveDelimiter[1]):x[0]]
            if len(data_between_Delimiters.strip().split()) > 0:
                currentNode.statement += data_between_Delimiters.strip()
            ############UPDATE2#############
            print(currentNode.delimiter)
            while (currentNode.delimiter != 'IF'):
                currentNode = currentNode.parent
            currentNode = currentNode.parent
            pass
        elif x[1] == 'ELSE':
            ############UPDATE2#############
            aboveDelimiter = allDelimiter[y - 1]
            data_between_Delimiters = dat[aboveDelimiter[0] + len(aboveDelimiter[1]):x[0]]
            if len(data_between_Delimiters.strip().split()) > 0:
                currentNode.statement += data_between_Delimiters.strip()
            ############UPDATE2#############
            newNode = Node(condition, currentNode)
            currentNode.addNegativeChild(newNode)
            newNode.addParent(currentNode)
            currentNode = newNode
            currentNode.easyArray.extend(currentNode.parent.easyArray)
            currentNode.easyArray.remove((currentNode.parent.condition, True))
            currentNode.easyArray.append((currentNode.parent.condition, False))
            currentNode.easyArray = list(set(currentNode.easyArray))
            currentNode.delimiter = 'ELSE'
            pass


generateConditionTree()


def printNode(currentNode):
    print('------------------------------')
    print("Delimeter: ", currentNode.delimiter)
    print("Condition : ", currentNode.condition)
    print("EasyArray : ", currentNode.easyArray)
    print("Statement : ", currentNode.statement)
    print("Positive Child : ", currentNode.positiveChild)
    print("Negative Child: ", currentNode.negativeChild)
    print("Parent : ", currentNode.parent)
    print('------------------------------')


# finds out all the nodes with statements,in them
def statmentNodeArrayGen(currentNode):
    global statementNodeArray
    printNode(currentNode)
    if currentNode.statement != '':
        statementNodeArray.append(currentNode)
    for node in currentNode.positiveChild:
        statmentNodeArrayGen(node)
    if currentNode.negativeChild is not None:
        statmentNodeArrayGen(currentNode.negativeChild)


statmentNodeArrayGen(genesis)

# Now to parse the Conditions at each node
conditionDelimeters = ['AND', 'OR', '(', ')', 'NOT']
allConddel = []
# Merge all the conditions of a given statement using AND and NOT
completeCondition = []
for x in statementNodeArray:
    b = x.easyArray
    cond = ''
    for y in b:
        # print (y)
        if y[1]:
            cond += " AND (" + y[0].strip().replace('\n', '') + ") "
        else:
            cond += " AND NOT (" + y[0].strip().replace('\n', '') + ") "
    completeCondition.append((x.statement, cond[5:]))


# Removing NOT case when NOT is not a keyword
def convertEqualNot(cond):
    equalToNot = ['=NOT', 'NOT=']
    notEqualList = [i for i in range(len(cond)) if cond.startswith(equalToNot[0], i)]
    notEqualList.extend([i for i in range(len(cond)) if cond.startswith(equalToNot[1], i)])
    for notequal in notEqualList:
        cond = cond[:notequal] + cond[notequal:notequal + 4].lower() + cond[notequal + 4:]
    return cond


# Removing NOT
completeCondition2 = []
for x in completeCondition:
    completeCondition2.append((x[0], convertEqualNot(x[1])))
completeCondition = completeCondition2


# Find the Next Condition in the String
def findNextCond(string):
    a = [(string.find(x), x) for x in conditionDelimeters]
    a.sort()
    for x in a:
        if x[0] >= 0:
            return x
    return -1


def findAllCondDel(string):
    ad = []
    stringParsed = 0
    while True:
        currDeli = findNextCond(string[stringParsed:])
        # print (currDeli)
        if currDeli == -1:
            break
        currStringParsed = stringParsed
        stringParsed = stringParsed + currDeli[0] + len(currDeli[1])
        currDeli = (currDeli[0] + currStringParsed, currDeli[1])
        ad.append(currDeli)
        # rint ("")
    return ad


# Making the final tuple consisting of Statement,Conditions and combined conditions
completeConditionPart2 = []
for x in completeCondition:
    alldel = findAllCondDel(x[1])
    completeConditionPart2.append((x[0], x[1], alldel))

# Creating the Truth Table
counter = 1
from createTruths import Truths

mapping = {}
reverseMapping = {}
# First the set of conditions is combined to give a boolean expression with the requried mapping to variables
for x in completeConditionPart2:
    variables = []
    delis = x[2]
    boolExpression = ''
    for y in range(0, len(delis) - 1):

        # global counter
        curr = delis[y][0] + len(delis[y][1])
        nex = delis[y + 1][0]
        con = x[1][curr:nex].strip()
        if len(con.split()) != 0:
            variable = ''
            if con not in mapping.keys():
                variable = 'a' + str(counter)
                mapping[con] = variable
                reverseMapping[variable] = con
                counter += 1
            else:
                variable = mapping[con]
            variables.append(variable)
            boolExpression += " " + delis[y][1] + " " + mapping[con]
        else:
            boolExpression += " " + delis[y][1] + " "
    boolExpression += ')'

    boolExpression = boolExpression.lower()
    ## All important Printing
    # Statement
    print("Current Statement is : \n" + x[0] + "\n")

    ## Condition Mappings for Current Statement
    for var in variables:
        print("Mapping of " + reverseMapping[var] + " : " + var)
    ## Print the truth table
    print(Truths(list(set(variables)), [boolExpression], 'Statement'))
    print("=======================================================================================\n")