import os
str1='ASCB Parameter :'
str2='Test By Inspection Test Case['
str3='const'
str4='Line No:'
str5='Failure Description(if any):'
global l
global flat_list
flat_list=[]
lglobal=[]
with open('C:\\TEST\\TOOLS\\EclAscb_14.cpp', 'r', encoding="utf-8") as read:
    with open('C:\\TEST\\TOOLS\\E2E_ECLB_0302.tbi', 'r', encoding="utf-8") as write:
        parsing = False
        flag= False
        parsing1 = False
        flag1= False        
        for line1 in write:            
            line = ' '.join(line1.split())
            if line.startswith(str2):
                parsing = False
                flag=True
            if line.startswith(str1) and flag:
                parsing = True
            if parsing:
                if line.startswith(str1):
                    if line.__contains__('Key') or line.__contains__('Type') or line.__contains__(':'):
                        compare_stringA2, compare_stringB2 = line.split('Key :')
                        compare_stringC2, compare_stringD2 = compare_stringA2.split('#')
                        compare_stringC1, compare_stringD1 = compare_stringC2.split(':')
                        compare_stringA1, compare_stringB1 = compare_stringB2.split(', Details')
                        with open('C:\\TEST\\TOOLS\\EclAscb_14.cpp', 'r', encoding="utf-8") as read:
                            lineCount = 0
                            l=[]
                            for line1 in read:
                                lineCount += 1
                                if line1.__contains__('UNSIGNED32') and line1.__contains__('=') and line1.__contains__('const') and line1.__contains__('__') and line1.__contains__('0x'):
                                    compare_stringZ2, compare_stringY2 = line1.split('=')
                                    compare_stringZ22, compare_stringY21 = compare_stringY2.split(';')
                                    compare_stringW2, compare_stringX2 = compare_stringZ2.split('__')
                                    compare_stringD1=compare_stringD1.strip()
                                    compare_stringX2=compare_stringX2.strip()
                                    compare_stringZ22=compare_stringZ22.strip()
                                    compare_stringA1='0x'+compare_stringA1
                                    compare_stringA1=compare_stringA1.strip()
                                    if(compare_stringD1 == compare_stringX2) and (compare_stringA1 == compare_stringZ22):
                                        string_pass = lineCount,compare_stringD1,compare_stringA1
                                        l.append(string_pass)
                                        break
                                    elif(compare_stringD1 != compare_stringX2) or (compare_stringA1 != compare_stringZ22):                                        
                                        string_fail =compare_stringD1,compare_stringA1 + '---Fail'
                                        l.append(string_fail)
                                        #print (line)
                                        break

                    print(l)
                    lglobal=l.copy()
                                       
            if line.startswith(str4):
                #print(line)
                parsing1 = False
                flag1=True
            if line.startswith(str5) and flag1:
                #print(line)
                parsing1 = True
                print(flat_list)
                #print('\n' +line)


                    

                        
                    
                    
                    
                 
                 



        




                                    
                                    



       
