# Class or variables

class MyFirstclass:
    pass

obj1 = MyFirstclass()
onj2 = MyFirstclass()