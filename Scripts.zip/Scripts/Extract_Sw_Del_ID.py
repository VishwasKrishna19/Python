import string
import os
import sys
import re
import glob
import math
import datetime
import ntpath

path = "C:/Users/h126313/Desktop/NG/PAR/"
files = glob.glob(path + "*PAR*.txt")

for file in files:
    with open(file, 'r') as f:
        with open('C:/Users/h126313/Desktop/NG/CR_Status.txt','a') as wf:
            #wf.write("filename,CR#,Sw DeliveryID#\n")
            filename = os.path.splitext(ntpath.basename(file))[0]
            contents = f.readline()
            while(contents):
                Request_id = re.findall(r"REQUEST ID:", contents, re.IGNORECASE)
                Request_id = contents.split(":")[1].strip()
                for line in f:
                    if "SW Delivery ID :" in line:
                        Current_Status = line.split(":")[1].strip()
                        print(filename + "," + Request_id + "," + Current_Status)
                        Test = filename + "," + Request_id + "," + Current_Status
                        wf.write(filename + "," + Request_id + "," + Current_Status + "")
                        wf.write("\n")
                contents = f.readline()
