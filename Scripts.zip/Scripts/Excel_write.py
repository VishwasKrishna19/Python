import win32com.client

# opening the source excel file

excel_app = win32com.client.dynamic.Dispatch("Excel.Application")


filename = "C:\\Vishwas\\Task_Assigned\\Python\\Prem\\Simgen\\SimgenFormat.xlsx"
xlBookread = excel_app.Workbooks.Open(filename)
xlSheetread = xlBookread.Worksheets('Sheet')
#wb1 = xl.load_workbook(filename)
#ws1 = wb1.worksheets[0]

mr = xlSheetread.UsedRange.Rows.Count
mc = xlSheetread.UsedRange.Columns.Count

excel_app.Interactive = False
excel_app.Visible = 0
excel_app.DisplayAlerts = False
xlBook = excel_app.Workbooks.Open("C:\\Vishwas\\Task_Assigned\\Python\\Prem\\Simgen\\ASTC71_Test.xls")
xlSheet = xlBook.Worksheets('Sheet1')
row_count = xlSheet.UsedRange.Rows.Count
xlOpenXMLWorkbookMacroEnabled = 52

for i in range(1, mr + 1):
    for j in range(1, mc + 1):
        # reading cell value from source excel file
        c = xlSheetread.cells(i+1, j)
        xlSheet.cells(i+20, j).value = c.value


xlBook.SaveAs("C:\\Vishwas\\Task_Assigned\\Python\\Prem\\Simgen\\ASTC71_Test.xls",
                  FileFormat=xlOpenXMLWorkbookMacroEnabled)

excel_app.Quit()
del excel_app