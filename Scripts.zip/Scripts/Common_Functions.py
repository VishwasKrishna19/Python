import pyodbc
import os

def commonfunctions(server,database,cmfpath):

    driver = '{SQL Server}' # Driver you need to connect to the database

    cnn = pyodbc.connect('DRIVER='+driver+';SERVER='+server+';DATABASE='+database+';Trusted_Connection=yes;')

    dataCursor = cnn.cursor()

    droptable_sql = """
    IF OBJECT_ID('CommonFunctions', 'U') IS NOT NULL 
      DROP TABLE CommonFunctions; 
    """

    dataCursor.execute(droptable_sql)

    createTable_sql = """
    CREATE TABLE CommonFunctions
    (  
        Function_Name nvarchar (500)  
        ,Inputs nvarchar (500)
        ,Filename nvarchar(500) 
    ); 
    """

    dataCursor.execute(createTable_sql)

    insertRow_sql = """
    INSERT INTO CommonFunctions(Function_Name, Inputs, Filename) 
        VALUES (?, ?, ?)
    """

    for filename in os.listdir(cmfpath):
        basename, extension = os.path.splitext(filename)
        if extension == ".tsf":
            SupportFilePath = cmfpath + "\\" + filename
            with open(SupportFilePath, 'r') as file :
                filedata = file.readlines()
            Functionname = ""
            for line in filedata:
                line = line.lstrip()
                line = line.rstrip()
                if (line.startswith('Function') or line.startswith('Sub')) and line.endswith(')'):
                    line = line.split(' ', 1)[1]
                    Functionname = line.partition("(")[0]
                    Functionname = Functionname.lstrip()
                    Functionname = Functionname.rstrip()
                    line = line.partition("(")[2]
                    Inputs = line.rstrip(")")
                    if Inputs != "":
                        Inputs = Inputs.split(",")
                        Inputs = [item.lstrip() for item in Inputs]
                        Inputs = [item.rstrip() for item in Inputs]
                        Inputs = ", ".join(Inputs)
                    dataCursor.execute(insertRow_sql, Functionname, Inputs, filename)
            templine = ""
            for line in filedata:
                line = line.lstrip()
                line = line.rstrip()
                if (line.startswith('Function') or line.startswith('Sub')) and line.endswith('_'):
                    templine = line
                elif templine != "" and line.endswith('_'):
                    templine = templine + line
                elif templine != "" and line.endswith(")"):
                    templine = templine + line
                elif templine != "":
                    line = templine.split(' ', 1)[1]
                    Functionname = line.partition("(")[0]
                    line = line.partition("(")[2]
                    Inputs = line.rstrip(")")
                    if Inputs != "":
                        Inputs = Inputs.split(",")
                        Inputs = [item.lstrip() for item in Inputs]
                        Inputs = [item.rstrip() for item in Inputs]
                        Inputs = ", ".join(Inputs)
                    dataCursor.execute(insertRow_sql, Functionname, Inputs, filename)
                    templine = ""
            print(filename + " Supporting File Parsed")
    cnn.commit()