import csv
import os

with open('C:/Vishwas/TASKS_ASSIGNED/Verification_Deliverables/CD_MEDIA/TSC/Final/file.txt') as f:
    with open('C:/Vishwas/TASKS_ASSIGNED/Verification_Deliverables/CD_MEDIA/TSC/Final/file_updated.txt', 'w', newline='') as wf:
        for line in f:
            if '.metadata-dir' not in line and '.metadata-item' not in line and '.metadata-config' not in line and '.' in line:
                wf.write(line)