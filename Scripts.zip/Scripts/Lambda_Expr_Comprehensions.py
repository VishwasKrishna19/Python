#Lambda Expression

#lambda parameter: action(parameter)
my_list = [1,2,3,4]
print(list(map(lambda item: item*2, my_list)))

my_list1 = [5,4,3]
print(list(map(lambda item: item**2, my_list1)))

a = [(0,2), (4,3), (10, -1), (9,9)]
a.sort(key = lambda x : x[1])
print(a)

#Comprehension
#List Comprehensions - it is the short form of creating list without for loop and all
#Set Comprehensions
#Dictionary Comprehensions

#Below is the old Method to add to the List
my_list2 = []
for char in 'hello':
    my_list2.append(char)

print(my_list2)

#With List Comprehension is as Below
#my_list2 = [char for char in iterable]
my_list2 = [char for char in 'iterable']
print(my_list2)

my_list3 = [num**2 for num in range(0,100)]
my_list4 = [num**2 for num in range(0,100) if num%2 == 0]
print(my_list4)

#set comprehension
my_list2 = {char for char in 'iterable'}
print(my_list2)

#Dictionary Comprehension
simple_dict = {'a':1, 'b':2}
my_dict = {key:value**2 for key,value in simple_dict.items() if value % 2 == 0}
print(my_dict)

my_dict2 = {num:num*2 for num in [1,2,3]}
print(my_dict2)

print('**********************************************************************************')
some_list = ['a', 'b', 'c', 'd', 'b', 'e', 'd']
duplicates = []
for values in some_list:
    if some_list.count(values) > 1:
        if values not in duplicates:
            duplicates.append(values)

print(duplicates)

duplicates1 = list({item for item in some_list if some_list.count(item) > 1})
print(duplicates1)