import InitialSupport
 
from InitialSupport import *
TestName = "CII_S07C_0087_HW3"
Startsum(TestName)
#=====================================================================================================
#CORE INAV SOFTWARE TEST PLAN/PROCEDURE
Output ("=============================================================================================")
Output ("TestName            : CII_S07C_0087_HW3")
Output ("ParagraphTitle  : Radio Tuning")
Output ("=============================================================================================")
Output ("=============================================================================================")
Output ("                                 MODIFICATION HISTORY                			            ")
Output ("=============================================================================================")
Output (" Version    Date          Author           Change Description                      CH_DOC        ")
Output ("=============================================================================================")
Output ("  01    16-Mar-17      Pradeep     Load 3.5.2:Intial Version for HW3 Execution    EDS_PRD_CINAV_PAR_952/EDS_PRD_CINAV_TR_3254")
Output ("=============================================================================================")
Output ("                                 REQUIREMENT TAGS (PARAGRAPH AND SHALL)                      ")
Output ("=============================================================================================")
Output ("Primary Paragraph Tag             :[PTAG::SRD C CINAV RADIO TUNING]")
Output ("Template Class                    : CUSTOM  ")
Output ("=============================================================================================")
#=====================================================================================================
# TestCase::Shall Tag                                      TemplateType        
#=====================================================================================================
#[TC a::SRD C CINAV RADIO TUNING 10]                       Test By Inspection  
#[TC b::SRD C CINAV RADIO TUNING 20]                       Test By Inspection
#=====================================================================================================
#                                    TEST ENVIRONMENT SPECIFICATION
#===============================================================================================================
#                                        HARDWARE SETUP
#============================================================================================================
#  Environment              :  Host Specific HardWare Environment, See Note below 
#  ESCAPE Configuration DB  :  Host Specific Configuration database(*.mdb), See Note below
#  ESCAPE Configuration Name:  Host Specific Configuration Name, See Note below 
#  ESCAPE Configuration is used for setting up the test environment only
#  Note: For host specific H/W environment setup refer section #Test Environment setup# from CORE_INAV_TEST_STRATEGY.doc available in PVCS at 
#  the location: INAV\CORE_INAV\TEST\TEST_MISC\ (Work Set: EDS_PRD:_WORK_MAIN). 
#==============================================================================================================
#                                         SOFTWARE SETUP 
#=====================================================================================================
# For this file to be executed, the custom built modules should be loaded. Refer the Build Procedure document (Build_Procedure.doc)
# present in the TaskMenu_RadioTuning_Support.zip available in PVCS at the location: INAV\CORE_INAV\TEST\TEST_MISC\ (Work Set: EDS_PRD:_WORK_MAIN). 
# and load customized modules to corresponding cards and point vars in TIU Server as per build procedure.
#=====================================================================================================
#                                        GENERAL COMMENTS
#-----------------------------------------------------------------------------------------------------
# As CORE INAV is common for different hosts and hosts are having different User interfaces, Menus/Layers selection procedures might be different. 
# Refer COREINAV_Menu_Selection_Procedures_Guide.doc available in PVCS at the location: INAV\CORE_INAV\TEST\TEST_MISC\ (Work Set: EDS_PRD:_WORK_MAIN)
# for detailed procedures for Menus/Layers selection.
#==============================================================================================================
#                                    GENERAL SET-UP COMMANDS
#==============================================================================================================
#Following files are to be included in the project and should be in the following order:
#     1. QualifiedSupport.tsf
#     2. ComConstantsAndFunctions.tsf
#     3. GGF_ComConstantsAndFunctions.tsf
# 	   4. CII_S07C_0087_HW3.tsf
#=====================================================================================================
#                                        DEFINE VARIABLES
#-----------------------------------------------------------------------------------------------------
global TemplateClass,PTAG,Input_Condition,Expected_Result,TestID,CA_Justification,Category,Tst_TunefreqVOR
global Host_Id
#=====================================================================================================
#                                      INITIAL CONDITIONS
#-----------------------------------------------------------------------------------------------------
TemplateClass = CUSTOM

PTAG = "SRD C CINAV RADIO TUNING"
Shall_Level_Test()


#*************************************************************************************************************
#Name   : DectoString
#Purpose: To Convert the Decimal Value to a String
#Usage  : DectoString VAR1
#         VAR1 -- Decimal value
#Returns: String
#Example: DectoString 65
#-------------------------------------------------------------------------------------------------------------
Function DectoString(VAR1) 

global str22,count,temp, Str33
temp = Trim(VAR1 Mod 16) 
VAR1 = (Int)(VAR1/16) 
count =1 
Do While(VAR1 > 0) 
count = count+1 
temp = (16*Trim((VAR1 Mod 16))) + temp 
VAR1 = Int(VAR1/16) 
If count Mod 2 = 0:   
str22 = str22 & Chr(temp) 
temp = Trim(VAR1 Mod 16) 
VAR1 = Int(VAR1/16) 
count =1 
#End If 
Loop 

DectoString=Str22 

End Function

#-------------------------------------------------
Function MergeChars(variable,length)
global loopvar,var
var=""
For loopvar=0 To length-1
var = var & DectoString(Acquire(variable(loopvar)))
Next
MergeChars = var
End Function
#----------------------------------------------------
#===================================================================================================
#                                          TEST CASES
#===================================================================================================
#***********************************************************************************************************
#SRD C CINAV RADIO TUNING 10 -- Test By Inspection
#***********************************************************************************************************
#=====================================================================================================
#	TestStep     :	a1
#	Description  :	Independent Code Analysis.
#	PassCriteria :	Code Analysis being performed by person other than the author of the code Analysis 
#Initials: _______________
#-----------------------------------------------------------------------------------------------------
#=====================================================================================================
#=====================================================================================================
#	TestStep     :	a2
#	Description  :	Name and CM Version of file under review
#	PassCriteria :	Module and/or Function Name: _________________      CM Version: ____               
#Document chapter: __________    CM Version: _____
#-----------------------------------------------------------------------------------------------------
#=====================================================================================================
#=====================================================================================================
#	TestStep     :	a3
#	Description  :	Requirements Implemented.  Identify which lines of code in the module under review 
#incorporate requirements  _________________________________
#	PassCriteria :	Code implements the requirements as defined in the requirement document  Y/N  ___
#-----------------------------------------------------------------------------------------------------
#=====================================================================================================
#=====================================================================================================
#	TestStep     :	a4
#	Description  :	Structural Coverage Analysis
#	PassCriteria :	Software and software structures (when applicable) are accessible under conditions 
#specified by requirements  Y/N:  _____
#-----------------------------------------------------------------------------------------------------
#===========================================================================================================
If (CompareShallTag(10)):

Initialization ("a -- SRD C CINAV RADIO TUNING 10 -- Test By Inspection")
	
Output ("TEST CASE -1")
#----------------------
Input_Condition  = "	When a button press event is received from the Host AND Ev_ButtonPress.ButtonId is InavTaskMenuTuneNav1 "\
"then INAV will send an event Ev_RadioTune# with the Event Record Header, Evt_RadioNavAidTune  And Event Record Data To host process Evt_RadioNavAidTune"
Expected_Result  = "Updates the Event Record for NAV1 Radio Tune event "
TestID           = "SRD C CINAV RADIO TUNING 10"
CA_Justification = "As the Host does not the Tune Nav, due to this limitation Test By Inspection is called"
Category         = EL 
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

Input_Condition  = "	When a button press event is received from the Host AND Ev_ButtonPress.ButtonId is InavTaskMenuTuneNav2"\
": INAV will send an event Ev_RadioTune# with the Event Record Header, Evt_RadioNavAidTune  And Event Record Data To host process Evt_RadioNavAidTune"
Expected_Result  = "Updates the Event Record for NAV2 Radio Tune event "
TestID           = "SRD C CINAV RADIO TUNING 10"
CA_Justification = "As the Host does not the Tune Nav, due to this limitation Test By Inspection is called"
Category         = EL 
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

Input_Condition  = "	When a button press event is received from the Host AND Ev_ButtonPress.ButtonId is InavTaskMenuTuneNav3"\
"then INAV will send an event Ev_RadioTune# with the Event Record Header, Evt_RadioNavAidTune  And Event Record Data To host process Evt_RadioNavAidTune"
Expected_Result  = "Updates the Event Record for NAV3 Radio Tune event "
TestID           = "SRD C CINAV RADIO TUNING 10"
CA_Justification = "As the Host does not the Tune Nav, due to this limitation Test By Inspection is called"
Category         = EL 
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If
#===================================================================================================
#***********************************************************************************************************
#SRD C CINAV RADIO TUNING 20 -- Test By Inspection
#***********************************************************************************************************
#=====================================================================================================
#	TestStep     :	a1
#	Description  :	Independent Code Analysis.
#	PassCriteria :	Code Analysis being performed by person other than the author of the code Analysis 
#Initials: _______________
#-----------------------------------------------------------------------------------------------------
#=====================================================================================================
#=====================================================================================================
#	TestStep     :	a2
#	Description  :	Name and CM Version of file under review
#	PassCriteria :	Module and/or Function Name: _________________      CM Version: ____               
#Document chapter: __________    CM Version: _____
#-----------------------------------------------------------------------------------------------------
#=====================================================================================================
#=====================================================================================================
#	TestStep     :	a3
#	Description  :	Requirements Implemented.  Identify which lines of code in the module under review 
#incorporate requirements  _________________________________
#	PassCriteria :	Code implements the requirements as defined in the requirement document  Y/N  ___
#-----------------------------------------------------------------------------------------------------
#=====================================================================================================
#=====================================================================================================
#	TestStep     :	a4
#	Description  :	Structural Coverage Analysis
#	PassCriteria :	Software and software structures (when applicable) are accessible under conditions 
#specified by requirements  Y/N:  _____
#-----------------------------------------------------------------------------------------------------
#===========================================================================================================
If (CompareShallTag(20)):

Initialization ("b -- SRD C CINAV RADIO TUNING 20 -- Test By Inspection")
	
Output ("TEST CASE -1")
#----------------------
Input_Condition  = "	When a button press event is received from the Host AND Ev_ButtonPress.ButtonId is InavTaskMenuTuneADF1"\
"then INAV will send an event Ev_RadioTune# with the Event Record Header, Evt_RadioNavAidTune  And Event Record Data To host process Evt_RadioNavAidTune"
Expected_Result  = "Updates the Event Record for ADF1 Radio Tune event"
TestID           = "SRD C CINAV RADIO TUNING 10"
CA_Justification = "As the Host does not the Tune Adf, due to this limitation Test By Inspection is called"
Category         = EL 
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

Input_Condition  = "	When a button press event is received from the Host AND Ev_ButtonPress.ButtonId is InavTaskMenuTuneADF2"\
": INAV will send an event Ev_RadioTune# with the Event Record Header, Evt_RadioNavAidTune  And Event Record Data To host process Evt_RadioNavAidTune"
Expected_Result  = "Updates the Event Record for ADF2 Radio Tune event"
TestID           = "SRD C CINAV RADIO TUNING 10"
CA_Justification = "As the Host does not the Tune Adf, due to this limitation Test By Inspection is called"
Category         = EL 
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

Input_Condition  = "	When a button press event is received from the Host AND Ev_ButtonPress.ButtonId is InavTaskMenuTuneADF3"\
"then INAV will send an event Ev_RadioTune# with the Event Record Header, Evt_RadioNavAidTune  And Event Record Data To host process Evt_RadioNavAidTune"
Expected_Result  = "Updates the Event Record for ADF3 Radio Tune event"
TestID           = "SRD C CINAV RADIO TUNING 10"
CA_Justification = "As the Host does not the Tune Adf, due to this limitation Test By Inspection is called"
Category         = EL 
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If

#====================================================================================================
#                                      PRINT FINAL RESULTS                                   
#====================================================================================================
ReportSummary()
