	import InitialSupport

from InitialSupport import *
TestName = "E2C_UTLB_0701"
Startsum(TestName)
#============================================================================================================
#                   CONTROL ABSTRACTION LAYER FUNCTION SOFTWARE TEST PLAN/PROCEDURE
Output ("=====================================================================================================")
Output (" TestName       :  E2C_UTLB_0701                                                               ")
Output ("=====================================================================================================")
Output ("                                   MODIFICATION HISTORY                                              ")
Output ("=====================================================================================================")
Output (" Version   Date       Author              Change Description                     CH_DOC              ")
Output (" ------- ---------  --------------   ----------------------------------         ---------            ")
#Output "    01   30-Nov-15   Navneet K.     Load 2.0: Initial Development        EDS_CALF_EJETE2_SCR_131/EDS_CALF_EJETE2_VR_555 " 
#Output "    02   21-Dec-15   Navneet K.   Rework: Rework done as per Review comments     EDS_CALF_EJETE2_SCR_131/EDS_CALF_EJETE2_VR_555 "  
#Output "    03   24-Feb-16   Navneet K.   Load 2.0: Added Testcase z for             EDS_CALF_EJETE2_VR_674 "
#Output "                                            Requirement SDD_CALF_12127                              " 
Output ("     04   29-Jul-16   Navneet K      Load 3.0:Testcase n updated for           EDS_CALF_EJETE2_VR_782")
Output ("                                     implementing EDS_CALF_EJETE2_SCR_168                             ")
Output ("=====================================================================================================")
#=============================================================================================================
#                                     TEST ENVIRONMENT SPECIFICATION
#-------------------------------------------------------------------------------------------------------------
# Environment               : MAU Mini-bench with a NGCIO card Or PMProc Card
# ESCAPE Configuration DB   : EJETE2_Configuration_Data.mdb
# ESCAPE Configuration Name : Embraer EJETS E2 || EJETE2_EASE
# Hyperstart Name           : cio1.bin  for NGCIO Card Or Proc1.bin for PMProc Card
# Additional Information    : NA

# The steps required to set-up a Mini bench is described in Guidelines_For_E2_Bench_Setup document.
#=============================================================================================================
#                                      GENERAL COMMENTS
#-------------------------------------------------------------------------------------------------------------
#This test needs to be executed on both MAU and NGCIO software baselines

#=============================================================================================================
#                                     GENERAL SET-UP COMMANDS
#-------------------------------------------------------------------------------------------------------------
# Following files are to be included in the project and should be in the following order:
#
# 1. QualifiedSupport.tsf               
# 2. ComConstantsAndFunctions.tsf    
# 3. E2C_UTLB_0701.tsf
#
#=============================================================================================================
#                                      DEFINE VARIABLES
#=============================================================================================================
global Input_Condition, Expected_Result, Object_ID, CA_Justification, Category

#=============================================================================================================
#                                     SUBROUTINES AND SUBFUNCTIONS
#-------------------------------------------------------------------------------------------------------------
#
#=============================================================================================================
#                                      INITIAL CONDITIONS
#=============================================================================================================
ObjectID_Level_Test() # Object ID level testing
Output ("")

#=============================================================================================================
#                                       TEST CASES AND PROCEDURES
#=============================================================================================================

If CompareObjectID("SDD_CALF_11855"):
#-------------------------------------------------------------------------------------------------------------
# TestCase         : a1
# Input Conditions : Set 
#                    Data is less than Low
# Expected OutPuts : Verify
#                    UtlLimit returns Low
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC a1::SDD_CALF_11855]            -   Test By Inspection")

Input_condition  = "Data is less than Low"
Expected_Result  = "UtlLimit returns Low"
Object_ID        = "SDD_CALF_11855"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#-------------------------------------------------------------------------------------------------------------
# TestCase         : a2
# Input Conditions : Set 
#                    Data is greater than High
# Expected OutPuts : Verify
#                    UtlLimit returns High
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC a2::SDD_CALF_11855]            -   Test By Inspection")

Input_condition  = "Data is greater than High"
Expected_Result  = "UtlLimit returns High"
Object_ID        = "SDD_CALF_11855"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#-------------------------------------------------------------------------------------------------------------
# TestCase         : a3
# Input Conditions : Set 
#                    Data is greater than Low and less than High
# Expected OutPuts : Verify
#                    UtlLimit returns Data
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC a3::SDD_CALF_11855]            -   Test By Inspection")

Input_condition  = "Data is greater than Low and less than High"
Expected_Result  = "UtlLimit returns Data"
Object_ID        = "SDD_CALF_11855"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If #CompareObjectID 

#----------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_12135"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : b1
# Input Conditions : Set 
#				         Data is greater than Limit
# Expected OutPuts : Verify
#                    UtlLimitUnit returns Limit
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC b1::SDD_CALF_12135]            -   Test By Inspection")

Input_condition = "Data is greater than Limit"
Expected_Result = "UtlLimitUnit returns Limit"
Object_ID = "SDD_CALF_12135"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : b2
# Input Conditions : Set 
#				         Data is not greater than Limit
# Expected OutPuts : Verify
#                   UtlLimitUnit returns Data
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC b2::SDD_CALF_12135]            -   Test By Inspection")

Input_condition = "Data is not greater than Limit"
Expected_Result = "UtlLimitUnit returns Data"
Object_ID = "SDD_CALF_12135"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If #CompareObjectID 
#----------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11859"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : c1
# Input Conditions : Set 
#				              1. InParm is TRUE
#                        2. Contents of Timer is equal to 0 
# Expected OutPuts : Verify
#                         1. Contents of Timer is set to TimeLimitOn
#                         2. Contents of OutParm is set to True.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC c1::SDD_CALF_11859]            -   Test By Inspection")

Input_condition = "InParm is set to TRUE and Contents of Timer is equal to 0"
Expected_Result = "Contents of Timer is set to TimeLimitOn and Contents of OutParm is set to True"
Object_ID = "SDD_CALF_11859"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#----------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : c2
# Input Conditions : Set 
#				              1. InParm is TRUE
#                        2. Contents of Timer is equal to 1
#                        3. Contents of OutParm is equal to TRUE
# Expected OutPuts : Verify
#                         1. Contents of Timer is set to TimeLimitOn
#                         2. Contents of OutParm is set to False.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC c2::SDD_CALF_11859]            -   Test By Inspection")

Input_condition = "InParm is set to TRUE, Contents of Timer is equal to 1 and Contents of OutParm is equal to TRUE"
Expected_Result = "Contents of Timer is set to TimeLimitOn and Contents of OutParm is set to False"
Object_ID = "SDD_CALF_11859"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#----------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : c3
# Input Conditions : Set 
#				              1. InParm is TRUE
#                        2. Contents of Timer is equal to 1
#                        3. Contents of OutParm is not equal to TRUE
# Expected OutPuts : Verify
#                         1. Contents of Timer is set to TimeLimitOFF
#                         2. Contents of OutParm is set to True.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC c3::SDD_CALF_11859]            -   Test By Inspection")

Input_condition = "InParm is set to TRUE, Contents of Timer is equal to 1 and Contents of OutParm is not equal to TRUE"
Expected_Result = "Contents of Timer is set to TimeLimitOFF and Contents of OutParm is set to True"
Object_ID = "SDD_CALF_11859"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#----------------------------------------------------------------------------------------------------------------------------------------------------------

# TestCase         : c4
# Input Conditions : Set 
#				              1. InParm is TRUE
#                        2. Contents of Timer is not equal to 1 neither equal to 0.
# Expected OutPuts : Verify
#                         1. Decrement the content of Timer.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC c4::SDD_CALF_11859]            -   Test By Inspection")

Input_condition = "InParm is set to TRUE and Contents of Timer is not equal to 1 neither equal to 0"
Expected_Result = "Decrement the content of Timer"
Object_ID = "SDD_CALF_11859"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#----------------------------------------------------------------------------------------------------------------------------------------------------------

# TestCase         : c5
# Input Conditions : Set 
#				              1. InParm is not TRUE
# Expected OutPuts : Verify
#                         1. contents of OutParm is False.
#                         2. contents of Timer is 0.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC c5::SDD_CALF_11859]            -   Test By Inspection")

Input_condition = "InParm is set to not True"
Expected_Result = "contents of OutParm is False and contents of Timer is 0"
Object_ID = "SDD_CALF_11859"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If #CompareObjectID 

#----------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11864"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : d1
# Input Conditions : Set 
#				              1. Low is less than or equal to Zero
#                        2. HIGH is greater than or equal to Zero 
# Expected OutPuts : Verify
#                         Zerocrossing = 1 
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC d1::SDD_CALF_11864]            -   Test By Inspection")

Input_condition = "Low is less than or equal to Zero and HIGH is greater than or equal to Zero"
Expected_Result = "Zerocrossing is set to 1"
Object_ID = "SDD_CALF_11864"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : d2
# Input Conditions : Set 
#				              1. Low is not less than or equal to Zero
#                        2. HIGH is greater than or equal to Zero 
# Expected OutPuts : Verify
#                         Zerocrossing = 0
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC d2::SDD_CALF_11864]            -   Test By Inspection")

Input_condition = "Low is not less than or equal to Zero and HIGH is greater than or equal to Zero"
Expected_Result = "Zerocrossing is set to 0"
Object_ID = "SDD_CALF_11864"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : d3
# Input Conditions : Set 
#				              1. Low is less than or equal to Zero
#                        2. HIGH is not greater than or equal to Zero 
# Expected OutPuts : Verify
#                         Zerocrossing = 0
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC d3::SDD_CALF_11864]            -   Test By Inspection")

Input_condition = "Low is less than or equal to Zero and HIGH is not greater than or equal to Zero"
Expected_Result = "Zerocrossing is set to 0"
Object_ID = "SDD_CALF_11864"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : d4
# Input Conditions : Set 
#				              1. Low is not less than or equal to Zero
#                        2. HIGH is not greater than or equal to Zero 
# Expected OutPuts : Verify
#                         Zerocrossing = 0
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC d4::SDD_CALF_11864]            -   Test By Inspection")

Input_condition = "Low is not less than or equal to Zero and HIGH is not greater than or equal to Zero"
Expected_Result = "Zerocrossing is set to 0"
Object_ID = "SDD_CALF_11864"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : d5
# Input Conditions : Set 
#				              Data is less than Low
#                        
# Expected OutPuts : Verify
#                         UtlCircularLimit returns (Data + High + Zerocrossing)
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC d5::SDD_CALF_11864]            -   Test By Inspection")

Input_condition = "Data is less than Low"
Expected_Result = "UtlCircularLimit returns (Data + High + Zerocrossing)"
Object_ID = "SDD_CALF_11864"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : d6
# Input Conditions : Set 
#				              Data is greater than High
#                        
# Expected OutPuts : Verify
#                         UtlCircularLimit returns (Data - High - Zerocrossing)
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC d6::SDD_CALF_11864]            -   Test By Inspection")

Input_condition = "Data is greater than High"
Expected_Result = "UtlCircularLimit returns (Data - High - Zerocrossing)"
Object_ID = "SDD_CALF_11864"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : d7
# Input Conditions : Set 
#				              Data is neither less than Low nor greater than High
#                        
# Expected OutPuts : Verify
#                         UtlCircularLimit returns Data 
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC d7::SDD_CALF_11864]            -   Test By Inspection")

Input_condition = "Data is neither less than Low nor greater than High"
Expected_Result = "UtlCircularLimit returns Data"
Object_ID = "SDD_CALF_11864"
CA_Justification = "It is not possible to check the library function for limiting passed values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID 

#---------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11868"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : e1
# Input Conditions : Set 
#				              1. X is less than 0.
#                        
# Expected OutPuts : Verify
#                       1. z is set to -0.5 
#                       2. using z as input rounded number is calculated as radix  * ( (x/radix) + z ) 
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC e1::SDD_CALF_11868]            -   Test By Inspection")

Input_condition = "X is less than 0"
Expected_Result = "z is set to -0.5 and using z as input rounded number is calculated as radix  * ( (x/radix) + z )"
Object_ID = "SDD_CALF_11868"
CA_Justification = "It is not possible to check the library function for rounding passed floating point values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : e2
# Input Conditions : Set 
#				              1. X is greater than 0.
#                        
# Expected OutPuts : Verify
#                       1. z is set to +0.5 
#                       2. using z as input rounded number is calculated as radix  * ( (x/radix) + z ) 
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC e2::SDD_CALF_11868]            -   Test By Inspection")

Input_condition = "X is greater than 0"
Expected_Result = "z is set to +0.5 and using z as input rounded number is calculated as radix  * ( (x/radix) + z )"
Object_ID = "SDD_CALF_11868"
CA_Justification = "It is not possible to check the library function for rounding passed floating point values in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If #CompareObjectID 

#---------------------------------------------------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_12076"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : f1
# Input Conditions : None
#				              
#                        
# Expected OutPuts : Verify
#                       UtlMovx copies blocks of memory from a source to a destination.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC f1::SDD_CALF_12076]            -   Test By Inspection")

Input_condition = "Source and destination is available"
Expected_Result = "UtlMovx copies blocks of memory from a source to a destination)"
Object_ID = "SDD_CALF_12076"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If #CompareObjectID 

#---------------------------------------------------------------------------------------------------------------------------------------------------------





If CompareObjectID("SDD_CALF_12079"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : g1
# Input Conditions : None
#				              
#                        
# Expected OutPuts : Verify
#                       UtlMov4 moves data from a source to a destination in 32bits at a time.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC g1::SDD_CALF_12079]            -   Test By Inspection")

Input_condition = "Source and destination is available"
Expected_Result = "UtlMov4 moves data from a source to a destination in 32bits at a time.)"
Object_ID = "SDD_CALF_12079"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#End If #CompareObjectID 
#---------------------------------------------------------------------------------------------------------------------------------------------------------




If CompareObjectID("SDD_CALF_12082"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : h1
# Input Conditions : None
#				              
#                        
# Expected OutPuts : Verify
#                       UtlSet4 initializes data at a destination in 32 bits at a time.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC h1::SDD_CALF_12082]            -   Test By Inspection")

Input_condition = "data is available at a destination for initialization"
Expected_Result = "UtlSet4 initializes data at a destination in 32 bits at a time.)"
Object_ID = "SDD_CALF_12082"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#End If #CompareObjectID 
#---------------------------------------------------------------------------------------------------------------------------------------------------------




If CompareObjectID("SDD_CALF_12137"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : i1
# Input Conditions : None
#				                                      
# Expected OutPuts : Verify
#                       Init initializes the classs members as specified below:
#                                                   m_Position To zero(0)
#                                                   m_Delta To zero(0)
#                                                   m_LowerPositionLimit To input lowerLimit value
#                                                   m_UpperPositionLimit To input upperLimit value
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC i1::SDD_CALF_12137]            -   Test By Inspection")

Input_condition = "data is available for initialization"
Expected_Result = "Init initializes the classs members as specified below"& vbLf &_
                  "m_Position To zero(0)"& vbLf &_
                  "m_Delta To zero(0)"& vbLf &_
                  "m_LowerPositionLimit To input lowerLimit value"& vbLf &_
                  "m_UpperPositionLimit To input upperLimit value"

Object_ID = "SDD_CALF_12137"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID 
#---------------------------------------------------------------------------------------------------------------------------------------------------------



If CompareObjectID("SDD_CALF_11876"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : j1
# Input Conditions : None
#				                                      
# Expected OutPuts : Verify
#                       1. Process7bit Processes a 7-bit raw delta knob value from the DC RS-422 transmission 
#                       2. m_Position is gettting updated using the 7 bit delta value.                             
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC j1::SDD_CALF_11876]            -   Test By Inspection")

Input_condition = "7-bit raw delta knob value is available for processing"
Expected_Result = "Process7bit processes a 7-bit raw delta knob value from the DC RS-422 transmission and"& vbLf &_
                  "m_Position 	gets updated using the 7 bit delta value"

Object_ID = "SDD_CALF_11876"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID
#---------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11893"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : k1
# Input Conditions : None
#				                                      
# Expected OutPuts : Verify
#                       1. Process processes a raw positional knob value with a range of 0 to127 
#                       2. m_delta value is gettting updated.                             
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC k1::SDD_CALF_11893]            -   Test By Inspection")

Input_condition = "raw positional knob value is available for processing"
Expected_Result = "Process processes a raw positional knob value with a range of 0 to127 and"& vbLf &_
                  "m_delta value gets updated"

Object_ID = "SDD_CALF_11893"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID

#---------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11903"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : l1
# Input Conditions : None
#				                                      
# Expected OutPuts : Verify
#                       Init initializes the data members of the class to the values specified below:
#                                                   m_InputSignal  = 0 
#                                                   m_InputOnTime  = 0 
#                                                   m_InputOffTime = 0 
#                                                   m_InputOn      = false 
#                                                   m_TrippedOn    = false
#                                                   m_TrippedOff   = false 
#                                                   m_OffThreshold = triggerOffInputThreshold 
#                                                   m_OffDelay     = triggerOffDelay
#                                                   m_OnThreshold  = triggerOnInputThreshold
#                                                   m_OnDelay      = triggerOnDelay
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC l1::SDD_CALF_11903]            -   Test By Inspection")

Input_condition = "data members of the class are available for initialization"
Expected_Result = "Init initializes the data members of the class to the values specified below"& vbLf &_
                  "m_InputSignal  = 0"& vbLf &_
                  "m_InputOnTime  = 0"& vbLf &_
                  "m_InputOffTime = 0"& vbLf &_
                  "m_InputOn      = false"& vbLf &_
                  "m_TrippedOn    = false"& vbLf &_
                  "m_TrippedOff   = false"& vbLf &_
                  "m_OffThreshold = triggerOffInputThreshold"& vbLf &_
                  "m_OffDelay     = triggerOffDelay"& vbLf &_
                  "m_OnThreshold  = triggerOnInputThreshold"& vbLf &_
                  "m_OnDelay      = triggerOnDelay"

Object_ID = "SDD_CALF_11903"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID
#---------------------------------------------------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_11908"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : m1
# Input Conditions : None
#				                                      
# Expected OutPuts : Verify
#                       Process processes the input signal by invoking ProcessInput() and ProcessTrigger()                            
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC m1::SDD_CALF_11908]            -   Test By Inspection")

Input_condition = "Input signal is available for processing"
Expected_Result = "Process processes the input signal by invoking ProcessInput() and ProcessTrigger()"
                  

Object_ID = "SDD_CALF_11908"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID

#---------------------------------------------------------------------------------------------------------------------------------------------------------



If CompareObjectID("SDD_CALF_11911"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : n1
# Input Conditions : m_OnThreshold  is greater than m_OffThreshold
#				                                      
# Expected OutPuts : Verify
#                       m_InputOn is assigned with Boolean which indicates that m_InputSignal is greater or equal to m_OnThreshold                            
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC n1::SDD_CALF_11911]            -   Test By Inspection")

Input_condition = "m_OnThreshold  is greater than m_OffThreshold"
Expected_Result = "m_InputOn is assigned with Boolean which indicates that m_InputSignal is greater or equal to m_OnThreshold"
                  

Object_ID = "SDD_CALF_11911"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : n2
# Input Conditions : m_OnThreshold  is less than  m_OffThreshold
#				                                      
# Expected OutPuts : Verify
#                       m_InputOn is assigned with Boolean which indicates that m_InputSignal is lesser or equal to m_OnThreshold                             
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC n2::SDD_CALF_11911]            -   Test By Inspection")

Input_condition = "m_OnThreshold  is less than  m_OffThreshold"
Expected_Result = "m_InputOn is assigned with Boolean which indicates that m_InputSignal is lesser or equal to m_OnThreshold"
                  

Object_ID = "SDD_CALF_11911"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : n3
# Input Conditions : 1. m_OnThreshold  is not greater than m_OffThreshold
#                    2. m_OnThreshold  Is not less than  m_OffThreshold
#				                                      
# Expected OutPuts : Verify
#                       m_InputOn is assigned with Boolean which indicates that m_InputSignal is equal to  m_OnThreshold.                             
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC n3::SDD_CALF_11911]            -   Test By Inspection")

Input_condition = "m_OnThreshold  is neither greater than m_OffThreshold nor less than  m_OffThreshold"
Expected_Result = "m_InputOn is assigned with Boolean which indicates that m_InputSignal is equal to  m_OnThreshold"
                  

Object_ID = "SDD_CALF_11911"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If #CompareObjectID
#---------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11914"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : o1
# Input Conditions : Set 
#				              1. m_InputOn as TRUE
#                        
# Expected OutPuts : Verify
#                         m_InputOffTime = 0
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC o1::SDD_CALF_11914]            -   Test By Inspection")

Input_condition = "m_InputOn is TRUE"
Expected_Result = "m_InputOffTime = 0"
Object_ID = "SDD_CALF_11914"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : o2
# Input Conditions : Set 
#				              1. m_InputOn as TRUE
#                        2. m_InputOnTime < m_OnDelay
#                        
# Expected OutPuts : Verify
#                         m_InputOnTime is incremented
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC o2::SDD_CALF_11914]            -   Test By Inspection")

Input_condition = "m_InputOn is TRUE and m_InputOnTime < m_OnDelay"
Expected_Result = "m_InputOnTime is incremented"
Object_ID = "SDD_CALF_11914"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : o3
# Input Conditions : Set 
#				              1. m_InputOn as TRUE
#                        2. m_InputOnTime > m_OnDelay
#                        3. m_TrippedOn as FALSE
#                        
# Expected OutPuts : Verify
#                        1. m_TrippedOn = TRUE
#                        2. m_TrippedOff = FALSE
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC o3::SDD_CALF_11914]            -   Test By Inspection")

Input_condition = "m_InputOn is TRUE, m_InputOnTime is greater than m_OnDelay and m_TrippedOn is FALSE"
Expected_Result = "m_TrippedOn = TRUE"& vbLf &_
                  "m_TrippedOff = FALSE"
Object_ID = "SDD_CALF_11914"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : o4
# Input Conditions : Set 
#				              1. m_InputOn as False
#                        
# Expected OutPuts : Verify
#                         m_InputOnTime = 0
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC o4::SDD_CALF_11914]            -   Test By Inspection")

Input_condition = "m_InputOn is False"
Expected_Result = "m_InputOnTime = 0"
Object_ID = "SDD_CALF_11914"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : o5
# Input Conditions : Set 
#				              1. m_InputOn as False
#                        2. m_InputOffTime < m_OnDelay	
#                        
# Expected OutPuts : Verify
#                         m_InputOffTime is incremented
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC o5::SDD_CALF_11914]            -   Test By Inspection")

Input_condition = "m_InputOn is False and m_InputOffTime < m_OnDelay"
Expected_Result = "m_InputOffTime is incremented"
Object_ID = "SDD_CALF_11914"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : o6
# Input Conditions : Set 
#				              1. m_InputOn as False
#                        2. m_InputOffTime > m_OnDelay
#                        3. m_TrippedOff as FALSE
#                        
# Expected OutPuts : Verify
#                         m_TrippedOff = TRUE
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC o6::SDD_CALF_11914]            -   Test By Inspection")

Input_condition = "m_InputOn is False, m_InputOffTime is greater than m_OnDelay and m_TrippedOff is FALSE"
Expected_Result = "m_TrippedOff = True"
Object_ID = "SDD_CALF_11914"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID
#---------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11917"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : p1
# Input Conditions : None
#				                                      
# Expected OutPuts : Verify
#                       Reset resets the data members to the values mentioned below:
#                                                   m_InputSignal       = 0 
#                                                   m_InputOnTime       = 0 
#                                                   m_InputOffTime      = 0 
#                                                   m_InputOn           = FALSE 
#                                                   m_TrippedOn         = FALSE
#                                                   m_TrippedOff        = FALSE 
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC p1::SDD_CALF_11917]            -   Test By Inspection")

Input_condition = "data members are available for reset"
Expected_Result = "Reset resets the data members to the values mentioned below"& vbLf &_
                  "m_InputSignal  = 0"& vbLf &_
                  "m_InputOnTime  = 0"& vbLf &_
                  "m_InputOffTime = 0"& vbLf &_
                  "m_InputOn      = false"& vbLf &_
                  "m_TrippedOn    = false"& vbLf &_
                  "m_TrippedOff   = false"
Object_ID = "SDD_CALF_11917"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID
#---------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11920"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : q1
# Input Conditions : None
#				                                      
# Expected OutPuts : Verify
#                       Copy copies the data members from input trigger instance.                            
#
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC q1::SDD_CALF_11920]            -   Test By Inspection")

Input_condition = "data members are available for copying"
Expected_Result = "Copy copies the data members from input trigger instance"
                  

Object_ID = "SDD_CALF_11920"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID

#---------------------------------------------------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_11931"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : r1
# Input Conditions : Set 
#				              1. Trigger On as TRUE
#                        
# Expected OutPuts : Verify
#                         m_Output = m_AssertionValue
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC r1::SDD_CALF_11931]            -   Test By Inspection")

Input_condition = "Trigger On is TRUE"
Output ("m_Output = m_AssertionValue")
Object_ID = "SDD_CALF_11931"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : r2
# Input Conditions : Set 
#				              1. Trigger On as TRUE
#                       2. m_OutputOnTime < m_HoldUpTime
#                        
# Expected OutPuts : Verify
#                         m_OutputOnTime is Incremented
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC r2::SDD_CALF_11931]            -   Test By Inspection")

Input_condition = "Trigger On is TRUE and m_OutputOnTime is less than m_HoldUpTime"
Output ("m_OutputOnTime gets Incremented")
Object_ID = "SDD_CALF_11931"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : r3
# Input Conditions : Set 
#                       1. m_OutputOnTime > m_HoldUpTime
#				             2. Trigger OFF as TRUE

#                        
# Expected OutPuts : Verify
#                         1. Reset the trigger
#                         2. m_OutputOnTime = 0
#                         3. m_Output = m_NonAssertionValue
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC r3::SDD_CALF_11931]            -   Test By Inspection")

Input_condition = "m_OutputOnTime is greater than m_HoldUpTime and Trigger OFF as TRUE"
Expected_Result = "Reset the Trigger"& vbLf &_
Output ("m_OutputOnTime = 0")
Output ("m_Output = m_NonAssertionValue")
Object_ID = "SDD_CALF_11931"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)



#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : r4
# Input Conditions : Set 
#				              1. Trigger On as False
#                       2. m_Output equal to m_AssertionValue 
#                        
# Expected OutPuts : Verify
#                         m_Output = m_NonAssertionValue
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC r4::SDD_CALF_11931]            -   Test By Inspection")

Input_condition = "Trigger On is False and m_Output is equal to m_AssertionValue"
Output ("m_Output = m_NonAssertionValue")
Object_ID = "SDD_CALF_11931"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID

#---------------------------------------------------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_11934"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : s1
# Input Conditions : Set 
#				              1. m_ProcessEnable as TRUE
#                        
# Expected OutPuts : Verify
#                         trigger processing is performed as specified in SDD_CALF_11914
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC s1::SDD_CALF_11934]            -   Test By Inspection")

Input_condition = "m_ProcessEnable is TRUE"
Expected_Result = "Trigger processing is performed"
Object_ID = "SDD_CALF_11934"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : s2
# Input Conditions : Set 
#				              1. m_ProcessEnable as TRUE
#                       2. Both Trigger On and Trigger Off as True
#                        
# Expected OutPuts : Verify
#                         1. Reset the On/Off trigger 
#                         2. m_ToggleDisable = FALSE
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC s2::SDD_CALF_11934]            -   Test By Inspection")

Input_condition = "m_ProcessEnable is TRUE and Both Trigger On and Trigger Off is set True"
Expected_Result = "Reset the On/Off trigger and m_ToggleDisable = FALSE"
Object_ID = "SDD_CALF_11934"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)



#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : s3
# Input Conditions : Set 
#				              1. m_ProcessEnable as TRUE
#                        2. Trigger On as True.
#                        3. Trigger Off as FALSE
#                        4. Toggle as not Inhibited 
#                        
# Expected OutPuts : Verify
#                         m_ToggleDisable = true
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC s3::SDD_CALF_11934]            -   Test By Inspection")

Input_condition = "m_ProcessEnable is TRUE, Trigger On is set True,  Trigger Off as FALSE and Toggle as not Inhibited"
Expected_Result = "m_ToggleDisable = true"
Object_ID = "SDD_CALF_11934"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)



#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : s4
# Input Conditions : Set 
#				              1. m_ProcessEnable as TRUE
#                       2. Trigger On as True.
#                       3. Toggle as not Inhibited 
#                       4. m_Output equal to m_NonAssertionValue
#                        
# Expected OutPuts : Verify
#                         m_Output = m_AssertionValue
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC s4::SDD_CALF_11934]            -   Test By Inspection")

Input_condition = "m_ProcessEnable is TRUE, Trigger On is set True, Toggle as not Inhibited and m_Output is equal to m_NonAssertionValue"
Output ("m_Output = m_AssertionValue")
Object_ID = "SDD_CALF_11934"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : s5
# Input Conditions : Set 
#				              1. m_ProcessEnable as TRUE
#                       2. Trigger On as True.
#                       3. Toggle as not Inhibited 
#                       4. m_Output not equal to m_NonAssertionValue
#                        
# Expected OutPuts : Verify
#                         m_Output = m_NonAssertionValue
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC s5::SDD_CALF_11934]            -   Test By Inspection")

Input_condition = "m_ProcessEnable is TRUE, Trigger On is set True, Toggle as not Inhibited and m_Output is not equal to m_NonAssertionValue"
Output ("m_Output = m_NonAssertionValue")
Object_ID = "SDD_CALF_11934"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#End If #CompareObjectID

#-----------------------------------------------------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_11937"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : t1
# Input Conditions : Set 
#				              1. Trigger On as TRUE
#                        2. m_OutputOnTime less than m_HoldUpTime.
#                        
# Expected OutPuts : Verify
#                         1. m_Output    = m_AssertionValue
#                         2. m_OutputOnTime is Incremented.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC t1::SDD_CALF_11937]            -   Test By Inspection")

Input_condition = "Trigger On is TRUE and m_OutputOnTime less than m_HoldUpTime"
Output ("m_Output = m_AssertionValue")
Output ("m_OutputOnTime gets Incremented")
Object_ID = "SDD_CALF_11937"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : t2
# Input Conditions : Set 
#				              1. Trigger On as TRUE
#                        2. m_OutputOnTime greater than m_HoldUpTime.
#                        
# Expected OutPuts : Verify
#                         m_Output = m_NonAssertionValue
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC t2::SDD_CALF_11937]            -   Test By Inspection")

Input_condition = "Trigger On is TRUE and m_OutputOnTime greater than m_HoldUpTime"
Output ("m_Output = m_NonAssertionValue")
Object_ID = "SDD_CALF_11937"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : t3
# Input Conditions : Set 
#				              1. Trigger On as TRUE
#                        2. m_OutputOnTime greater than m_HoldUpTime.
#                        3. Trigger Off as TRUE
#                        
# Expected OutPuts : Verify
#                         1. Trigger is reset.
#                         2. m_OutputOnTime = 0
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC t3::SDD_CALF_11937]            -   Test By Inspection")

Input_condition = "Trigger On is TRUE, m_OutputOnTime greater than m_HoldUpTime and Trigger Off as TRUE"
Expected_Result = "Trigger is reset" & vbLf &_
Output ("m_OutputOnTime = 0")
Object_ID = "SDD_CALF_11937"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)



#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : t4
# Input Conditions : Set 
#				              1. Trigger On as False.
#                        2. m_Output equal to m_AssertionValue 
#                        
# Expected OutPuts : Verify
#                         m_Output = m_NonAssertionValue.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC t4::SDD_CALF_11937]            -   Test By Inspection")

Input_condition = "Trigger On is False and m_Output is equal to m_AssertionValue "
Output ("m_Output = m_NonAssertionValue")
Object_ID = "SDD_CALF_11937"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#End If #CompareObjectID

#-----------------------------------------------------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_11940"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : u1
# Input Conditions : Set 
#				              1. Trigger On Condition as True for both m_Trigger and m_ArmedTrigger.
#                        2. m_OutputOnTime less than m_HoldUpTime
#                        
# Expected OutPuts : Verify
#                         1. m_Output    = m_AssertionValue
#                         2. m_OutputOnTime is Incremented.
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC u1::SDD_CALF_11940]            -   Test By Inspection")

Input_condition = "Trigger On Condition is True for both m_Trigger and m_ArmedTrigger & m_OutputOnTime less than m_HoldUpTime"
Output ("m_Output = m_AssertionValue")
Output ("m_OutputOnTime gets Incremented")
Object_ID = "SDD_CALF_11940"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : u2
# Input Conditions : Set 
#				              1. Trigger On Condition as True for both m_Trigger and m_ArmedTrigger.
#                        2. m_OutputOnTime greater than m_HoldUpTime
#                        
# Expected OutPuts : Verify
#                         1. m_Output    = m_NonAssertionValue
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC u2::SDD_CALF_11940]            -   Test By Inspection")

Input_condition = "Trigger On Condition is True for both m_Trigger and m_ArmedTrigger & m_OutputOnTime less than m_HoldUpTime"
Output ("m_Output    = m_NonAssertionValue")
Object_ID = "SDD_CALF_11940"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)



#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : u3
# Input Conditions : Set 
#				              1. Trigger On Condition as True for both m_Trigger and m_ArmedTrigger.
#                        2. m_OutputOnTime greater than m_HoldUpTime
#                        3. Trigger Off Condition as True
#                        
# Expected OutPuts : Verify
#                         1. m_OutputOnTime = 0
#                         2. Reset the trigger for both m_Trigger and m_ArmedTrigger
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC u3::SDD_CALF_11940]            -   Test By Inspection")

Input_condition = "Trigger On Condition is True for both m_Trigger and m_ArmedTrigger, m_OutputOnTime less than m_HoldUpTime and Trigger Off Condition is True"
Output ("m_OutputOnTime = 0")
                  "Reset the trigger for both m_Trigger and m_ArmedTrigger"
Object_ID = "SDD_CALF_11940"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)



#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : u4
# Input Conditions : Set 
#				              1. Trigger On Condition as False for both m_Trigger and m_ArmedTrigger.
#                        2. m_Output equal to m_AssertionValue 
#                        
# Expected OutPuts : Verify
#                         m_Output = m_NonAssertionValue
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC u4::SDD_CALF_11940]            -   Test By Inspection")

Input_condition = "Trigger On Condition is False for both m_Trigger and m_ArmedTrigger & m_Output equal to m_AssertionValue"
Output ("m_Output = m_NonAssertionValue")
Object_ID = "SDD_CALF_11940"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : u5
# Input Conditions : Set 
#			                Trigger On and Trigger Off  Condition as True	 for m_Trigger.
#                        
# Expected OutPuts : Verify
#                          The trigger for m_Trigger is reset
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC u5::SDD_CALF_11940]            -   Test By Inspection")

Input_condition = "Trigger On and Trigger Off  Condition 1s True	 for m_Trigger"
Expected_Result = "trigger for m_Trigger is reset"
Object_ID = "SDD_CALF_11940"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : u6
# Input Conditions : Set 
#			                Trigger On and Trigger Off  Condition as True	 for m_ ArmedTrigger.
#                        
# Expected OutPuts : Verify
#                          The trigger for m_ ArmedTrigger is reset
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC u6::SDD_CALF_11940]            -   Test By Inspection")

Input_condition = "Trigger On and Trigger Off  Condition 1s True	 for m_ ArmedTrigger"
Expected_Result = "trigger for m_ ArmedTrigger is reset"
Object_ID = "SDD_CALF_11940"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#End If #CompareObjectID

#---------------------------------------------------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_11943"):

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : v1
# Input Conditions : Set 
#				              1. Value as not equal m_Output
#                        2. m_TransitionTimer  as inactive
#                        
# Expected OutPuts : Verify
#                         1. m_TransitionTimer is activated.
#                         2. m_Output = value 
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC v1::SDD_CALF_11943]            -   Test By Inspection")

Input_condition = "Value is not equal m_Output and m_TransitionTimer  is inactive"
Expected_Result = "m_TransitionTimer is activated"& vbLf &_
Output ("m_Output = value")
Object_ID = "SDD_CALF_11943"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : v2
# Input Conditions : Set 
#				              1. Value as not equal m_Output
#                        2. m_TransitionTimer  as active
#                        
# Expected OutPuts : Verify
#                         Pulse m_TransitionTimer
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC v2::SDD_CALF_11943]            -   Test By Inspection")

Input_condition = "Value is not equal m_Output and m_TransitionTimer  is active"
Expected_Result = "Pulse m_TransitionTimer"
Object_ID = "SDD_CALF_11943"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)



#---------------------------------------------------------------------------------------------------------------------------------------------------------
# TestCase         : v3
# Input Conditions : Set 
#				              Value as equal m_Output
#                        
# Expected OutPuts : Verify
#                         m_TransitionTimer is deactivated
#----------------------------------------------------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC v3::SDD_CALF_11943]            -   Test By Inspection")

Input_condition = "Value is equal m_Output"
Expected_Result = "m_TransitionTimer is deactivated"
Object_ID = "SDD_CALF_11943"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category = EL # :Environment Limitation

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID


If CompareObjectID("SDD_CALF_12124"):
#-------------------------------------------------------------------------------------------------------------
# TestCase         : w1
# Input Conditions : None
# Expected OutPuts : Verify
#                    roundup rounds off the input value (numToRound)to the nearest multiple value using the following logic.
#                                                  return value =  (numToRound + multiple - 1/ multiple) *  multiple
                                      

#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC w1::SDD_CALF_12124]            -   Test By Inspection")

Input_condition  = "Input value is available for round off"
Expected_Result  = "roundup rounds off the input value (numToRound)To the nearest multiple value using the following logic." \
                           "return value =  (numToRound + multiple - 1/ multiple) *  multiple"
Object_ID        = "SDD_CALF_12124"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID

#-------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_12140"):
#-------------------------------------------------------------------------------------------------------------
# TestCase         : x1
# Input Conditions : None
# Expected OutPuts : Verify
#                    UtlSet1 initializes data at a destination in bytes at a time.
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC x1::SDD_CALF_12140]            -   Test By Inspection")

Input_condition  = "data is available for initialization"
Expected_Result  = "UtlSet1 initializes data at a destination in bytes at a time."
Object_ID        = "SDD_CALF_12140"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID

#------------------------------------------------------------------------------------------------------------


If CompareObjectID("SDD_CALF_12130"):
#-------------------------------------------------------------------------------------------------------------
# TestCase         : y1
# Input Conditions : 1. contents of Timer = 0
#                    2. Input != contents of Output
#                    3. Input = True
# Expected OutPuts : Verify
#                    contents of Timer = OnTime
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC y1::SDD_CALF_12130]            -   Test By Inspection")

Input_condition  = "contents of Timer equal to 0, Input not equal to contents of Output and Input equal to true "
Expected_Result  = "contents of Timer = OnTime"
Object_ID        = "SDD_CALF_12130"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#-------------------------------------------------------------------------------------------------------------
# TestCase         : y2
# Input Conditions : 1. contents of Timer = 0
#                    2. Input != contents of Output
#                    3. Input = False
# Expected OutPuts : Verify
#                    contents of Timer = OffTime
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC y2::SDD_CALF_12130]            -   Test By Inspection")

Input_condition  = "contents of Timer equal to 0, Input not equal to contents of Output and Input equal to False "
Expected_Result  = "contents of Timer = OffTime"
Object_ID        = "SDD_CALF_12130"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#-------------------------------------------------------------------------------------------------------------
# TestCase         : y3
# Input Conditions : 1. contents of Timer = 0
#                    2. Input != contents of Output
# Expected OutPuts : Verify
#                    content of Output = Input
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC y3::SDD_CALF_12130]            -   Test By Inspection")

Input_condition  = "contents of Timer equal to 0 and Input not equal to contents of Output "
Output ("content of Output = Input")
Object_ID        = "SDD_CALF_12130"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#-------------------------------------------------------------------------------------------------------------
# TestCase         : y4
# Input Conditions : 1. contents of Timer != 0
#                    2. Input = contents of Output
# Expected OutPuts : Verify
#                    contents of Timer = 0
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC y4::SDD_CALF_12130]            -   Test By Inspection")

Input_condition  = "contents of Timer not equal to 0 and Input equal to contents of Output "
Expected_Result  = "contents of Timer = 0"
Object_ID        = "SDD_CALF_12130"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#-------------------------------------------------------------------------------------------------------------
# TestCase         : y5
# Input Conditions : 1. contents of Timer != 0
#                    2. Input != contents of Output
# Expected OutPuts : Verify
#                    contents of Timer gets decremented by 1.
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC y5::SDD_CALF_12130]            -   Test By Inspection")

Input_condition  = "contents of Timer not equal to 0 and Input not equal to contents of Output "
Expected_Result  = "contents of Timer gets decremented by 1"
Object_ID        = "SDD_CALF_12130"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#-------------------------------------------------------------------------------------------------------------
# TestCase         : y6
# Input Conditions : 1. contents of Timer != 0
#                    2. Input != contents of Output
#                    3. contents of Timer-1 = 0
# Expected OutPuts : Verify
#                     contents of Output = Input
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC y6::SDD_CALF_12130]            -   Test By Inspection")

Input_condition  = "contents of Timer not equal to 0 and Input not equal to contents of Output "
Output ("contents of Output = Input")
Object_ID        = "SDD_CALF_12130"
CA_Justification = "It is not possible to check the library function for debouncing an input value into an output value in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#End If  #CompareObjectID

#-------------------------------------------------------------------------------------------------------------

If CompareObjectID("SDD_CALF_12127"):
#-------------------------------------------------------------------------------------------------------------
# TestCase         : z1
# Input Conditions : None
# Expected OutPuts : Verify
#                    UtlCrc32 calculates a 32 bit CRC on a block of data.
#-------------------------------------------------------------------------------------------------------------
Output ("[TP_1::TC z1::SDD_CALF_12127]            -   Test By Inspection")

Input_condition  = "A block of data is available for calculating a 32 bit CRC."
Expected_Result  = "UtlCrc32 calculates a 32 bit CRC on a block of data"
Object_ID        = "SDD_CALF_12127"
CA_Justification = "It is not possible to check the prototype of a function in our test environment" \
                   "So TBI has been called"
Category         = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If  #CompareObjectID



#--------------------------------------------------------------------------------------------------------------------------------

#=========================================================================================================
#                                        PRINT FINAL RESULTS
#=========================================================================================================
ReportSummary()