#Updated to For summary without TBI
import string
import os
import sys
import re

Updated_path = "C:/Vishwas/TASKS_ASSIGNED/Load_12_Activities/MODSUM.txt"
Sum_path = "C:/Vishwas/TASKS_ASSIGNED/Load_12_Activities/TSG_S11B_0001_Rework summary.sum"
List_path = "C:/Vishwas/TASKS_ASSIGNED/Load_12_Activities/List.txt"
#Open Ease File
Ease = open(Sum_path,"r+")
fd = open(Updated_path,"w")
book = open(List_path,"r")
pass_num = 0
fail_num = 0
# Read the first line from the files
Ease_line = Ease.readline()
Exit_loop = False
str4 = "TEST RESULTS:"
str5 = "Total No. of Tests Included"
Exit_file = 1
total_tests = 0
Test_result = 1
tbi = 0
Without_TBI = 1
# Loop if either file1 or file2 has not reached EOF
while Exit_file != 0:
   str1 = " Passed"
   str2 = " Fail"
   str3 = " Number"
   p = 0
   f = 0
   n = 0
#Search passed and Fail number in every line
   p = Ease_line.find(str1)
   f = Ease_line.find(str2)
   n = Ease_line.find(str3)
   if (p > 1 or f > 1) and (n > 1):
      temp = Ease_line.split("** ")
      fd.write(temp[0])
      if p > 1:
         if (temp[0] == " "):
            book_line = book.readline()
            book_line = book_line.strip()
            if (book_line == "P"):
               pass_num = pass_num + 1
               fd.write("**" + " " + "Passed Number" + " ")
               fd.write('%d' % pass_num)
               fd.write(" ** \n")
            else:
               fail_num = fail_num + 1
               fd.write("**" + " " + "Fail Number" + " ")
               fd.write('%d' % fail_num)
               fd.write(" ** \n")
               FailureD = book_line.split(":")
               FailureD = FaliureD.replace('.','');
               fd.write("Failure Description :" + FailureD[1])
               fd.write("\n")
         else:
            pass_num = pass_num + 1
            fd.write("** Passed Number ")
            fd.write('%d' % pass_num)
            fd.write(" ** \n")		  
      if f > 1:
       #print fail_num
         if (temp[0] == " "):
             book_line = book.readline()
             book_line = book_line.strip()
             if (book_line == "F"):
                fail_num = fail_num + 1
                fd.write("**" + " " + "Fail Number" + " ");
                fd.write('%d' % fail_num)
                fd.write(" ** \n")
             else:
                pass_num = pass_num + 1
                fd.write("**" + " " + "Passed Number" + " ")
                fd.write('%d' % pass_num)
                fd.write(" ** \n")
         else:
             fail_num = fail_num + 1
             fd.write ("** Fail Number ")
             fd.write('%d' % fail_num)
             fd.write(" ** \n")
      #print pass_num
      
   else:
     Test_result = Ease_line.find(str4)
     if (Test_result == 0):
        Exit_file = 1
        Exit_file = Ease_line.find(str4)
        fd.write(Ease_line)
        fd.write("\n")
        fd.write("No. of Test Steps Failed    : " + '%d' % fail_num + "\n")
        fd.write("No. of Test Steps Passed    : " + '%d' % pass_num + "\n")
        Ease_line = Ease.readline()
        Ease_line = Ease.readline()
        Ease_line = Ease.readline()
        Ease_line = Ease.readline()# TBI line
        Without_TBI = Ease_line.find(str5)
        if (Without_TBI == 0):
            total_tests = fail_num + pass_num
            fd.write("Total No. of Tests Included : " + '%d' % total_tests + "\n")
        else:
            Ease_line = Ease_line.replace("\n", "")
            Perm = Ease_line.split(" ")
            tbi = Perm[8]
            val = int(tbi)
            fd.write(Ease_line)	
            fd.write("\n")	
            total_tests = fail_num + pass_num + val
            Ease_line = Ease.readline()
            fd.write(Ease_line)	
            Ease_line = Ease.readline()
            fd.write(Ease_line)	
            fd.write("Total No. of Tests Included : " + '%d' % total_tests + "\n")
     else:
	  fd.write(Ease_line)
      
  #read line   
   Ease_line = Ease.readline()

#close file
Ease.close()
fd.close()
book.close()
