#thisDict = {"Vishwas" : "Waste", "Vishwas Krishna": "Coward"}
#print(thisDict)
#x = thisDict["Vishwas Krishna"]
#print(x)
#thisDict1 = {'Vishwas' : 'Waste', 'Vishwas Krishna': 'Coward'}
#print(thisDict1)
#y = thisDict1['Vishwas Krishna']
#print(y)
#
#for z in thisDict1:
#    print(thisDict1[z])
#
#for x in thisDict1.values():
#    print("*********************")
#    print(x)

#Python to read Xls file and then add the first column as Key and Next column as Dictionary

import openpyxl
from openpyxl import workbook

dict = {}
filename = "C:\\Users\\h126313\\Desktop\\Python\\Ashwini\\complete.xlsx"
wb = openpyxl.load_workbook(filename)
sheet = wb.get_sheet_by_name('Sheet2')


for row in range (1,sheet.max_row+1):
    First_Column = str(sheet.cell(row=row, column=1).value).strip()
    second_Column = str(sheet.cell(row=row, column=2).value).strip()
    dict[First_Column] = second_Column

print(dict)
x = dict['ads1bCalibratedAirspeed#']
#print(x)

for u in dict:
    print(u)

i = 0
while i<4:
    i +=1
    #print(i)


def square(num1):
    num2 = num1 * num1
    return num2

num = 6
num2 = square(num)
print(num2)