with open("C:\\Vishwas\\Task_Assigned\\TSC2_0\Drop2\\Cons_RA\\Cpp.txt", "r") as inputdata:
    with open("C:\\Vishwas\\Task_Assigned\\TSC2_0\Drop2\\Cons_RA\\Cpp1.txt", "w") as output:
        for line in inputdata:
            if line.__contains__("\\"):
                line = line.split("\\")[-1]
            output.write(line)
