#-------------------------------------------------------------------------------------------------------------------------------------
#Author: Vishwas Krishna
#Purpose: Parse the tsf and cpp file and generate the Trace report (Trace_CA4.csv)
#-------------------------------------------------------------------------------------------------------------------------------------


import os
import csv
import codecs
import time

fileread = input("Drag and Drop the folder Containing Tsf and Cpps: ")
os.getcwd()
if os.path.exists('Trace_CA4.csv'): os.remove('Trace_CA4.csv')
with open("Trace_CA4.csv", 'a', newline='', encoding="utf-8") as traceout:
    outdata = ''
    w = csv.writer(traceout)
#Header Section in Trace.csv output file
    w.writerow(["TestName", "Requirement_ID", "TestCase_Number", "FileName"])
    for root, dirs, files in os.walk(fileread):
        for file in files:

            if file.endswith(".tsf") or file.endswith(".cpp") or file.endswith(".TSF") or file.endswith(".CPP") or file.endswith(".Tsf") or file.endswith(".Cpp"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as fileinput:
                    #filename = os.path.basename(file)
                    TestName = ''
                    RequirementId = ''
                    TestcaseName = ''
                    tsfname = ''
                    for line in fileinput:
                        RequirementId = ''
                        TestcaseName = ''
                        if line.__contains__("TestName") and line.__contains__(":"):
                            TestName = line.split(":")[1]
                            TestName = TestName.split("\"")[0]
                            TestName = TestName.rstrip("\r\n")
                            TestName = TestName.lstrip("\r\n")
                            TestName = TestName.rstrip(" ")
                            TestName = TestName.lstrip(" ")
                            print(TestName)
                            tsfname = fileinput.name
                            tsfname = tsfname.split('\\')[-1]
                        if line.__contains__("[TC") and line.__contains__("TC") and line.__contains__("::"):
                            RequirementId = line.split("::")[1]
                            RequirementId = RequirementId.split("]")[0]
                            RequirementId = RequirementId.rstrip("\r\n")
                            RequirementId = RequirementId.lstrip("\r\n")
                            print(RequirementId)
                            TestcaseName = line.split("::")[0]
                            TestcaseName = TestcaseName.split("TC")[1]
                            TestcaseName = TestcaseName.rstrip("\r\n")
                            TestcaseName = TestcaseName.lstrip("\r\n")
                            print(TestcaseName)
                            #outdata = TestName + "," + RequirementId + "," + TestcaseName + "," + tsfname + '\n'
                            #traceout.write(outdata)
                        elif line.__contains__("[TP_") and line.__contains__("::") and line.__contains__("OutputResult"):
                            RequirementId = ''
                            TestcaseName = ''
                            RequirementId = line.split("::")[2]
                            RequirementId = RequirementId.split("]")[0]
                            RequirementId = RequirementId.rstrip("\r\n")
                            RequirementId = RequirementId.lstrip("\r\n")
                            TestcaseName = line.split("::")[1]
                            #print(RequirementId)
                            #print(TestcaseName)
                        if(RequirementId != '' and TestcaseName!= ''):
                            outdata = TestName + "," + RequirementId + "," + TestcaseName + "," + tsfname + '\n'
                            print(outdata)
                            traceout.write(outdata)

print("All Trace Extractions are Completed")
time.sleep(2)
exit(0)