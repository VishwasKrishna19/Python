import os
import re
import glob
import errno
import fileinput

#getting current working directory
cwd = os.getcwd()
#searching for test files
path = cwd+'\*.tsf'
tsf_files = glob.glob(path)
py_files = []
sum_files = []
for file in tsf_files:
    py_files.append(file.replace(".tsf",".py"))
sum_files = [re.search('[a-zA-Z0-9_ ]*.tsf', x).group(0) for x in tsf_files]
i = 0
n = len(sum_files)
for i in range(0,n):
    sum_files[i]=sum_files[i].replace(".tsf","")
i = 0
for tsfname in tsf_files:
    file1 = open(tsfname,'r')
    file2 = open(py_files[i],'w')
    file3 = open("temp.txt",'w')
    for line in file1:
        if '\'' in line:
            file3.write(line.replace("'", "#"))
        else:
            file3.write(line)
    file3.close()
    file3 = open("temp.txt",'r')
    for line in file3:
        pattern_search = re.search('Passfail', line) or re.search('PassFail', line)
        pattern_search1 = re.search('MessageBox', line) or re.search('Messagebox', line)
        pattern_search2 = re.search('Initialization', line) or re.search('initialization', line)
        pattern_search7 = re.search('Input_condition', line) or re.search('input_condition', line)
        pattern_search3 = re.search('Output', line) or re.search('output', line)
        pattern_search4 = re.search('TCodeA.TestByInspectionOutput1 ', line)
        pattern_search5 = re.search('Sub ', line)
        pattern_search6 = re.search('Assign ', line)
        pattern_search8 = re.search('Delay [0-9]', line) or re.search('delay [0-9]', line)
        if line.startswith('#'):
            file2.write(line)
        elif 'Option Explicit' in line:
            file2.write(line.replace("Option Explicit", "import InitialSupport\n"))
            file2.write("from InitialSupport import *\n")
            file2.write("TestName = "'"'+sum_files[i]+'"'"\n")
            file2.write("Startsum(TestName)\n")
        elif 'Dim' in line:
            file2.write(line.replace("Dim", "global"))
        elif 'End Sub' in line:
            file2.write(line.replace("End Sub", ""))
        elif '& vbCrLf & _' in line:
            file2.write(line.replace("& vbCrLf & _", "\\"))
        elif '&vbCrLf & _' in line:
            file2.write(line.replace("&vbCrLf & _", "\\"))
        elif '&vbCrLf& _' in line:
            file2.write(line.replace("&vbCrLf& _", "\\"))
        elif '&vbCrLf&_' in line:
            file2.write(line.replace("&vbCrLf&_", "\\"))
        elif '&vbCrLf &_' in line:
            file2.write(line.replace("&vbCrLf &_", "\\"))
        elif '& vbCrLf &_' in line:
            file2.write(line.replace("& vbCrLf &_", "\\"))
        elif '& vbCrLf&_' in line:
            file2.write(line.replace("& vbCrLf&_", "\\"))
        elif 'End If' in line:
            file2.write(line.replace("End If", "#End If"))
        elif 'End if' in line:
            file2.write(line.replace("End if", "#End if"))
        elif 'Sub ' in line:
            file2.write(line.replace("Sub ", "def "))
        elif ' Then' in line:
            file2.write(line.replace(" Then", ":"))    
        elif ' then' in line:
            file2.write(line.replace(" then", ":"))    
        elif 'ReportSummary' in line:
            file2.write(line.replace("ReportSummary", "ReportSummary()"))            
        elif pattern_search:
            patterns = re.findall(r'"(.*?)(?<!\\)"',line)
            if patterns:
                file2.write("PassFail (\"" + patterns[0]+"\")\n")
        elif pattern_search8:
            if '#' in line:
                patterns = re.findall(r"\d+\.\d+ #.*",line) or re.findall(r"\d+ #.*",line)
                pattern1 = re.findall(r'\d+\.\d+',patterns[0]) or re.findall(r'\d+',patterns[0])
                pattern2 = re.findall(r' #.*',patterns[0])
                if patterns:
                    file2.write("Delay (" + pattern1[0]+")"+pattern2[0]+"\n")
            else:
                patterns = re.findall(r'\d+\.\d+',line) or re.findall(r'\d+',line)
                if patterns:
                    file2.write("Delay (" + patterns[0]+")\n")
        elif pattern_search1:
            patterns = re.findall(r'"(.*?)(?<!\\)"',line)
            if patterns:
                file2.write("MessageBox (\"" + patterns[0]+"\")\n")
        elif pattern_search4:
            file2.write("TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)\n")
        elif pattern_search7:
            file2.write(line)
        elif pattern_search2:
            patterns = re.findall(r'"(.*?)(?<!\\)"',line)
            if patterns:
                file2.write("Initialization (\"" + patterns[0]+"\")\n")
        elif pattern_search3:
            patterns = re.findall(r'"(.*?)(?<!\\)"',line)
            if patterns:
                file2.write("Output (\"" + patterns[0]+"\")\n")
        elif pattern_search5:
            patterns = re.findall(r'"(.*?)(?<!()\\)"',line)
            if patterns:
                file2.write("def (\"" + patterns[0]+"\")\:\n")
        elif 'Assign ' and "glossary" in line:
            line = line.replace("Assign ", "Assign(")
            file2.write(line.replace(',"'"glossary"'"', ',"'"glossary"'")'))
        elif 'Call ' in line:
            file2.write(line.replace("Call ", ""))
        else:
            file2.write(line)
    file1.close()
    file2.close()
    file3.close()
    i = i + 1

