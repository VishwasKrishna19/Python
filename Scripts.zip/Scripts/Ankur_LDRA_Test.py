import os
import sys
import csv
import codecs
import time
import xlrd

def extract_trace_data_Text():
    tsffolder = 'C:\\TSC2.0\\TEST\\Scripts\\TSC2.0\\TEST'
    with open('C:/Users/h126313/Desktop/Python/Script/tracedata.txt', 'w') as tracedata:
        for root, dirs, files in os.walk(tsffolder):
            for file in files:
                if file.endswith(".tsf") or file.endswith(".cpp") :
                    with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as tsf:
                        for line in tsf:
                            if line.__contains__('[TP_'):
                                tsfname = tsf.name
                                tsfname = tsfname.split("\\")[-1]
                                print(tsf.name)
                                tracedata.write(tsfname + ',' + line + '\n')
                            #print(line)

def Trace_data_Extract():
    Doors_xls = 'C:\\Users\\h126313\\Desktop\\Python\\Script\\'
    wb = xlrd.open_workbook(Doors_xls)
    sheet = wb.sheet_by_index(0)
    sheet.cell_value(0, 0)
    if os.path.exists('Trace_Data.csv'): os.remove('Trace_Data.csv')
    with open("Trace_Data.csv", 'a', newline='', encoding="utf-8") as traceoutput:
        with open('tracedata.txt', 'r') as inputtrace:
            for i in range(sheet.nrows):
                ReqId = sheet.cell_value(i, 0)
                testname = []
                for tracedata in inputtrace:
                    if tracedata.__contains__(ReqId):
                        tsfname = tracedata.split(',')[0]
                        testname.append(tsfname)





extract_trace_data_Text()
