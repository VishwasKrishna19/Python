from openpyxl import Workbook
import openpyxl
# import load_workbook
from openpyxl import load_workbook

filename = "C:\\Vishwas\\TASKS_ASSIGNED\\CA4\\Chandan\\CA4_TSC_EDSTSC_GS_00_002_Consolidated_RA_Test.xlsx"
wb = openpyxl.load_workbook(filename)
sheet = wb.get_sheet_by_name('Sheet1')


OutputReportFile = "C:\\Vishwas\\TASKS_ASSIGNED\\CA4\\Chandan\\CA4_TSC_EDSTSC_GS_00_002_Consolidated_RA_Test_Updated.xlsx"
OutputReportFile_wb = Workbook()
OutputReportFile_sheet_1 = OutputReportFile_wb.active

M_Column_Value = ""
N_Column_Vlaue = ""
output_row = 0
M_Column_Value_Array = []
N_Column_Value_Array = []

for row in range (1,sheet.max_row+1):
    M_Column_Value = str(sheet.cell(row=row, column=13).value).strip()
    N_Column_Value = str(sheet.cell(row=row, column=14).value).strip()
    #print(M_Column_Value)
    #print(N_Column_Value)
    if ";" not in M_Column_Value:
        output_row += 1
        for col in range (1,sheet.max_column+1):
            if str(sheet.cell(row=row, column=col).value).strip() != '' and str(sheet.cell(row=row, column=col).value).strip() != 'None':
                OutputReportFile_sheet_1.cell(row=output_row, column=col).value = str(sheet.cell(row=row, column=col).value).strip()
            else:
                print("Else")
                OutputReportFile_sheet_1.cell(row=output_row, column=col).value = ""
    else:
        M_Column_Value_Array = M_Column_Value.split(";")
        N_Column_Value_Array = N_Column_Value.split(";")
        for count in range(0,len(M_Column_Value_Array)):
            output_row += 1
            for col in range(1, sheet.max_column + 1):
                if col != 13 and col != 14:
                    if str(sheet.cell(row=row, column=col).value).strip() != '' and str(sheet.cell(row=row, column=col).value).strip() != 'None':
                        OutputReportFile_sheet_1.cell(row=output_row, column=col).value = str(sheet.cell(row=row, column=col).value).strip()
                    else:
                        print("Else")
                        OutputReportFile_sheet_1.cell(row=output_row, column=col).value = ""
                else:
                    if col == 13:
                        OutputReportFile_sheet_1.cell(row=output_row, column=col).value = M_Column_Value_Array[count]
                    if col == 14:
                        OutputReportFile_sheet_1.cell(row=output_row, column=col).value = N_Column_Value_Array[count]



wb.close()
OutputReportFile_wb.save(filename=OutputReportFile)
OutputReportFile_wb.close()
