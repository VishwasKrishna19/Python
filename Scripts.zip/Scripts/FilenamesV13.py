import string
import os
import sys
import re
import xlsxwriter


Updated_path = input("Enter the path of tsf file")
New = Updated_path.split('\\',15)
New1 = New[-1]
New2 = New1.split('.')
Filename = New2[0]
#xlsx creation
xlsname1 = Filename
xlsname = Filename + "." + "xlsx"
workbook = xlsxwriter.Workbook(xlsname)
worksheet = workbook.add_worksheet()
#Open Ease File
Ease = open(Updated_path,"r")
tsf_line = Ease.readline()
Image_no = 0
Video_no = 0
str1 = "COMPARESHALLTAG"
str3 = "REPORTSUMMARY"
str2 = "PASSFAIL"
For_Keyword = "FOR "
next = "NEXT"
widgettype = "WIDGETTYPE_"
Manwidget = "NOTEPAD_INVOKE (NOTEPAD_START)"
ManualwidgetIndex = 1
tc=0
EndFunc = False
start_image = 0
Next_reached = 1
num_of_Passfails = 0
User_input = len(sys.argv)
For_Exist = 1
widgetIndex = 1
TBI_Present = 0
# Start from the first cell. Rows and columns are zero indexed.
row = 0
col = 0
row1 = 0
col1 = 4
tsf_line = tsf_line.strip()
tsf_line = tsf_line.upper()
while tsf_line != 'REPORTSUMMARY':
  tsf_line = re.sub("\s+", " ", tsf_line)
  Exit_file = 1
  shall_tag = 0
  shall_tag = tsf_line.find(str1)
  if (shall_tag == 3):
     EndFunc = False
     Image_no = 0
     Video_no = 0
     temp = tsf_line.split("(")
     temp2 = temp[1]
     temp3 = temp2.split(")")
     Each_shalltag = int(temp3[0])
     #print(temp3[0])
     #fd.write(temp3[0])
     while EndFunc != True:
       For_Exist = tsf_line.find(For_Keyword)
       if For_Exist == 0 and Next_reached == 1:
         tsf_line = re.sub("\s+", " ", tsf_line)
         tsf_line = tsf_line.upper()
         Ivalue1 = tsf_line.split("TO")
         Ivalue2 = Ivalue1[1]
         Ivalue3 = Ivalue2.strip()
         Ivalue4 = Ivalue3.split(" ")
         Ivalue = int(Ivalue4[0])
         while Next_reached != 0:
           tsf_line = Ease.readline()
           tsf_line = tsf_line.strip()
           tsf_line = tsf_line.upper()
           shall_tag2 = tsf_line.find(str2)
           if shall_tag2 == 0:
              num_of_Passfails = num_of_Passfails + 1
           Next_reached = tsf_line.find(next)
           #print num_of_Passfails
         if num_of_Passfails > 0:
           Image_no = Image_no + 1
           start_image = Image_no
         for iterate in range(1,(Ivalue+1)):
          for Image_no in range(start_image, (num_of_Passfails+start_image)):
            worksheet.write(row, col, (Filename + "_" + temp3[0] + "_" + "IMG" + '%d' % Image_no + "_" + '%d' % iterate))
            worksheet.write(row, col + 1, "Image")
            row += 1
       shall_tag2 = tsf_line.find(str2)
       if shall_tag2 == 0:
          if User_input > 1:
             i=1
             user_arg = User_input - 1
             while(user_arg):
               required_shalltag = int(sys.argv[i])
               if (Each_shalltag == required_shalltag):
                   Image_no = Image_no + 1
                   worksheet.write(row, col, (Filename + "_" + temp3[0] + "_" + "IMG" + '%d' % Image_no ))
                   worksheet.write(row, col + 1, "Image")
                   row += 1
               i= i+1
               user_arg = user_arg - 1
          else:
               Image_no = Image_no + 1
               worksheet.write(row, col, (Filename + "_" + temp3[0] + "_" + "IMG" + '%d' % Image_no ))
               worksheet.write(row, col + 1, "Image")
               row += 1
       else:
          tsf_line = re.sub("\s+", " ", tsf_line)
          widgetIndex = tsf_line.find(widgettype)
          ManualwidgetIndex = tsf_line.find(Manwidget)
          if widgetIndex == 5 or ManualwidgetIndex == 5:
             TBI_Present = tsf_line.find("WIDGETTYPE_FUNCTIONS_TBI")
             if TBI_Present == -1:
               if User_input > 1:
                  i=1
                  user_arg = User_input - 1
                  while(user_arg):
                    required_shalltag = int(sys.argv[i])
                    if (Each_shalltag == required_shalltag):
                       Video_no = Video_no + 1
                       worksheet.write(row1, col1, (Filename + "_" + temp3[0] + "_" + "VIDEO" + '%d' % Video_no ))
                       row1 += 1
                    i= i+1
                    user_arg = user_arg - 1
               else:
                  Video_no = Video_no + 1
                  worksheet.write(row1, col1, (Filename + "_" + temp3[0] + "_" + "VIDEO" + '%d' % Video_no ))
                  row1 += 1
       tsf_line = Ease.readline()
       tsf_line = tsf_line.strip()
       tsf_line = tsf_line.upper()
       shall_tag = 0
       shall_tag = tsf_line.find(str1)
       if (shall_tag == 3):
         EndFunc = True
       Exit_file = 1
       Exit_file = tsf_line.find(str3)
       if (Exit_file ==0):
         EndFunc = True
     #fd.write("\n")
  else:
   tsf_line = Ease.readline()
   tsf_line = tsf_line.strip()
   tsf_line = tsf_line.upper()
Ease.close()
workbook.close()