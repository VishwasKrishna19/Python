import sys
import os

arglist = ""
boolXmlPathExist = False

## Get the command line arguments
for arg in sys.argv:
    arglist = arglist + "," + arg

## Split the command line arguments into an array
arglistArray = arglist.split(',')

## Process if correct number of command line arguments are provided
if len(arglistArray) != 2:
    print("** Error: One Input Argument is Expected.. **")
    sys.exit()

## Enter the requirement document name
xmlPath = input("Enter the IDL_XMLs path: ")

## Process if the document path is provided
if xmlPath == "":
    print ("** Error: IDL_XMLs path not entered **")
    sys.exit()

## Check if the path exists
if not os.path.exists(xmlPath):
    print ("** Error Path '" + xmlPath + "' does not exist **")
    sys.exit()
else:
    boolXmlPathExist = True

## Function to identify the non blank lines
def nonBlankLines(f):
    for l in f:
        line = l.rstrip()
        if line:
            yield line

## Function to convert the X and Y co-ordinates to be passed onto the Remote parameters
def convertXY(x, y):
    gridXMin = -2.56
    gridXDst = 5.12
    gridYMin = -1.925
    gridYDst = 3.85
    xVal = 0.0
    yVal = 0.0

    xVal = (y + gridYMin)/-gridYDst
    yVal = ((((x + gridXMin) * 0.75)/-gridXDst) + 0.25)

    return (xVal, yVal)

## Function to parse the IDL_XMLs to identify the objects and their co-ordinates
def parseXML(xmlPath):
    ## Open a text file to populate the object co-ordinates
    objObjCoord = open(xmlPath + "\\XMLCoord.txt", "wb")
    ## Loop through the path provided to identify the files in the folder
    for root, dirs, file in os.walk(xmlPath):

        ## Loop through all the files present in the path specified
        for filename in file:
            ## Extract the base name and extension from the file name
            basename, extension = os.path.splitext(filename)
            ## Proceed only in case of IDL_XML file
            if extension.upper() == ".IDL_XML":
                strGroupName = ""
                strQuadName = ""
                blGroupFound = False
                blQuadFound = False
                strX = ""
                strY = ""
                fltAvgX = 0.0
                fltAvgY = 0.0
                lstX = []
                lstY = []

                ## Open the IDL_XML file
                objXML = open(xmlPath + "\\" + filename, "r", encoding="utf-16")

                print("\nParsing '" + filename + "'...\n")
                objObjCoord.write(("\nParsing '" + filename + "'...\n\n").encode("utf-8"))

                for line in nonBlankLines(objXML):
                    ## Start of a Group is reached
                    if line.strip().startswith("<group name="):
                        strGroupName = line[line.find("name=")+6:]
                        strGroupName = strGroupName[:strGroupName.find(" ")-1]
                        blGroupFound = True
                    ## End of a Group is reached
                    elif line.strip().startswith("</group>"):
                        blGroupFound = False
                    ## Start of a Quad is reached
                    elif blGroupFound and (line.strip().startswith("<quad ") or line.strip().startswith("<texture ")):
                        strQuadName = line[line.find("name=")+6:]
                        strQuadName = strQuadName[:strQuadName.find(" ")-1]
                        blQuadFound = True
                    ## End of a Quad is reached
                    elif blGroupFound and line.strip().startswith("</quad>") or line.strip().startswith("</texture>"):
                        blQuadFound = False
                        ## Proceed only when co-ordinates of all the four vertices are captured
                        ## Compute the average value of the X and Y co-ordinates
                        if len(lstX) == 4:
                            for item in lstX:
                                fltAvgX = fltAvgX + float(item)
                            fltAvgX = fltAvgX/4
                        if len(lstY) == 4:
                            for item in lstY:
                                fltAvgY = fltAvgY + float(item)
                            fltAvgY = fltAvgY/4
                        ## Convert the averaged X and Y co-ordinates to values that needs to be passed onto the remote parameters
                        fltAvgX, fltAvgY = convertXY(fltAvgX, fltAvgY)
                        ## Write the co-ordinates onto the text file
                        objObjCoord.write((strGroupName + " : " + strQuadName + " : " + format(fltAvgX, ".4f") + " - " + format(fltAvgY, ".4f") + "\n").encode("utf-8"))
                        print (strGroupName + " : " + strQuadName + " : " + format(fltAvgX, ".4f") + " - " + format(fltAvgY, ".4f"))
                        lstX = []
                        lstY = []
                    ## Capture the X and Y co-ordinates of a quad (x1y1, x2y1, x2y2,x1,y2)
                    elif blGroupFound and blQuadFound and line.strip().startswith("<vertex x"):
                        strX = line[line.find(" x=""")+4:line.find(" xbin")-1]
                        lstX.append(strX)
                        strY = line[line.find(" y=""")+4:line.find(" ybin")-1]
                        lstY.append(strY)

                objXML.close()
    objObjCoord.close()


if boolXmlPathExist:
    parseXML(xmlPath)