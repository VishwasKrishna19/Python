import string
import os
import sys
import re
import xlsxwriter
import xlrd
import glob
import math
import datetime

log1 = open("C:/Users/h126313/Desktop/NG/out.txt", 'w')

for file in os.listdir("C:/Users/h126313/Desktop/NG/PAR/"):
    if file.endswith("*PAR*.txt"):
        print(os.path.join("", file))
        log = open(file, 'r')
        line = log.read()
        print(line)
        while line:
            if any("SW Delivery ID") in line:
                print(line)
                log1.write(line)
                line = line.strip()
                break
            line = log.readline()
        log.close()
log1.close()


