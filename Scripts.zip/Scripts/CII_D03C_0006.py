import InitialSupport

from InitialSupport import *
TestName = "CII_D03C_0006"
Startsum(TestName)
#=======================================================================================================================
#	 INAVDBLAYER SOFTWARE TEST PLAN/PROCEDURE
#=======================================================================================================================
Output ("================================================================================================================")
Output ("TestName       :	CII_D03C_0006                                                                                 ")
Output ("ParagraphTitle :Runway Layer                                                                                    ")
Output ("================================================================================================================")
Output ("================================================================================================================")
Output ("                                             MODIFICATION HISTORY                                               ")
Output ("================================================================================================================")
Output (" Version     Date         Author         Change Description                             CH_DOC                  ")
Output ("================================================================================================================")
Output ("  01      11-Jul-16    Narayana Rao   Load 3.3: Initial Development     EDS_PRD_CINAV_CR_530/EDS_PRD_CINAV_TR_2277")
Output ("================================================================================================================")
Output ("                               REQUIREMENT TAGS (PARAGRAPH AND SHALL)                                           ")
Output ("================================================================================================================")
Output ("Primary Paragraph Tag : [PTAG::DDD C INAV DBL RUNWAY]")
Output ("Template Class        : DDD Graphic Functionality")
#=======================================================================================================================
#   TestCase::ShallTag                            TemplateType	 
#=======================================================================================================================
#[TC a::DDD C INAV DBL RUNWAY 10]                   Custom
#[TC b::DDD C INAV DBL RUNWAY 20]                   Custom
#[TC c::DDD C INAV DBL RUNWAY 30]                   Test By Inspection
#[TC d::DDD C INAV DBL RUNWAY 40]                   Test By Inspection
#[TC e::DDD C INAV DBL RUNWAY 50]                   Custom
#[TC f::DDD C INAV DBL RUNWAY 60]                   Custom
#[TC g::DDD C INAV DBL RUNWAY 70]                   Custom
#[TC h::DDD C INAV DBL RUNWAY 80]                   Custom
#[TC i::DDD C INAV DBL RUNWAY 75]                   Test By Inspection
#=======================================================================================================================
#=======================================================================================================================  
#=======================================================================================================================  
#                               TEST ENVIRONMENT SPECIFICATION 
#=======================================================================================================================
#                                   HARDWARE SETUP 
#-----------------------------------------------------------------------------------------------------------------------
#  Environment              :  Host Specific HardWare Environment, See Note below 
#  ESCAPE Configuration DB  :  Host Specific Configuration database(*.mdb), See Note below
#  ESCAPE Configuration Name:  Host Specific Configuration Name, See Note below 
#  ESCAPE Configuration is used for setting up the test environment only
#  Note: For host specific H/W environment setup refer section #Test Environment setup# from CORE_INAV_TEST_STRATEGY.doc available in PVCS at 
#  the location: INAV\CORE_INAV\TEST\TEST_MISC\ (Work Set: EDS_PRD:_WORK_MAIN). 
#==============================================================================================================
#                                         SOFTWARE SETUP 
#=====================================================================================================
# For this file to be executed, the custom built modules should be  loaded. Refer the Build Procedure document (Build_Procedure.doc)
# present in the Inavdblayer_Custom_Support.zip available in PVCS at the location: INAV\CORE_INAV\TEST\TEST_MISC\ (Work Set: EDS_PRD:_WORK_MAIN). 
# and load cutomized modules to corresponding cards and point vars in TIU Server as per build procedure.
#=====================================================================================================
#                                        GENERAL COMMENTS
#-----------------------------------------------------------------------------------------------------
# As CORE INAV is common for different hosts and hosts are having different User interfaces, Menus/Layers selection procedures might be different. 
# Refer COREINAV_Menu_Selection_Procedures_Guide.doc available in PVCS at the location: INAV\CORE_INAV\TEST\TEST_MISC\ (Work Set: EDS_PRD:_WORK_MAIN)
# for detailed procedures for Menus/Layers selection.

#======================================================================================================================
#                                  GENERAL SET-UP COMMANDS
#=======================================================================================================================
#-----------------------------------------------------------------------------------------------------------------------
#The following files are to be included in the project and should be in the following order
#1.QualifiedSupport.tsf
#2.ComConstantsAndFunctions.tsf
#3.GGF_ComconstantsAndFunctions.tsf
#4.CII_ComConstantsandfunctions.tsf
#5.CII_D03C_0006.tsf
#=======================================================================================================================
#-----------------------------------------------------------------------------------------------------------------------
#					                          DEFINE VARIABLES
#-----------------------------------------------------------------------------------------------------------------------
global PTAG, TemplateClass
global Input_condition,Expected_Result,TestID,CA_Justification,Category
#=======================================================================================================================
#                                       SUBROUTINES AND SUBFUNCTIONS
#-----------------------------------------------------------------------------------------------------------------------
PTAG = "DDD C INAV DBL RUNWAY"
Shall_Level_Test () 
TemplateClass = DDD_GRAPHICS
MessageBox ("Bring up the MAP page if not displayed")
#MessageBox "Ensure that same navigation database is loaded on to both AGM and FMS cards"
#-------------------------------------------------------------------------------------------------
#============================================================================================================
#                                          TEST CASES
#============================================================================================================
#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 10    --    Custom
#************************************************************************************************************
#============================================================================================================
#	TestStep     :  a1
#	Description  :  Set necessary variable(s) to enable the display of the desired graphic object with 
#                 proper functionality.
#	PassCriteria : The graphic object is displayed with the proper functionality as mentioned in DDD.
#------------------------------------------------------------------------------------------------------------
#============================================================================================================
If (CompareShallTag(10)):
Initialization (" a  --  DDD C INAV DBL RUNWAY 10   --   Custom")
MessageBox ("Ensure that same navigation database is loaded on to both AGM and FMS cards")
MessageBox ("Bring up the MAP window if not displaying")
#"""""""""""""""""""""""""""""""
#"""Runway Selection"""""
#"""""""""""""""""""""""""""""""
LayerSelection(5)
MessageBox ("Ceter the MAP to any Major Airport Ex:KINW")
MessageBox ("Adjust the MAP range to less than 25")
MessageBox ("Observe that runway symbol is displayed on DU")
PassFail ("Verify that runway symbol is displayed on DU")

#End If

#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 20    --    Custom
#************************************************************************************************************
#============================================================================================================
#	TestStep     :  b1
#	Description  :  Set necessary variable(s) to enable the display of the desired graphic object with 
#                 proper functionality.
#	PassCriteria : The graphic object is displayed with the proper functionality as mentioned in DDD.
#------------------------------------------------------------------------------------------------------------
#============================================================================================================
If (CompareShallTag(20)):
Initialization (" b  --  DDD C INAV DBL RUNWAY 20   --   Custom")

MessageBox ("Bring up the MAP window if not displaying")
#"""""""""""""""""""""""""""""""
#"""Runway Selection"""""
#"""""""""""""""""""""""""""""""
LayerSelection(5)
MessageBox ("Ceter the MAP to any Major Airport Ex: KLAX")
#eMapRangeDisplayMajorAirportRunways is set to 25.0 in configuration data
#eMapRangeDisplayMinorAirportRunways is set to 5 in configuration data


#TestCase 1a: MapRange = MapLayerRanges[eMapRangeDisplayMajorAirportRunways]
#-------------------------------------------------------------------------
MessageBox ("Adjust the map range to 25 (i.e Half range is 12.5NM)")
MessageBox ("Observe that Major Airport runway is displayable on DU which indicates that Runway data is processed")

PassFail ("Verify that runway symbol is displayed on DU")

#TestCase 1b: #mapRange > MapLayerRanges[eMapRangeDisplayMajorAirportRunways]
#--------------------------------------------------------------------------

MessageBox ("Adjust the map range greater than 25 (i.e Half range is more than 12.5NM)")
MessageBox ("Observe that Major airport runway is not displayable on DU which indicates that Runway data is not processed")

PassFail ("Verify that runway symbol is not displayed on DU")
#TestCase 1c: MapRange < MapLayerRanges[eMapRangeDisplayMajorAirportRunways]
#-------------------------------------------------------------------------
MessageBox ("Adjust the map range to less than 25 (i.e Half range is less than 12.5NM)")
MessageBox ("Observe that Major airport runway is displayable on DU which indicates that Runway data is processed")

PassFail ("Verify that runway symbol is displayed on DU")

MessageBox ("Ceter the MAP to any Minor Airport Ex: EGBW")
#TestCase 2a: mapRange = MapLayerRanges[eMapRangeDisplayMinorAirportRunways]
#-------------------------------------------------------------------------

MessageBox ("Adjust the map range to 5 (i.e Half range is 2.5NM)")
MessageBox ("Observe that Minor Airport runway is displayable on DU which indicates that Runway data is processed")

PassFail ("Verify that runway symbol is displayed on DU.")

#TestCase 2b: mapRange > MapLayerRanges[eMapRangeDisplayMinorAirportRunways]
#-------------------------------------------------------------------------

MessageBox ("Adjust the map range greater than 5 (i.e Half range is greater than 2.5NM)")
MessageBox ("Observe that Minor airport runway is not displayable on DU which indicates that Runway data is not processed")

PassFail ("Verify that runway symbol is not displayed on DU")

#TestCase 2c: mapRange < MapLayerRanges[eMapRangeDisplayMinorAirportRunways]
#-------------------------------------------------------------------------
Input_condition = "When  map range to less than 5 (i.e Half range is less than 2.5NM)"
Expected_Result = "Minor airport runway is displayable on DU which indicates that Runway data is processed"
TestID = "DDD C INAV DBL RUNWAY 20"
CA_Justification = "Due to host limitation MapRange < 2.5NM is not possible to set. Hench test by inspection called."
Category = EL

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)



#MessageBox "Adjust the map range to less than 5 (i.e Half range is less than 2.5NM)"
#MessageBox "Observe that Minor airport runway is displayable on DU which indicates that Runway data is processed"
#Passfail "Verify that runway symbol is displayed on DU"
#End If

#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 30    --    Test By Inspection
#************************************************************************************************************
#=================================================================================================
#	TestStep     :	c1
#	Description  :	Independent Code Analysis.
#	PassCriteria :	Code Analysis being performed by person other than the author of the code    Analysis 
#Initials: _______________
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	c2
#	Description  :	Name and CM Version of file under review
#	PassCriteria :	Module and/or Function Name: _________________      CM Version: ____               
#Document chapter: __________    CM Version: _____
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	c3
#	Description  :	Requirements Implemented.  Identify which lines of code in the module under review 
#incorporate requirements  _________________________________
#	PassCriteria :	Code implements the requirements as defined in the requirement document  Y/N  ___
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	c4
#	Description  :	Structural Coverage Analysis
#	PassCriteria :	Software and software structures (when applicable) are accessible under conditions 
#specified by requirements  Y/N:  _____
#-------------------------------------------------------------------------------------------------
#=================================================================================================
If (CompareShallTag(30)):
Initialization (" c  --  DDD C INAV DBL RUNWAY 30   --   Test By Inspection")

Input_condition = "When the number of Runway record data is more than DBL_MAX_NUMBER_OF_RUNWAYS i.e 250."
Expected_Result = "Number of Runway record data is limited to DBL_MAX_NUMBER_OF_RUNWAYS i.e 250."
TestID = "DDD C INAV DBL RUNWAY 30"
CA_Justification = "It is not possible to simulate the Runway symbols equal to or greater than DBL_MAX_NUMBER_OF_RUNWAYS i.e 250 in the current Test environment. Hence test by inspection called."
Category = EL

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If
#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 40    --    Test By Inspection
#************************************************************************************************************
#=================================================================================================
#	TestStep     :	d1
#	Description  :	Independent Code Analysis.
#	PassCriteria :	Code Analysis being performed by person other than the author of the code    Analysis 
#Initials: _______________
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	d2
#	Description  :	Name and CM Version of file under review
#	PassCriteria :	Module and/or Function Name: _________________      CM Version: ____               
#Document chapter: __________    CM Version: _____
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	d3
#	Description  :	Requirements Implemented.  Identify which lines of code in the module under review 
#incorporate requirements  _________________________________
#	PassCriteria :	Code implements the requirements as defined in the requirement document  Y/N  ___
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	d4
#	Description  :	Structural Coverage Analysis
#	PassCriteria :	Software and software structures (when applicable) are accessible under conditions 
#specified by requirements  Y/N:  _____
#-------------------------------------------------------------------------------------------------
#=================================================================================================
If (CompareShallTag(40)):
Initialization (" d  --  DDD C INAV DBL RUNWAY 40   --   Test By Inspection")

#RunwayandfeatherList.RunwayList.Bearing
Input_condition = "When Runway bearing and airport magnetic variation obtained from database."
Expected_Result = "Each runway record of RunwayandfeatherList is updated with bearing."
TestID = "DDD C INAV DBL RUNWAY 40"
CA_Justification = "As RunwayandfeatherList.RunwayList.Bearing is internal data it is not possible to verify in the current Test environment. Hence test by inspection called."
Category = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#RunwayandfeatherList.RunwayList.Length
Input_condition = "When Runway Length obtained from database."
Expected_Result = "Each runway record of RunwayandfeatherList is updated with Length."
TestID = "DDD C INAV DBL RUNWAY 40"
CA_Justification = "As RunwayandfeatherList.RunwayList.Bearing is internal data it is not possible to verify in the current Test environment. Hence test by inspection called."
Category = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#RunwayandfeatherList.RunwayList.StartLat
Input_condition = "When Runway StartLat obtained from database."
Expected_Result = "Each runway record of RunwayandfeatherList is updated with StartLat."
TestID = "DDD C INAV DBL RUNWAY 40"
CA_Justification = "As RunwayandfeatherList.RunwayList.Length is internal data it is not possible to verify in the current Test environment. Hence test by inspection called."
Category = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#RunwayandfeatherList.RunwayList.StartLon
Input_condition = "When Runway StartLon obtained from database."
Expected_Result = "Each runway record of RunwayandfeatherList is updated with StartLon."
TestID = "DDD C INAV DBL RUNWAY 40"
CA_Justification = "As RunwayandfeatherList.RunwayList.StartLon is internal data it is not possible to verify in the current Test environment. Hence test by inspection called."
Category = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#RunwayandfeatherList.RunwayList.EndLat
Input_condition = "When Runway EndLat obtained from database."
Expected_Result = "Each runway record of RunwayandfeatherList is updated with EndLat."
TestID = "DDD C INAV DBL RUNWAY 40"
CA_Justification = "As RunwayandfeatherList.RunwayList.EndLat is internal data it is not possible to verify in the current Test environment. Hence test by inspection called."
Category = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#RunwayandfeatherList.RunwayList.EndLon
Input_condition = "When Runway EndLon obtained from database."
Expected_Result = "Each runway record of RunwayandfeatherList is updated with EndLon."
TestID = "DDD C INAV DBL RUNWAY 40"
CA_Justification = "As RunwayandfeatherList.RunwayList.EndLon is internal data it is not possible to verify in the current Test environment. Hence test by inspection called."
Category = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

#End If



#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 50    --    Custom
#************************************************************************************************************
#============================================================================================================
#	TestStep     :  e1
#	Description  :  Set necessary variable(s) to enable the display of the desired graphic object with 
#                 proper functionality.
#	PassCriteria : The graphic object is displayed with the proper functionality as mentioned in DDD.
#============================================================================================================
If (CompareShallTag(50)):
Initialization (" e  --  DDD C INAV DBL RUNWAY 50   --   Custom")
#As ScaleFactor depends on MAP Range, this requirement is verified indirectly by changing MAP range
#Saclefactor = MAP_RANGE_RING_RADIUS/MAP half range 
MessageBox ("Bring up the MAP window if not displaying")
#"""""""""""""""""""""""""""""""
#"""Runway Selection"""""
#"""""""""""""""""""""""""""""""
LayerSelection(5)
MessageBox ("Ceter the MAP to any Airport Ex:KPHX")
MessageBox ("Ensure that runways are displayed on Lateral MAP by adjusting map range")
MessageBox ("Observe the variation in size of any runway by changing the MAP range within the limits runway is being displayed")
PassFail ("Verify that size of runway vary according to the ScaleFactor")
#End If

#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 60    --    Custom
#************************************************************************************************************
#============================================================================================================
#	TestStep     :  f1
#	Description  :  Set necessary variable(s) to enable the display of the desired graphic object with 
#                 proper functionality.
#	PassCriteria : The graphic object is displayed with the proper functionality as mentioned in DDD.
#------------------------------------------------------------------------------------------------------------
#============================================================================================================
If (CompareShallTag(60)):
Initialization (" f  --  DDD C INAV DBL RUNWAY 60   --   Custom")

MessageBox ("Bring up the MAP window if not displaying")
#"""""""""""""""""""""""""""""""
#"""Runway Selection"""""
#"""""""""""""""""""""""""""""""
LayerSelection(5)
MessageBox ("Ceter the MAP to any Airport Ex:KLAX")
MessageBox ("Set the MAP to Heading up mode")
MessageBox ("Ensure that runways are displayed on Lateral MAP by adjusting map range")
MessageBox ("Change the Aircraft#s #True Heading# to change MAP orientation")
MessageBox ("Observe that orientation of runway symbol is as per change in map rotation angle")
PassFail ("Verify that orientation of runway symbol is as per map rotation angle")

#MapRange ≤   MapLayerRanges[eMapRangeDisplayMinorAirportsSymbols]
#MapLayerRanges[eMapRangeDisplayMinorAirportsSymbols] = 5.0f
#""""""""""""""""""""
#""""Test Case-1"""""
#""""""""""""""""""""

#TestCase 1a: mapRange = MapLayerRanges[eMapRangeDisplayMinorAirportsSymbols]
#-------------------------------------------------------------------------

MessageBox ("Adjust the map range to 5 (i.e Half range is 2.5NM)")
MessageBox ("Observe that Minor Airport symbols are displayed on DU")

PassFail ("Verify that Minor Airport symbols are displayed on DU.")

#TestCase 1b: mapRange > MapLayerRanges[eMapRangeDisplayMinorAirportsSymbols]
#-------------------------------------------------------------------------

MessageBox ("Adjust the map range greater than 5 (i.e Half range is greater than 2.5NM)")
MessageBox ("Observe that Minor Airport symbols are displayed on DU")

PassFail ("Verify that Minor Airport symbols are displayed on DU")

#TestCase 1c: mapRange < MapLayerRanges[eMapRangeDisplayMinorAirportsSymbols]
#-------------------------------------------------------------------------
Input_condition = "When  map range to less than 5 (i.e Half range is less than 2.5NM)"
Expected_Result = "Minor airport runway is displayable on DU which indicates that Runway data is processed"
TestID = "DDD C INAV DBL RUNWAY 60"
CA_Justification = "Due to host limitation MapRange < 2.5NM is not possible to set. Hench test by inspection called."
Category = EL

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#MapRange ≤ MapLayerRanges[eMapRangeDisplayMajorAirportRunways]
#""""""""""""""""""""
#""""Test Case-2"""""
#""""""""""""""""""""
#MapLayerRanges[eMapRangeDisplayMajorAirportRunways] = 25.0f
MessageBox ("Ceter the MAP to any Major Airport Ex: KLAX")

#TestCase 2a: MapRange = MapLayerRanges[eMapRangeDisplayMajorAirportRunways]
#-------------------------------------------------------------------------
MessageBox ("Adjust the map range to 25 (i.e Half range is 12.5NM)")
MessageBox ("Observe that Major Airport runway is displayable on DU which indicates that Runway data is processed")

PassFail ("Verify that runway symbol is displayed on DU")

#TestCase 2b: #mapRange > MapLayerRanges[eMapRangeDisplayMajorAirportRunways]
#--------------------------------------------------------------------------

MessageBox ("Adjust the map range greater than 25 (i.e Half range is more than 12.5NM)")
MessageBox ("Observe that Major airport runway is not displayable on DU which indicates that Runway data is not processed")

PassFail ("Verify that runway symbol is not displayed on DU")
#TestCase 2c: MapRange < MapLayerRanges[eMapRangeDisplayMajorAirportRunways]
#-------------------------------------------------------------------------
MessageBox ("Adjust the map range to less than 25 (i.e Half range is less than 12.5NM)")
MessageBox ("Observe that Major airport runway is displayable on DU which indicates that Runway data is processed")

PassFail ("Verify that runway symbol is displayed on DU")



#End If

#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 70    --    Custom
#************************************************************************************************************
#============================================================================================================
#	TestStep     :  g1
#	Description  :  Set necessary variable(s) to enable the display of the desired graphic object with 
#                 proper functionality.
#	PassCriteria : The graphic object is displayed with the proper functionality as mentioned in DDD.
#------------------------------------------------------------------------------------------------------------
#============================================================================================================
If (CompareShallTag(70)):
Initialization (" g  --  DDD C INAV DBL RUNWAY 70   --   Custom")
#"""""""""""""""""""""""""""""""
#"""Runway Selection"""""
#"""""""""""""""""""""""""""""""
LayerSelection(5)

#TestCase 1: Color of any runway
#-------------------------------
#RunwayColor.Value1=1.0000000f,RunwayColor.Value2=1.0000000f,RunwayColor.Valu3=0.0000000f,RunwayColor.Value4=1.0000000f 
MessageBox ("Ceter the MAP to any Airport Ex:KLAX")
MessageBox ("Adjust the map range in such a way that runways are displayable other than FMS selected runways")
MessageBox ("Observe the Color of any runway other than FMS selected runway is Yellow")

PassFail ("Verify that color of any runway other than FMS selected runway is Yellow")

#TestCase 2: color of the border any of runway
#---------------------------------------------
#RunwayBorderColor.Value1=1,RunwayBorderColor.Value2=0,RunwayBorderColor.Value3=0,RunwayBorderColor.Value4=1
MessageBox ("Observe the Color of any Runway border is Red")
PassFail ("Verify that color of any Runway border is Red")

#End If


#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 80    --    Custom
#************************************************************************************************************
#============================================================================================================
#	TestStep     :  h1
#	Description  :  Set necessary variable(s) to enable the display of the desired graphic object with 
#                 proper functionality.
#	PassCriteria : The graphic object is displayed with the proper functionality as mentioned in DDD.
#------------------------------------------------------------------------------------------------------------
#============================================================================================================
If (CompareShallTag(80)):
Initialization (" h  --  DDD C INAV DBL RUNWAY 80   --   Custom")

#"""""""""""""""""""""""""""""""
#"""Runway Selection"""""
#"""""""""""""""""""""""""""""""
LayerSelection(5)

#eMapRangeDisplayILS=25
#""""""""""""""""""""
#""""test Case-1"""""
#""""""""""""""""""""
MessageBox ("Ceter the MAP to any Airport Ex:KPHX")
MessageBox ("Adjust the map range in such a way that runways are displayable other than FMS selected runways")
MessageBox ("Adjust the map range below 50")
MessageBox ("Ils feather is rendered on DU")
#MapDspRenderRwyAndFeather Is used To render the runway And feathers On Lateral map which Is called from _DBL_RenderAirports
PassFail ("Verify that ILS feather for the given(KPHX) runway has to dispalyed on DU")

#""""""""""""""""""""
#""""test Case-2"""""
#""""""""""""""""""""

#each set of runway data stored in StRunwayListDrawData 

MessageBox ("Ceter the MAP to any Airport Ex:KPHX")
MessageBox ("Adjust the map range in such a way that runways are displayable other than FMS selected runways")
MessageBox ("Adjust the map range below 50")
MessageBox ("Observe that Runways are rendered on DU")
#MapDspRenderRwyAndFeather Is used To render the runway And feathers On Lateral map which Is called from _DBL_RenderAirports
PassFail ("Verify that Runways are rendered on DU with start and end Lat/Lon values")


#""""""""""""""""""""
#""""test Case-3"""""
#""""""""""""""""""""

If(Host_Input = 1):
#
#For GLS
#TestCase 1: runway feather type is GLS
#---------------------------------------
Input_condition = "When GetDBLStaticConfigData()->GLSFeatherEnable is TRUE) AND runway feather type is GLS"
Expected_Result = "Draw GLSFeather on LMAP"
TestID = "DDD C INAV DBL RUNWAY 80"
CA_Justification = "Not possible to verify GLSFeather on DU with the current environment.Hence test by inspection called."
Category = EL

TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)

ElseIf(Host_Input = 2):
#E2
#TestCase 1: runway feather type is GLS
#GetDBLStaticConfigData()->GLSFeatherEnable=true
MessageBox ("Before Loading the flight Plan ,set the APM varaible #glsApproachType# to Cat-1GLSEnabled")
MessageBox "Keep the FMS in download and: normal mode by using bench loader tool"
MessageBox ("Load flight plan from KPHX-KEWR")
MessageBox ("Select NAV, Create Arrival procedure On #KEWR# with #Approach# as GLS, Approach Trans# as #WUSIP# and apply and activate it")
MessageBox ("Set the lateral Map Range To #2.5#")
MessageBox ("Adjust the lateral Map Range so that GLS can be view on the map page")
PassFail ("Verify that GLS feather is displayed on the map page")

#End If
#End If

#************************************************************************************************************
#	DDD C INAV DBL RUNWAY 75    --    Test By Inspection
#************************************************************************************************************
#=================================================================================================
#	TestStep     :	i1
#	Description  :	Independent Code Analysis.
#	PassCriteria :	Code Analysis being performed by person other than the author of the code    Analysis 
#Initials: _______________
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	i2
#	Description  :	Name and CM Version of file under review
#	PassCriteria :	Module and/or Function Name: _________________      CM Version: ____               
#Document chapter: __________    CM Version: _____
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	i3
#	Description  :	Requirements Implemented.  Identify which lines of code in the module under review 
#incorporate requirements  _________________________________
#	PassCriteria :	Code implements the requirements as defined in the requirement document  Y/N  ___
#-------------------------------------------------------------------------------------------------
#=================================================================================================
#=================================================================================================
#	TestStep     :	i4
#	Description  :	Structural Coverage Analysis
#	PassCriteria :	Software and software structures (when applicable) are accessible under conditions 
#specified by requirements  Y/N:  _____
#-------------------------------------------------------------------------------------------------
#=================================================================================================
If (CompareShallTag(75)):
Initialization (" i  --  DDD C INAV DBL RUNWAY 75   --   Test By Inspection")

Input_condition = "dboffset of a particular airport when _DBL_BuildDBOffsetRunwayFeather function is invoked."
Expected_Result = "runway draws for an airport based on the dbOffset passed to the function."
TestID = "DDD C INAV DBL RUNWAY 75"
CA_Justification = "As dbOffset is changes with the database.Hence it is not possible to verify dbOffset of a particular airport in the current Test environment. Hence test by inspection called."
Category = EL
TestByInspectionOutput1(Input_condition, Expected_Result, TestID,CA_Justification,Category)


#End If

#---------------------------------------------------------------------------------------------------------------------------
#                                  PRINT FINAL RESULTS
#----------------------------------------------------------------------------------------------------------------------------
ReportSummary()