with open("C:\\Users\\h126313\\Desktop\\Python\\Ashwini\\Data.txt", "r") as inputdata:
    with open("C:\\Users\\h126313\\Desktop\\Python\\Ashwini\\Data1.txt", "w") as output:
        for line in inputdata:
            if line.__contains__("#"):
                output.write(line)