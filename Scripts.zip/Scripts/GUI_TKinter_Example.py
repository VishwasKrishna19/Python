import tkinter
from tkinter import *
from tkinter import filedialog
import xlrd
import os
import codecs
import time

root = tkinter.Tk()
title = root.title("Trace Tool")
button = tkinter.Button(root, text='Exit', width=10, command=root.destroy)

w = Label(root, text="TRACE MISS TOOL", bg="red", fg="white")
w.pack(fill=X)

currdir = os.getcwd()
if os.path.exists('inputfilenampath.txt'): os.remove('inputfilenampath.txt')
if os.path.exists('inputfolderpath.txt'): os.remove('inputfolderpath.txt')

MyText= StringVar()
MyText1= StringVar()
global filename

def browsefunc():
    filename = filedialog.askopenfilename()
    MyText.set(filename)
    with open('inputfilenampath.txt', "w") as w:
        w.write(str(filename))
    return filename

def browsefunc_folder():
    filename1 = filedialog.askdirectory()
    MyText1.set(filename1)
    with open('inputfolderpath.txt', "w") as w1:
        w1.write(str(filename1))
    return filename1

back = tkinter.Frame(master=root, width=500, height=100)
back.pack()

browsebutton = Button(root, text="Browse the Doors Requirment Object ID", command=browsefunc)
browsebutton.pack(pady=10)

entry = tkinter.Entry(root, textvariable = MyText, width = 50).pack()

broButton = tkinter.Button(master = root, text = 'Browse the Test folder',command=browsefunc_folder)
broButton.pack(pady=10)

entry1 = tkinter.Entry(root, textvariable = MyText1, width = 50).pack()

#Function: duplicate()
#Purpose : Remove the dulicate Test names from the list and return the unique test lists
def duplicate(testname):
    final_list = []
    for num in testname:
        if num not in final_list:
            final_list.append(num)
    return final_list

def Traceloop():
    #Get the current working directory
    os.getcwd()
    input = open('inputfilenampath.txt', 'r')
    inputfilenamepath = input.readline()

    input1 = open('inputfolderpath.txt', 'r')
    inputfolderpath = input1.readline()

    print(inputfilenamepath)
    print(inputfolderpath)

    #Open the xls sheet with xlrd package
    wb = xlrd.open_workbook(inputfilenamepath)
    sheet = wb.sheet_by_index(0)

    #start reading from the first row first and first column
    sheet.cell_value(0, 0)

    #If Trace_Data.csv is already present in the working directory then delete it
    if os.path.exists('Trace_Data.csv'): os.remove('Trace_Data.csv')

    #Open the Trace_data.csv file
    with open("Trace_Data.csv", 'a', newline='', encoding="utf-8") as traceoutput:
        #Read only first column one by one
        for i in range(sheet.nrows):
            ReqId = sheet.cell_value(i,0)
            #Create the Empty list
            testname = []
            #Read all the tsf and cpp files present in the directory and sub directory
            for root, dirs, files in os.walk(inputfolderpath):
                for file in files:
                    #Read only tsf and cpp files
                    if file.endswith(".tsf") or file.endswith(".cpp"):
                        #Codecs will be used to handle multi code characters
                        with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as tsffiles:
                            #Read the lines in the files
                            for line in tsffiles:
                                #If line containing TP_ then read only those files, this is because to identify the trace holes, if object ID id is miised to trace then this will be skipped
                                if line.__contains__('[TP_'):
                                    if line.__contains__(ReqId):
                                        tsfname = tsffiles.name
                                        tsfname = tsfname.split('\\')[-1]
                                        #Identify the test name from the searched file
                                        testname.append(tsfname)
            #If List is Empty write Object ID is Not Tested
            if not testname:
                testname.append("Object ID NOT Tested")
            #If List is not empty wirte the test names in the list and remove the duplicates
            testnamedata = duplicate(testname)
            testnamedata = ":".join(testnamedata)
            print(testnamedata)
            #print(ReqId + ':' + testnamedata)
            #Print the final data in the format
            final_data = ReqId + ',' + str(testnamedata)
            #writing to the output file
            traceoutput.write(final_data + '\n')

    print("Trace Check is Completed")
    time.sleep(2)

root.bind("<Return>", Traceloop)
tkinter.Button(root, text='Run', command=Traceloop, width=10, height=0).pack(pady=10)
tkinter.Button(root, text='Exit', command=root.destroy, width=10, height=0).pack(pady=20)

w = tkinter.Label(root, text="Feedback:Vishwas Krishna(H126313)")
w.pack(side=RIGHT)
root.mainloop()