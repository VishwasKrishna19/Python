import docx

def readtxt(filename):
    doc = docx.Document(filename)
    fullText = []
    for para in doc.paragraphs:
        fullText.append(para.text)
    return '\n'.join(fullText)

Filedata = readtxt('C:\Vishwas\Task_Assigned\Python\DARE_Docs\DARE\DARE_7.docx')
print(Filedata)