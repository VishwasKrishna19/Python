#Line to open the File
filedata = input("Enter the path and input file: ")
fp = open(filedata, "r")
listval = []
for line in fp:
    line = line.strip()
    if line.startswith("From "):
       EmailAddrs = line.split()[1]
       listval.append(EmailAddrs)
       my_dict = {i: listval.count(i) for i in listval}
print(my_dict)
x = my_dict.items()
#max = sorted(x, key= lambda x: x[1], reverse=True)[0] #For Maximum Item
max = max(x, key= lambda x: x[1])
#Max_Value = max(my_dict.values())
max = ' '.join(str(i) for i in max)
print(max) #output = cwen@iupui.edu 5
#min = sorted(x, key= lambda x: x[1], reverse=False)[0] #For Minimum Item
min = min(x, key= lambda x: x[1])
min = ' '.join(str(i) for i in min)
print(min) #output = wagnermr@iupui.edu 1