#|--------------------------------------------------------------------
#| This work contains information that is the property of
#| Honeywell International Inc. Except for rights expressly
#| granted by contract to the United States government, this
#| work may not, in whole or in part, be duplicated, disclosed
#| or used for design or manufacturing purposes without prior
#| written permission of Honeywell International Inc.
#|
#*********************************************************************
#|                   PROGRAM:  ICPCS: 777 CPOV
#*********************************************************************
#|
#| Company Name: Honeywell International
#| 11100 N. Oracle Road
#| Tucson, AZ
#| Claims/Conditions: Copyright 2002-03
#| Honeywell Confidential & Proprietary
#|
#| FILE: MSTP75.INT
#|
#| Tests the current feedback.
#|
#| Reqmts tested include: MSSRS219, MSSDD134, MSSRS320, MSSDD128
#|
#| Refer to test case MSTC55.
#|--------------------------------------------------------------------

import Test_harness_777
import ngccomm
TH = Test_harness_777
#Declaring all device and channel variables as global variable
xNgcDriver = 0
obj_NGC7_NGC = 0
NGC7 = 7

def Init():
	global xNgcDriver
	global obj_NGC7_NGC
	################# Connection to NGC device ##################################
	# Create NGC device instance
	xNgcDriver = ngccomm.DeviceDriver()
	# Get the required channel objects from NGC device
	obj_NGC7_NGC = xNgcDriver.GetDeviceChannel(NGC7)


def Test_1():



 
#+-----------------------------------------------------------------------------
#| Header for results file
#+-----------------------------------------------------------------------------

  TH.Message(";+-------------------------------------------------------------------")
  TH.Message("\n")
  TH.Message("; PROGRAM:  ICPCS: 777 CPOV                                       ")
  TH.Message("\n")
  TH.Message(";+-------------------------------------------------------------------")
  TH.Message("\n")
  TH.Message("File Name   : MSTP75.log")
  TH.Message("\n")
  TH.Message("Reqmt Tested: MSSRS219, MSSDD134, MSSRS320, MSSDD128")
  TH.Message("\n")
  TH.Message("\n")

#+---------------------------------------------------------------------------
#+ During power-up there is four consecutive reads of the motor phase current
#+ analog inputs I_A_COUNTS and I_B_COUNTS.
#+
#+ TESTCASE 01: Test if the average of I_A_COUNTS and the average of
#+ I_B_COUNTS are both in the range of 512+/-100 counts.
#+
#+ Verify I_FEEDBACK_BIT_FLT = FALSE, Bit 3 / BIT_FAULT
#+---------------------------------------------------------------------------
  

  TH.Message("Testing TestCase 01...")
  
  TH.Pause(3)

  
  TH.Message("\n")
  TH.Message("TESTCASE 01:")
  TH.Message("\n")
  TH.Message("Test Results:")
  TH.Message("\n")
  
  TH.Message("         I_A_COUNTS  = 512+/-100")
  TH.Message("\n")
  retcode, Test_I_A_COUNTS = obj_NGC7_NGC.ReadSymbol("I_A_COUNTS")
  TH.VerifyTol(Test_I_A_COUNTS,512,100 ,"I_A_COUNTS")
  TH.Message("\n")
  
  TH.Message("         I_B_COUNTS  = 512+/-100")
  TH.Message("\n")
  retcode, Test_I_B_COUNTS = obj_NGC7_NGC.ReadSymbol("I_B_COUNTS")
  TH.VerifyTol(Test_I_B_COUNTS,512,100 ,"I_B_COUNTS")
  TH.Message("\n")
  
  TH.Message("         I_FEEDBACK_BIT_FLT = FALSE")
  TH.Message("\n")
  retcode, Test_I_FEEDBACK_BIT_FLT = obj_NGC7_NGC.ReadSymbol("I_FEEDBACK_BIT_FLT")
  TH.Verify(Test_I_FEEDBACK_BIT_FLT,0,"I_FEEDBACK_BIT_FLT")
  retcode, Test_BIT_FAULT = obj_NGC7_NGC.ReadSymbol("BIT_FAULT")
  retcode, Actual_value =  Test_BIT_FAULT & 8h
  TH.Verify(Actual_value,0h,"BIT_FAULT")
  TH.Message("\n")
  TH.Message("\n")
    
#+---------------------------------------------------------------------------
#+ Close AS/MS TDLs
#+---------------------------------------------------------------------------
  

  TH.Message("Testing completed.")

  TH.Pause(3)
  

  TH.Message("\n")
  TH.Message("----------------- End Test -------------------")
  TH.Message("\n")

#
# Print the test summary at the end
#

def RunTest():
	Init()
	Test_1()

if __name__ == '__main__':
	TH.RunTest(RunTest, "MSTP75.log"," Write Verification",True,True)
	del xNgcDriver
	del obj_NGC7_NGC
