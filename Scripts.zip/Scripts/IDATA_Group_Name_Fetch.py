#--------------------------------------------------------------------------------------
# Author: Vishwas Krishna
#Purpose: To fetch the Group Names from XMLS
#--------------------------------------------------------------------------------------

import chardet
from numpy import *
import glob, os
import re

class SmartReader(object):
    def __init__(self, function_to_call, default_return):
        self.fun = function_to_call
        self.default_return = default_return

    def read(self, file):
        return self._open_and_execute(file)

    def _predict_encoding(self, file, nLines=1000):
        # Open the file as binary data
        with open(file, 'rb') as f:
            rawdata = b''.join([f.readline() for _ in range(nLines)])
            # print(chardet.detect(rawdata)['encoding'])
            return chardet.detect(rawdata)['encoding']

    def _open_and_execute(self, file):
        """
        Open the different encoding files and invoke the call back function
        with the file handler.
        """

        # Get encoding
        encd = self._predict_encoding(file)
        try:
            with open(file, 'r', encoding=encd) as f:
                return self.fun(f)
        except:
            pass
        try:
            with open(file, 'r') as f:
                return self.fun(f)
        except:
            pass
        try:
            with open(file, 'r', encoding='utf-8') as f:
                return self.fun(f)
        except:
            pass
        print('Not able to read', file)
        # Return default
        return self.default_return


sreder = SmartReader(lambda x: x.readlines(), [])

def getfilelist(path):
    files = glob.glob(os.path.join(path, r'**'), recursive=True)
    # print(files)
    XML_Files = [x for x in files if os.path.splitext(x)[1].lower() == '.idl_xml']
    return XML_Files

def get_XML_data(file):
    with open("Groupname.csv", "a") as fileout:
        finalgroupname = ""
        filedata = ""
        print(os.path.basename(file))
        filename = os.path.basename(file)
        fdata = sreder.read(file)
        for eachline in fdata:
            if '<group name=' in eachline and 'tracetag=' in eachline:
                groupname = re.findall(r"<group name=\"[\w]+\"", eachline)
                for eachitem in groupname:
                    finalgroupname = eachitem.split("\"")[1]
                    finalgroupname = finalgroupname.split("\"")[0]
                    print(filename + "," + finalgroupname)
                    filedata = filename + "," + finalgroupname + "\n"
                fileout.write(filedata)


XMLRead = "C:\\Vishwas\\Task_Assigned\\CA4\\MMECL\\Build\\EDSTSC_GS_00_005\\GTSC\\Software\\Tgf\\Format04\\"
#XMLRead = input("Drag and Drop the folder containing XMLs : ")

XML_Files = getfilelist(XMLRead)
if os.path.exists('Groupnames.csv'): os.remove('Groupnames.csv')
for eahfile in XML_Files:
    xmldata = get_XML_data(eahfile)

