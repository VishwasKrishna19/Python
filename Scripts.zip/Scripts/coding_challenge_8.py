# Question 45

### **Question:**
#>***Define a class named American which has a static method called printNationality.***
#---------------------
#### Hints:
#>***Use @staticmethod decorator to define class static method.There are also two more methods.To know more, go to this [link](https://realpython.com/blog/python/instance-class-and-static-methods-demystified/).***

class American:
    def __init__(self, firstname, lastname, citizen):
        self.firstname = firstname
        self.lastname = lastname
        self.citizen = citizen
    @staticmethod
    def printnationality():
        # fullname = self.firstname + self.lastname
        # print(f'{fullname} is a {self.citizen} citizen')
        print('Indian')

citi = American("Vishwas", "Krishna", "Indian")
print(citi.printnationality())

# Question 46

### **Question:**
#>***Define a class named American and its subclass NewYorker.***
#------------
#### Hints:
#>**Use class Subclass(ParentClass) to define a subclass.***

class American:
    def __init__(self, firstname, lastname, citizen):
        self.firstname = firstname
        self.lastname = lastname
        self.citizen = citizen

    def printnationality(self):
        # fullname = self.firstname + self.lastname
        # print(f'{fullname} is a {self.citizen} citizen')
        print('Indian')

class Newyork(American):
    def worker(self, company):
        self.company = company
        self.firstname = "KKKKKKKK"

citi = American("Vishwas", "Krishna", "Indian")
citi1 = Newyork("asasd", "Krisashna", "American")

# Question 47

### **Question**
#> ***Define a class named Circle which can be constructed by a radius. The Circle class has a method which can compute the area.***
#----------------------
#### Hints
#> ***Use def methodName(self) to define a method.***

class Circle:
    def __init__(self, radius):
        self.radius = radius
    def area(self):
        return self.radius**2*3.14

c1 = Circle(4)
print(c1.area())

class Rectangle:
    def __init__(self, Length, breadth):
        self.Length = Length
        self.breadth = breadth
    def arearectangle(self):
        return self.Length * self.breadth

r1 = Rectangle(2,3)


# Question 53
### **Question**
#> ***Assuming that we have some email addresses in the "username@companyname.com" format, please write program to print the user name of a given email address. Both user names and company names are composed of letters only.***
#> ***Example:
#If the following email address is given as input to the
#program:***
#john@google.com
#> ***Then, the output of the program should be:***
#john
#> ***In case of input data being supplied to the question, it should be assumed to be a console input.***
#----------------------
#### Hints
#> ***Use \w to match letters.***
import re
str = "username@companyname.com, john@google.com, Vishwas.Krishna@honeywell.com"
# val = re.match(r'\w+(?=@)', str)
pattren = "[A-Za-z0-9._-]+(?=@)"
val = re.findall(pattren, str)
print(val)

pattren2 = "(?<=@)[A-za-z0-9]+"
companyname = re.findall(pattren2,str)
print(companyname)

# Question 55

### **Question**
#>***Write a program which accepts a sequence of words separated by whitespace as input to print the words composed of digits only.***
#>***Example:
#If the following words is given as input to the program:***
'''
2 cats and 3 dogs.
'''
#>***Then, the output of the program should be:***
'''
['2', '3']
>***In case of input data being supplied to the question, it should be assumed to be a console input.***
'''

inputstr = "2 cats and 3 dogs."
liststr = []
for eachstr in inputstr:
    if eachstr.isdigit():
        liststr.append(eachstr)

print(liststr)

strdata = "\d+"
strdata = re.findall(strdata, inputstr)
print(strdata)

import zlib
s = 'hello world!hello world!hello world!hello world!'
#t = zlib.compress(s)
#print(t)
#print(zlib.decompress(s))

subjects=["I", "You"]
verbs=["Play", "Love"]
objects=["Hockey","Football"]
for i in range(len(subjects)):
    for j in range(len(verbs)):
        for k in range(len(objects)):
            sentence = "%s %s %s." % (subjects[i], verbs[j], objects[k])
            print(sentence)

# Question 80

### **Question**
#>***Please write a program to print the list after removing even numbers in [5,6,77,45,22,12,24].***
#----------------------
#### Hints
#> ***Use list comprehension to delete a bunch of element from a list.***
#----------------------

ls = [5,6,77,45,22,12,24]
c = [x for x in ls if x % 2 != 0]
print(c)

li = [12,24,35,70,88,120,155]
z = [x for x in li if x % 5 !=0 and x % 7 != 0]
print(z)

li = [12,24,35,70,88,120,155]
li = [x for (i,x) in enumerate(li) if i not in (0,4,5)]
print(li)


list1 = [1,3,6,78,35,55]
list2 = [12,24,35,55,88,120,155]
set1= set(list1)
set2= set(list2)
intersection = set1 & set2
print(intersection)