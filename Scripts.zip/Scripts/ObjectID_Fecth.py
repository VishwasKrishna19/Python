import os
import glob
import codecs
import re
import csv

def getfilelist(path):
    files = glob.glob(os.path.join(path, '*.*'))
    tsf_files = [x for x in files if os.path.splitext(x)[1].lower() == '.cpp']
    return tsf_files

def get_sum_data(file):
    with codecs.open(file, "r", encoding='UTF8', errors='ignore') as tsf_FileName:
        filename = os.path.basename(file)
        filetext = tsf_FileName.read()
    ObjectID = re.findall(r"TSC2[A-Za-z0-9_]+", filetext)
    ObjectID_1 = set(ObjectID)
    ObjectID_Final = list(ObjectID_1)
    #print(ObjectID_Final)
    with open ("TestobjectId.csv", "a") as output:
        for eachid in ObjectID_Final:
            print(f'{filename},{eachid}')
            finaldata = filename + ',' + eachid + '\n'
            output.write(finaldata)
    return [filename, ObjectID_Final]


def write_to_file(ObjectID_Data):
    with open("ObjectIdFetch.csv", 'w', newline='', encoding="utf-8") as ObjectId_details:
        w = csv.writer(ObjectId_details)
        w.writerow(
            ["FileName", "ObjectID"])
        for data in ObjectID_Data:
            #print(data)
            w.writerow(data)

if os.path.exists('ObjectIdFetch.csv'): os.remove('ObjectIdFetch.csv')
# tsf_path = input("Drag and Drop the folder Containing tsf: ")
tsf_path = "C:\\Vishwas\\Task_Assigned\\TSC2_0\\Drop2\\Load_5_5\\Trace\\TSF\\PRD\\TSC2.0\\TEST\\"
tsf_files = getfilelist(tsf_path)
print(tsf_files)
ObjectID_Data = []
for file in tsf_files:
    ObjectID_Data.append(get_sum_data(file))
write_to_file(ObjectID_Data)