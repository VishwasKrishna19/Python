import xml.etree.ElementTree as ET



inputfile = "C:\\Vishwas\\Task_Assigned\\Python\\IDATA\XML_HTML\\reports.XML"

tree = ET.parse(inputfile)
root = tree.getroot()
print(root.tag)
print(root[0][1].text)
for child in root:
    print(child.tag, child.attrib)