#Automate the boring stuff with pthon on openpyxl

import openpyxl
excel_file = "C:\\Vishwas\\Task_Assigned\\Python\\Excel\\Test12.xlsx"

#reading Excel document

wb = openpyxl.load_workbook(excel_file)
ws1 = wb.worksheets[0]
maxrow = ws1.max_row
maxcol = ws1.max_column

for i in range(1, maxrow + 1):
    for j in range(1, maxcol + 1):
        c = ws1.cell(row=i+1, column=3)

        print(c.value)
print(ws1['A1'].value)

