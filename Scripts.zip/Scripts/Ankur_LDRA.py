from bs4 import BeautifulSoup
import urllib.request
import xlwt

wb = xlwt.Workbook()
ws = wb.add_sheet('a test sheet')
with urllib.request.urlopen("C:/Users/h126313/Desktop/Python/Ankur/NGDNIC_LDRA_Code_Review_Report.html") as f:
    html = f.read()
    soup = BeautifulSoup(html)
# print soup.prettify()
# print soup

    table = soup.find("table", id="alignmentTable")

    rows = table.findAll("tr")
    x = 0
    for tr in rows:
        cols = tr.findAll("td")
        if not cols:
            # when we hit an empty row, we should not print anything to the workbook
            continue
        y = 0
        for td in cols:
            texte_bu = td.text
            texte_bu = texte_bu.encode('utf-8')
            texte_bu = texte_bu.strip()
            ws.write(x, y, td.text)
            print(x, y, td.text)
            y = y + 1
    # update the row pointer AFTER a row has been printed
    # this avoids the blank row at the top of your table
        x = x + 1

    wb.save('C:/Users/h126313/Desktop/Python/Ankur/BlastResults.xls')