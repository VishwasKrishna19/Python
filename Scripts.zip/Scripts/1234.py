import re
str = " \" TgfDspFMS  \""
IDBCheck = str.split('"')[1]
IDBCheck = IDBCheck.split('"')[0]
print(f'test- {len(IDBCheck)}')
if len(IDBCheck.strip()) != 0 and ('idb' in IDBCheck or 'IDB' in IDBCheck):
    IDBName = re.findall(r'[\w-]+\.IDB|idb', str, re.IGNORECASE)[0]
else:
    IDBName = ""
print(f' IDBNAME = {IDBName}')
