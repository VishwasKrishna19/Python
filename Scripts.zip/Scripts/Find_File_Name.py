import os
import sys
import csv
import codecs
import time
import re


sumread = input("Drag and Drop the folder Containing summary files: ")
os.getcwd()
if os.path.exists('Sum_Trace.csv'): os.remove('Sum_Trace.csv')
with open("Sum_Trace.csv", 'a', newline='', encoding="utf-8") as traceout:
    w = csv.writer(traceout)
    w.writerow(
        ["ObjectId", "Filename"])
    for root, dirs, files in os.walk(sumread):
        for file in files:
            if file.endswith(".sum"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as summary:
                    for line in summary:
                        regexdata = re.search(r'TSC((_2)|(2))[A-Z_]+[0-9]+', line)
                        print(regexdata)
                        filename = summary.name
                        filename = filename.split('\\')[-1]
                        #for regexdata1 in regexdata:
                        #    print(str(regexdata1))
                        #    traceout.write(str(regexdata1) + ',' + filename + '\n')


