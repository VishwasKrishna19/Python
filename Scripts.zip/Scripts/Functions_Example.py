def twovalues(a, b):
    return a+b

print(twovalues(4, 9))


##Even or Odd
def EvenOdd(num):
    if num%2 == 0:
        print(num, "is Even Number")
    else:
        print(num, "is Odd Number")

EvenOdd(5)

##Calculate the Factorial value

def factorial(n):
    prod = 1
    while n>=1:
        prod = prod*n
        n = n -1
    return prod

for i in range(1,12):
    print("Factorial of {} is {}".format(i, factorial(i)))
#factorial(5)

print('*************************************************')

#python function to check given number is Prime or Not

def prime_not_prime(num):
    x = 1
    #print(n, x)
    for i in range(2, n):
        #print(n, x)
        if n%i == 0:
            x = 0
        else:
            x = 1
    #print(n, x)
    return x

n = 4
result = prime_not_prime(n)

if result == 1:
    print (n, 'is prime')
else:
    print(n, 'is not a prime')

print('*************************************************')

# python function to Generate Prime Numbers

def generate_Prime(num):
    x = 1
    for i in range(2, n):
        if n%i == 0:
            x = 0
            break
        else:
            x = 1
    return x

#result = generate_Prime(n)
i = 2
c = 1
num = 10
while True:
    if generate_Prime(i):
        print(i)
        c +=1
    i +=1
    if c>num:
        break
