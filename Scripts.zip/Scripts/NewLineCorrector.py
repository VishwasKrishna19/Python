import os
import sys

# Python version 3.6.1

argList = ""
# Get the command line arguements
for arg in sys.argv:
    argList = argList + "," + arg
# end for

# Split the command line arguements into an array
argListArray = argList.split(',')

# Process if correct number of command line arguements are provided
if len(argListArray) != 2:
    print("** Error: One Input Arguement is Expected.. **")
    sys.exit()
# end if

# Enter TR Text Files directory path
testPath = input("Enter the test File name with file path: ")

# Process if the path is provided
if testPath == "":
    print("** Error: No input provided **")
    sys.exit()
# end if

# Check if the path exists
if not os.path.exists(testPath):
    print("** Error Path '" + testPath + "' does not exist **")
    sys.exit()
# end if

def readFile(path):
    strFilePath = path[:path.rfind("\\")]
    strFileName = path[path.rfind("\\"):path.rfind(".")]
    objTestFileRead = open(path, "r", errors='ignore')
    objTstFileWrite = open(strFilePath + strFileName + "_updated.tsf", "w", newline="\r\n")

    for  line in objTestFileRead:
        objTstFileWrite.write(line)

    objTstFileWrite.close()
    objTestFileRead.close()

readFile(testPath)