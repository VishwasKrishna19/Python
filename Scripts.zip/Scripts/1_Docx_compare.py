#comments
#Install below packages in command prompt
# pip install pywin32
# pip install pypiwin32
import win32com.client
import os,sys
# path = "C:\ThePath\OfYourFolder\WithYourDocuments\\"
print("Check path information in path1, path2, output path in the script)

path1 = "C:\\Vishwas\\TASKS_ASSIGNED\\Python\\Word_Compare\\old_Others.docx\\"
path2 = "C:\\Vishwas\\TASKS_ASSIGNED\\Python\\Word_Compare\\Latest_Others.docx\\" 
outputpath = "C:\\Vishwas\\TASKS_ASSIGNED\\Python\\Word_Compare\\" 
# note the \\ at the end of the path name to prevent a SyntaxError

def compare_func(filename):
    #Create the Application word
    Application=win32com.client.gencache.EnsureDispatch("Word.Application")
    # Compare documents
    # Application.CompareDocuments(Application.Documents.Open(path + "Original.docx"),
                             # Application.Documents.Open(path + "Revised.docx"))

    Application.CompareDocuments(Application.Documents.Open(path1 + filename),
                             Application.Documents.Open(path2 + filename))
    
    output_file_name = filename+"Comparision.doc"
    # Save the comparison document as "Comparison.docx"
    Application.ActiveDocument.SaveAs (FileName = outputpath + output_file_name)

    print(filename+" Read complete")
    # Don't forget to quit your Application
    Application.Quit()

def main():
    #inside main
    for filename in os.listdir(path2):
      if(".docx" in filename):
        compare_func(filename)

main()
print("Doc compare completed")
