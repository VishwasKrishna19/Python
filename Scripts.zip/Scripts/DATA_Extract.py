import csv
import os
import re

with open('C:/Vishwas/TASKS_ASSIGNED/Verification_Deliverables/CD_MEDIA/TSC/DVD1/Verification_Deliverables/TSC/file.txt') as f:
    with open('C:/Vishwas/TASKS_ASSIGNED/Verification_Deliverables/CD_MEDIA/TSC/DVD1/Verification_Deliverables/TSC/output1.txt','w', newline='') as wf:
        for line in f:
            if '.metadata-dir' not in line and '.metadata-item' not in line and '.metadata-config' not in line and '.' in line:
                line2 = line.split('/')[-1]
                wf.write(str(line2))