import pandas as pd
import openpyxl
import xlrd

Actual_data = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\Actual1.xlsx'
Template_xls = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\ASTC1217.xlsx'
temp_xls = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\Temp.xls'

df = pd.read_excel(Template_xls)
xlsdata = openpyxl.load_workbook(Template_xls)
readsheet = xlsdata['Sheet1']

templist = df.columns.values.tolist()
templist = [x.upper() for x in templist]
templist_index = dict()


for col in range(1, readsheet.max_column + 1):
    if readsheet.cell(row = 16, column=col).value != None:
        if readsheet.cell(row=16, column=col).value.strip().upper().replace('_SRD', "") in templist:
            templist_index[readsheet.cell(row=16, column=col).value.strip().upper().replace('_SRD', "")] = col

readsheet.insert_rows(5)
xlsdata.save(Template_xls)
#print(templist)
#print(templist_index)
#print(df['FAULT_RESET'])




