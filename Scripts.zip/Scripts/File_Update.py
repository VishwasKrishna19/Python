import os
import sys
import fileinput
import re

with open("C:/Users/h126313/Desktop/Python/TDA/Out0_orig.txt") as input:
    with open("C:/Users/h126313/Desktop/Python/TDA/result.txt", "w") as Output:
        line_count = 0
        list_count = 0
        parsing = False
        for line in input:
            if line.__contains__('\'Statements'):
                parsing = False
            if line.startswith('\'Keys:'):
                parsing = True
            if parsing:
                if(line.__contains__('-') and '---' not in line):
                    line1 = line.split('-')[0]
                    line1 = line1.split('\'')[1]
                    line2 = line.split('-')[1]
                    line_count += 1
                    line1 = line1.replace(line1, '\'V_'+ str(line_count))
                    line = line1 + ' - ' + line2
                    #print(line)
            if line.__contains__('\'Test No.'):
                startstring = '\'Test No.'
                endstring = 'O/P'
                line3 = (line.split(startstring))[1].split(endstring)[0]
                line3 = line3.split(" ")
                while '' in line3:
                    line3.remove('')
                #print(line3)
                list_len = len(line3)
                #print(list_len)
                #line3 = "".join()
                #line4 = len(line3.replace(" ", ""))
                #print(line4)
                #print(len(line3))
                #print(line_count)
                list_count = 0
                for n,i in enumerate(line3):
                    list_count += 1
                    line3[n] = 'V_' + str(list_count)
                    #line3 = " ".join(line3)
                print(line3)
            Output.write(line)
