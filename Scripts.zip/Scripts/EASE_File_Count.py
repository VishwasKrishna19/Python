import os
import csv
import codecs
import time

if os.path.exists('output_EASE.csv'): os.remove('output_EASE.csv')
tsf_path = input("Drag and Drop the folder Containing Summaries: ")
os.getcwd()
with open("output_EASE.csv", 'w', newline='', encoding="utf-8") as tbi_count:
    w = csv.writer(tbi_count)
    w.writerow(["FileName", "Machine_Name"])
    for root, dirs, files in os.walk(tsf_path):
        for file in files:
            if file.endswith(".sum") or file.endswith(".SUM") or file.endswith(".Sum"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as Sum_FileName:
                    for line in Sum_FileName:
                        MachineName= ""
                        if line.__contains__('Test Station being used is'):
                            MachineName = line.split(':')[1]
                            MachineName = MachineName.rstrip('\n')
                            if MachineName.startswith('['):
                                MachineName = MachineName.split('[')[1]
                                MachineName = MachineName.split(']')[0]
                                MachineName = MachineName.strip()
                            filename = Sum_FileName.name
                            filename = filename.split('\\')[-1]
                            print(filename + ',' + str(MachineName))
                            Name = filename + ',' + str(MachineName) + '\n'
                            tbi_count.write(Name)

print('All file Extraction Completed')
time.sleep(2)
exit(0)