import os
import codecs

inputfolderpath = 'C:\\TSC2.0\\TEST\\Scripts\\TSC2.0\\TEST'
print(inputfolderpath)
with open('C:\\TSC2.0\\TEST\\Scripts\\TSC2.0\\tracedata.txt', 'w') as tracedata:
    for root, dirs, files in os.walk(inputfolderpath):
        for file in files:
            if file.endswith(".tsf") or file.endswith(".cpp"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as tsf:
                    for line in tsf:
                        if line.__contains__('[TP_'):
                            requirement_Id = line.split("::")[2]
                            requirement_Id = requirement_Id.split("]")[0]
                            tsfname = tsf.name
                            tsfname = tsfname.split("\\")[-1]
                            tracedata.write(tsfname + ',' + requirement_Id + '\n')
                            #k = tsfname
                            #v = requirement_Id
                            #dict = {k : v}
                                #dict[tsfname] = requirement_Id
                                #dict.update({tsfname:requirement_Id})
                                #dictionary.write(str(dict))
dict = {}
with open('C:\\TSC2.0\\TEST\\Scripts\\TSC2.0\\tracedata.txt', 'r') as dictdata:
    with open('C:\\TSC2.0\\TEST\\Scripts\\TSC2.0\\dict.txt', 'w') as dictdata1:
        dict((line.strip().split(',') for line in file(dictdata)))
        #for linedata in dictdata:
        #    linedata = linedata.split(",")
        #    linedata = linedata.strip()
        #    tsfname = linedata[0]
        #    req_id = linedata[1]
        #    dict[tsfname] = req_id
        dictdata1.write(str(dict))
