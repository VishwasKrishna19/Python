print(float(5)) #object is integer. Returns 5.0
print(float('5')) #object is string. Returns 5.0
print(float(5.4)) #object is already float. Returns 5.4
print(float('5.4')) #object is string. Returns 5.4
print(float('-5.99')) #object is string. Returns -5.99
print(float(-5.99)) #object is float. Returns -5.99