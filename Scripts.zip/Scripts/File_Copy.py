import os
from pathlib import Path
from shutil import copyfile
import shutil

for root, dirs, files in os.walk('C:/48816/48816_Cpp/deliver/Qualification_Test_Suite/work-area_Ease/actual'):
	for dat in files:
         if dat.__contains__("TESTINSS.DAT"):
           srcfilepath = os.path.join(str(root), dat)
           dstfilepath = srcfilepath.split("TESTINSS.DAT")[0]
           dstfilepath = dstfilepath + "compile" + "//"
           dstfilepath = dstfilepath + "TESTINSS.dat"
           #print(srcfilepath)
           #shutil.copyfile(srcfilepath, dstfilepath)
           if 'TESTINSS.DAT' not in dirs:
               print(dstfilepath)



