import xml.etree.cElementTree as ET

def indent(elem, level=0):
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


Testfile1 = ET.Element("Testfile1")
Header = ET.SubElement(Testfile1,"Header")
Header = ET.SubElement(Header, "Test Module name")
Header = ET.SubElement(Header, "Test Case name ")
Header = ET.SubElement(Header, "DOORS BASELINE VersionS")
Header = ET.SubElement(Header, "TEST CASE ")
TESTCASEID= ET.SubElement(Testfile1,"TESTCASE ID")



Change_Descr="Test_VHF_Subnetwork"
DOORS_BASELINE_VersionS="0.81"
TEST_CASE="VHF Subnetwork Link Manager will fail to change the VHF_Link_Status to NoComm"
ID_NUM="1"
Function_name="create_result_file"
Parameter="Test_ATC_DL_ITP_LEVEL_REQUEST_1_4_8 " + ',' + "123"


ET.SubElement(Header, "Test Module name").text = Change_Descr
ET.SubElement(Header, "DOORS BASELINE VersionS").text = DOORS_BASELINE_VersionS
ET.SubElement(Header, "TEST CASE").text = TEST_CASE
ET.SubElement(TESTCASEID ,"TESTCASE ID").text = ID_NUM
ET.SubElement(TESTCASEID ,"ACTION ID").text = ID_NUM
ET.SubElement(TESTCASEID ,"Function").text = Function_name
ET.SubElement(TESTCASEID ,"Parameter").text = Parameter




tree = ET.ElementTree(Testfile1)

indent(Testfile1)

# writing xml
tree.write("filename.xml",xml_declaration=True )

