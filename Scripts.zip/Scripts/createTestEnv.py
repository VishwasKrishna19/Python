import string
import os
import sys
import re
import shutil

fileListName = "FileList.txt"
fileList = open(fileListName,"r")


while True:
	fileLine = fileList.readline()
	lineLength = len(fileLine)
	if fileLine == '':
		break
	else:
		tsfFileNameWithExt = fileLine[0:17]
		tsfFileNameWithoutExt = fileLine[0:13]
		
		if(os.path.exists(tsfFileNameWithoutExt)!=True):
			os.mkdir(tsfFileNameWithoutExt)

		if(os.path.exists("/"+tsfFileNameWithoutExt+"/"+tsfFileNameWithExt)!=True):
			shutil.copyfile("C:/TSC2.0/TEST/"+tsfFileNameWithExt,tsfFileNameWithoutExt+"/"+tsfFileNameWithExt)
		
		tsfFile = open(tsfFileNameWithoutExt+"/"+tsfFileNameWithExt,"r")
		tspFile = open(tsfFileNameWithoutExt+"/"+tsfFileNameWithoutExt+".tsp","w")
		configFile = open(tsfFileNameWithoutExt+"/"+"Config_file.txt","w")
		
		tspFile.write("1.0")
		while True:
			tsfLine = tsfFile.readline()
			
			if ("DEFINE " in tsfLine):
				break
			else:
				if(".tsf" in tsfLine):
					tsfLine.lstrip()
					re.sub('[^a-zA-Z-_*.]', '', tsfLine)
					tsfLine.lstrip()
					tsfWord = tsfLine.split('.')
					tspFile.write("\n")
					if(tsfFileNameWithoutExt in tsfWord[1]):
						tspFile.write("\""+tsfWord[1]+".tsf\"")
					else:
						tspFile.write("\"..\\Support_files\\"+tsfWord[1]+".tsf\"")
					if ("QualifiedSupport" in tsfWord[1]):						
						tspFile.write("\n0, 1, 0")
					else:
						tspFile.write("\n0, 0, 0")
			
		configFile.writelines("<Config>\n<g__thisInstance_check>2</g__thisInstance_check>\n<TestEnvironment>10</TestEnvironment>\n")
		configFile.writelines("<EASE_WARM>1</EASE_WARM>\n<Software_Version>EDS_GGF_EJETE2_00_009</Software_Version>\n")
		configFile.writelines("<ExecutorName>R, Jyothi</ExecutorName>\n<ObjectID_ExeFull>1</ObjectID_ExeFull>\n<Selected_ObjectIDs>")
		configFile.write(fileLine[18:lineLength])
		configFile.writelines("</Selected_ObjectIDs>\n<AUTOGIT_VERIFYDISPLAYRANGE_IMAGE>1</AUTOGIT_VERIFYDISPLAYRANGE_IMAGE>\n</Config>")

		tsfFile.close()
		tspFile.close()
		configFile.close()
		
fileList.close()



#Updated_path = "C:/EASE_OEM/GVII_733_12_DG/TSG_S22B_0007.tsf"
#Sum_path = "Report.txt"
#New = Updated_path.split('/',15)
#New1 = New[-1]
#New2 = New1.split('.')
#Filename = New2[0]
##Open Ease File
#Ease = open(Updated_path,"r")
#fd = open(Sum_path,"w")
#tsf_line = Ease.readline()
#Image_no = 0
#str1 = "CompareShallTag"
#str3 = "ReportSummary"
#str2 = "PassFail"
#str4 = "Passfail"
#tc=0
#EndFunc = False
#User_input = len(sys.argv)
#
#tsf_line = tsf_line.strip()
#while tsf_line != 'ReportSummary':
#  Exit_file = 1
#  shall_tag = 0
#  shall_tag = tsf_line.find(str1)
#  if (shall_tag > 0):
#     EndFunc = False
#     Image_no = 0
#     temp = tsf_line.split("(")
#     temp2 = temp[1]
#     temp3 = temp2.split(")")
#     Each_shalltag = int(temp3[0])
#    
#     #fd.write(temp3[0])
#     while EndFunc != True:
#       shall_tag2 = tsf_line.find(str2)
#       if shall_tag2 == 0:
#          if User_input > 1:
#             i=1
#             user_arg = User_input - 1
#             while(user_arg):
#               required_shalltag = int(sys.argv[i])
#               if (Each_shalltag == required_shalltag):
#                   Image_no = Image_no + 1
#                   fd.write(Filename + "_" + temp3[0] + "_" + "IMG" + '%d' % Image_no )
#                   fd.write("\n")
#               i= i+1
#               user_arg = user_arg - 1
#          else:
#               Image_no = Image_no + 1
#               fd.write(Filename + "_" + temp3[0] + "_" + "IMG" + '%d' % Image_no )
#               fd.write("\n")   
#       shall_tag3 = tsf_line.find(str4)
#       if shall_tag3 == 0:
#          if User_input > 1:
#             i=1
#             user_arg = User_input - 1
#             while(user_arg):
#               required_shalltag = int(sys.argv[i])
#               if (Each_shalltag == required_shalltag):
#                   Image_no = Image_no + 1
#                   fd.write(Filename + "_" + temp3[0] + "_" + "IMG" + '%d' % Image_no )
#                   fd.write("\n")
#               i= i+1
#               user_arg = user_arg - 1
#          else:
#               Image_no = Image_no + 1
#               fd.write(Filename + "_" + temp3[0] + "_" + "IMG" + '%d' % Image_no )
#               fd.write("\n")
#       tsf_line = Ease.readline()
#       tsf_line = tsf_line.strip()
#       shall_tag = 0
#       shall_tag = tsf_line.find(str1)
#       if (shall_tag > 0):
#         EndFunc = True
#       Exit_file = 1
#       Exit_file = tsf_line.find(str3)
#       if (Exit_file ==0):
#         EndFunc = True
#     #fd.write("\n")
#  else:
#   tsf_line = Ease.readline()
#   tsf_line = tsf_line.strip()
#Ease.close()
#fd.close()
#