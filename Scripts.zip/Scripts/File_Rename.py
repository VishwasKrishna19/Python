import os

#os.chdir('D:\\Vishwas\\Python\\Test_Folder\\Rename')
os.chdir(f'D:\Vishwas\Python\Test_Folder\Rename')
print(os.getcwd())

count = 0
for filename in os.listdir():
    #print(filename)
    count += 1
    f_name, f_ext = os.path.splitext(filename)
    f_ext = ".txt"
    f_name = f_name.split("_")[0]
    print('{}{}'.format(count, f_ext))
    newname = '{}{}'.format(count, f_ext)
    os.rename(filename, newname)
