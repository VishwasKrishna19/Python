import pyodbc

def ascbmapping(server,database,mappingpath):
    driver = '{SQL Server}' # Driver you need to connect to the database

    cnn = pyodbc.connect('DRIVER='+driver+';SERVER='+server+';DATABASE='+database+';Trusted_Connection=yes;')

    dataCursor = cnn.cursor()

    droptable_sql = """
    IF OBJECT_ID('Variables', 'U') IS NOT NULL 
      DROP TABLE Variables; 
    """

    dataCursor.execute(droptable_sql)

    createTable_sql = """
    CREATE TABLE Variables
    (  
        Parameter nvarchar (500)
        ,ASCBPath nvarchar (500)
        ,Description nvarchar (500)  
        ,Datatype nvarchar (500)
        ,MinScale float
        ,MaxScale float
        ,Resolution float
        ,StartingBit int
        ,DefaultTestValue nvarchar (32)
        ,EnumSet nvarchar(500)
        ,RangeofArray nvarchar(500)     
    ); 
    """

    dataCursor.execute(createTable_sql)

    cnn.commit()

    insertRow_sql = """
    INSERT INTO Variables(Parameter, ASCBPath, Description, Datatype, MinScale, MaxScale, Resolution, StartingBit, DefaultTestValue, EnumSet, RangeofArray) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    selectmain_sql = """
    SELECT TOP (1) [id]
          ,[Description]
          ,[Datatype_id]
          ,[MinScale]
          ,[MaxScale]
          ,[Resolution]
          ,[StartingBit]
          ,[DefaultTestValue]
      FROM [Parameter]
      WHERE [Name] = ? or [Name] = CONCAT([id], ?) and Function_id = ?
    """

    selectfunction_sql = """
    SELECT [id] FROM [Function] WHERE [Name] = ?
    """

    selectdatatype_sql = """
    SELECT [Name] FROM [Datatype] WHERE [id] = ?
    """

    selectenumset_sql = """
    SELECT * FROM [EnumState] WHERE [Datatype_id] = ?
    """

    with open(mappingpath, 'r') as file :
        filedata = file.readlines()

    linenumber = 0
    loopstarted = 0
    loops = 0

    for line in filedata:
        line = line.lstrip()
        line = line.rstrip()
        if line.startswith('For ') and line.__contains__('=') & loopstarted == 0:
            loopstarted = 1
            line = line.split(' ', 1)[1]
            Array = [line.strip()]
            iden = line.partition("To")[0].strip()
            identifier = [iden.partition("=")[0].strip()]
            count = linenumber + 1
            fline = filedata[count].strip()
            while True:
                if fline.startswith('For '):
                    fline = fline.split(' ', 1)[1]
                    Array.append(fline.strip())
                    fiden = fline.partition("To")[0].strip()
                    identifier.append(fiden.partition("=")[0].strip())
                    loopstarted += 1
                elif fline == "Next" and loopstarted == 1:
                    break
                elif fline == "Next":
                    loopstarted -= 1
                elif fline != "" and fline.__contains__('ASCB D'):
                    ParameterName = fline.partition("=")[0].strip()
                    ASCBpath = fline.partition("=")[2]
                    ASCBpath = ASCBpath.strip()
                    paramarg = ParameterName.partition("(")[2]
                    paramarg = paramarg.strip(")")
                    paramarg = paramarg.split(",")
                    paramarg = [item.strip() for item in paramarg]
                    argcount = 0
                    ArrayRange = ""
                    while argcount < len(paramarg):
                        index = identifier.index(paramarg[argcount])
                        ArrayRange = ArrayRange + Array[index]
                        argcount += 1
                        if argcount == len(paramarg):
                            continue
                        else:
                            ArrayRange = ArrayRange + ", "
                    dataCursor.execute(insertRow_sql, ParameterName, ASCBpath, "", "", "",
                                           "", "", "", "", "", ArrayRange)
                count += 1
                fline = filedata[count].strip()
            loops = count
        elif line.__contains__('ASCB D') and line.__contains__('=') and loopstarted == 0 and line.startswith('\'') == False:
            if line.startswith('Dim') and line.__contains__(':'):
                line = line.split(' ', 1)[1]
                ParameterName = line.partition(":")[0]
                ParameterName = ParameterName.lstrip()
                ParameterName = ParameterName.rstrip()
            else:
                ParameterName = line.partition("=")[0]
                ParameterName = ParameterName.strip()
            line = line.partition("ASCB D\\")[2]
            ASCBpath = line.partition("\"")[0]
            ASCBpath = "ASCB D\\" + ASCBpath
            Function = line.partition("\\")[0]
            line = line.partition("\"")[0]
            Parameter = line.rpartition("\\")[2]
            if Parameter == " Parameter Group Status":
                templine = line.rpartition("\\")[0]
                Parameter = templine.rpartition("\\")[2]
            Parameter = Parameter.split(' ', 1)[0]
            tempf = dataCursor.execute(selectfunction_sql, Function)
            Function = tempf.fetchone()
            if Function != None:
                output = dataCursor.execute(selectmain_sql, Parameter, Parameter, Function[0])
                output = output.fetchone()
                if output !=  None:
                    Datatype_id = output[2]
                    Description = output[1]
                    Minscale = output[3]
                    Maxscale = output[4]
                    Resolution = output[5]
                    StartingBit = output[6]
                    DefaultTestValue = output[7]
                    dtid = dataCursor.execute(selectdatatype_sql,Datatype_id)
                    dtid = dtid.fetchone()
                    Datatype = dtid[0]
                    es = dataCursor.execute(selectenumset_sql,Datatype_id)
                    es = es.fetchall()
                    EnumSet = ""
                    if len(es) > 0:
                        count = 0
                        while count < len(es):
                            EnumSet = EnumSet + str(es[count][1]) + " - " + str(es[count][2]) + ", "
                            count += 1
                    dataCursor.execute(insertRow_sql, ParameterName, ASCBpath, Description, Datatype, Minscale, Maxscale, Resolution, StartingBit, DefaultTestValue, EnumSet, "")
                else:
                    print("Parameter not found in DB: " + ParameterName)
            else:
                print("Functionality not found in DB: " + ParameterName)
        elif linenumber == loops:
            loopstarted = 0
        linenumber += 1
    cnn.commit()