input = "C:\\Vishwas\\Task_Assigned\\Python\\TIO\\Test.txt"
output = "C:\\Vishwas\\Task_Assigned\\Python\\TIO\\Test_Updated.txt"

ipfile = open(input, 'r')
opfile = open(output, 'w')
count = 50
for line in ipfile:
    if 'tio.OutputResult ("' in line:
        count += 1
        line1 = 'tio.OutputResult ("Test Step : c' + str(count) + '");'
        line = line.replace(line, line1)
    print(line)
    opfile.write(line)

opfile.close()