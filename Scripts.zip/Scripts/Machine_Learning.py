#Machine Learning
# 1. Import the Data
# 2. Clean the Data
# 3. Split the Data, Training set and Test Set
# 4. Create a Model (Import a Algorithm usually import sometimes develop a New)
# 5. Check the Output
# 6. Improve the Dataset and Training set

import pandas as pd
import seaborn as sns
def value_to_float(x):
    if type(x) == float or type(x) == int:
        return x
    if 'K' in x:
        if len(x) > 1:
            return float(x.replace('K', '')) * 1000
        return 1000.0
    if 'M' in x:
        if len(x) > 1:
            return float(x.replace('M', '')) * 1000000
        return 1000000.0
    if 'B' in x:
        return float(x.replace('B', '')) * 1000000000
    return 0.0

data_frame = pd.read_csv("C:\\Vishwas\\Python\\fifa19\\data.csv")
print(data_frame.shape[0])
# print(data_frame.describe())
# print(data_frame.values)
testframe = data_frame[data_frame['Age'] > 30].head(data_frame.shape[1])
testframe = data_frame['Age'] > 30
testframe = data_frame.max()
testframe = data_frame[data_frame['Age']>30]
testframe = testframe['Age']

df1 = pd.DataFrame(data_frame, columns=['Name', 'Wage', 'Value'])  #To Create the New Data Frame

wage = df1['Wage'].replace('[\€]', '', regex=True).apply(value_to_float)
value = df1['Value'].replace('[\€]', '', regex=True).apply(value_to_float)
df1['Wage'] = wage
df1['Value'] = value
df1['difference'] = df1['Value'] - df1['Wage']
df1.sort_values('difference', ascending=True)

df1.to_csv("Testdata.csv")

sns.set()
graph = sns.scatterplot(x  = 'Wage', y = 'Value', data = df1)
print(graph)