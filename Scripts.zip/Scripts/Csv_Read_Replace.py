import os
import sys
import fileinput
import csv

with open("C:/Users/h126313/Desktop/NG/Reuse_Test_Generation2.csv", "r") as f:
    with open("C:/Users/h126313/Desktop/NG/find.txt", "w") as wf:
        with open("C:/Users/h126313/Desktop/NG/replace.txt", "w") as wf1:
            for csvline in f:
                csvline = csvline.rstrip('\n')
                csvline1 = csvline.split(",")[0]
                wf.write(csvline1 + '\n')
                csvline_Replace = csvline.split(",")[1]
                wf1.write(csvline_Replace + '\n')


findlines = open('C:/Users/h126313/Desktop/NG/find.txt').read().split('\n')
replacelines = open('C:/Users/h126313/Desktop/NG/replace.txt').read().split('\n')
find_replace = dict(zip(findlines, replacelines))

with open('C:/Users/h126313/Desktop/NG/A3G_MAPC_0001.tsf') as oldtsf:
    with open('C:/Users/h126313/Desktop/NG/A3G_MAPC_0001_Updated.tsf', 'w') as newtsf:
        for line in oldtsf:
            for key in find_replace:
                if key in line:
                    line = line.replace(key, find_replace[key])
            newtsf.write(line)

