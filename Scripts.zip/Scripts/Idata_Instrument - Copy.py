import subprocess
import codecs
import os, re
from chardet import detect

srcpath = "C:\\Vishwas\\Task_Assigned\\Initiatives\\IDATA\\tgf\\"
dstpath = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\IDATA\\Instru\\'
command = 'start ' + "robocopy " + srcpath + " " + dstpath + " /E *.IDW_XML *.IDT_XML *.hit *.lwt_xml *.col_xml *.grd_xml"
print(command)
p = subprocess.Popen(command, stdout=subprocess.PIPE, shell = True)
p.communicate()

# get file encoding type
def get_encoding_type(file):
    with open(file, 'rb') as f:
        rawdata = f.read()
    return detect(rawdata)['encoding']

dict = {}
for root, dirs, files in os.walk(srcpath):
    for file in files:
        destination_folder = dstpath + root.split('\\')[-1] + "\\" + file
        if file.endswith(".IDL_XML") or file.endswith(".idl_xml"):
            from_codec = get_encoding_type(os.path.join(root, file))
            if (from_codec != 'UTF-8'):
                with codecs.open(os.path.join(root, file), 'r', encoding=from_codec) as f:
                    filedata = f.read()
                    tagcount = filedata.count("elementtag=\"")
                    print(file + " , " +  str(tagcount))
                    dict[file] = str(tagcount)
print(dict)


def get_value(key_val):
    for key, value in dict.items():
        if key_val == key:
            return value

    return "Value doesn't exist"


for root, dirs, files in os.walk(srcpath):
    for file in files:
        count = 0
        destination_folder = dstpath + root.split('\\')[-1] + "\\" + file
        #print(destination_folder)
        if file.endswith(".IDL_XML") or file.endswith(".idl_xml"):
            from_codec = get_encoding_type(os.path.join(root, file))
            if (from_codec != 'UTF-8'):
                with codecs.open(os.path.join(root, file), 'r', encoding=from_codec) as f:
                    with codecs.open(destination_folder, 'w', encoding=from_codec) as fw:
                    #print(f.name)
                        for eachxmlline in f:
                            if 'elementtag="' in eachxmlline:
                                pattren = re.search(r'elementtag="(\d+)"', eachxmlline)
                                element_tag = "elementtag=\"" + str(count) + "\""
                                eachxmlline = eachxmlline.replace(pattren.group(), element_tag)
                                count += 1
                            if 'externalgroup name=\"' in eachxmlline and 'filename=\"' in eachxmlline:
                                newxmlsearch = re.findall(r'[ \w-]+\.IDL_XML', eachxmlline, re.IGNORECASE)[0]
                                elementtag_incr = get_value(newxmlsearch)
                                count =  count + int(elementtag_incr)
                                print(f'{newxmlsearch}- {elementtag_incr}')
                            fw.write(eachxmlline)
