#|--------------------------------------------------------------------
#| This work contains information that is the property of
#| Honeywell International Inc. Except for rights expressly 
#| granted by contract to the United States government, this 
#| work may not, in whole or in part, be duplicated, disclosed 
#| or used for design or manufacturing purposes without prior 
#| written permission of Honeywell International Inc.
#|
#*********************************************************************
#|                   PROGRAM:  ICPCS: 777 CPOV 
#*********************************************************************
#|
#| Company Name: Honeywell International
#| 11100 N. Oracle Road
#| Tucson, AZ
#| Claims/Conditions: Copyright 2002-03
#| Honeywell Confidential & Proprietary
#|
#| FILE: MSTP55.INT
#|
#|
#| Tests the MCP_MAN_DIN_RAW bit. 
#|
#| Reqmts tested include: MSSRS135, MSSDD107, MSSRS338, MSSDD128
#|
#| Refer to test case MSTC43.
#|--------------------------------------------------------------------

import Test_harness_777 as TH

def Test():

  TH.SetupNGC()
  TH.SetupARINC()

 


#+-----------------------------------------------------------------------------
#| Reqmt MSSRS135, MSSDD107 - Discrete Inputs Acquisition
#| Reqmt MSSRS338, MSSDD128 - Discrete_Inputs1_Raw
#+-----------------------------------------------------------------------------

  print ";+-------------------------------------------------------------------"
  print ";| PROGRAM:  ICPCS: 777 CPOV                                      "
  print ";+-------------------------------------------------------------------"
  print "Reqmt Tested: MSSRS135, MSSDD107, MSSRS338, MSSDD128"
  
  #+---------------------------------------------------------------------------
  #+ Verify MCP_MAN_DIN_RAW is set FALSE, Bit 0 / DISCRETE_INPUTS1_RAW
  #+---------------------------------------------------------------------------
  
  print "Switch to AUTO mode on the test panel"
  print "and press (Y) on MS."
  
  while (raw_input("") != 1):
    TH.Pause (0.1)


  print "TESTCASE 01:"
  print "Switch to AUTO mode"
  print "Test for"
  print "         MCP_MAN_DIN_RAW = FALSE"

  print "Test Results:"
  
  TH.VerifyTol(MCP_MAN_DIN_RAW,0,0,"MCP_MAN_DIN_RAW")
  TH.VerifyTol(andDISCRETE_INPUTS1_RAW,0h,1h,"andDISCRETE_INPUTS1_RAW")

  #+---------------------------------------------------------------------------
  #+ Verify MCP_MAN_DIN_RAW is set TRUE, Bit 0 / DISCRETE_INPUTS1_RAW
  #+---------------------------------------------------------------------------

  print "Switch to MANUAL mode on the test panel"
  print "and press (Y) on MS."
  
  while (raw_input("") != 1):
    TH.Pause (0.1)


  print "TESTCASE 02:"
  print "Switch to MANUAL mode"
  print "Test for"
  print "         MCP_MAN_DIN_RAW = TRUE"

  print "Test Results:"
  
  TH.VerifyTol(MCP_MAN_DIN_RAW,1,0,"MCP_MAN_DIN_RAW")
  TH.VerifyTol(andDISCRETE_INPUTS1_RAW,1h,1h,"andDISCRETE_INPUTS1_RAW")
  
  #+---------------------------------------------------------------------------
  #+ Testing Completed.
  #+---------------------------------------------------------------------------  
  
  print "Testing Completed."  

  TH.Pause(3)


  print "---------------- End Test -------------------"

  # 
  # 
  print "MSTP55.LOG"



def RunTest():
  Test()

if __name__ == '__main__':
  TH.RunTest(RunTest, "MSTP55.log","Verify the values are set as per requirements.",True,True)
