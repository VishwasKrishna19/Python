import os
import sys
import re
import csv

with open("C:/Vishwas/TASKS_ASSIGNED/Python/Idata/Test/Exception_Sheet.csv", "r") as csv_Read_file:
    with open("C:/Vishwas/TASKS_ASSIGNED/Python/Idata/Test/3_IN_TRACE.txt", "r")as trace:
        with open("C:/Vishwas/TASKS_ASSIGNED/Python/Idata/Test/Output.txt", "w")as output:
            csv_Read_file = csv_Read_file.readlines()
            line2 = trace.readlines()
            for lines in csv_Read_file:
                group_name = lines.split(",")[-1]
                group_name = group_name.rstrip()
                group_name = group_name.lstrip()
                #print(group_name)
                for tracelines in line2:
                    if tracelines.__contains__(group_name):
                        tracematch = tracelines.split(group_name)[1]
                        print(tracematch)
