#Generators

#allows us to generate the sequence of Values

def make_list(num):
    result = []
    for i in range(num):
        result.append(i*2)
    return result

my_list = make_list(100)
print(my_list)

def generator_function(num):
    for i in range(num):
        yield i*2

g = generator_function(100)
next(g)
next(g)
print(next(g))

print("**************************")

class Mygen():
    current = 0
    def __init__(self, first, last):
        self.first = first
        self.last = last

    def __iter__(self):
        return self

    def __next__(self):
        if Mygen.current < self.last:
            num = Mygen.current
            Mygen.current += 1
            return num
        raise StopIteration

gen = Mygen(0, 100)
for i in gen:
    print(i)

print('////////////////////////////')
#Fibonacci nUmber

#0 1 1 2 3 5 8 13 21

def fibonacci(num):
    prevnum = 0
    firstnum = 1
    for i in range(num):
        if i <= 1:
            nextnum = i
        nextnum = firstnum + prevnum
        firstnum = prevnum
        prevnum = nextnum

        print(nextnum)


fibonaccinum = fibonacci(100)
print(fibonaccinum)
print('888888888888888888888888888888888888888888888888888888888')
def fib(number):
    a = 0
    b = 1
    result = []
    for i in range(number):
        #yield a
        result.append(a)
        temp = a
        a = b
        b = temp + b
    return result

print(fib(10))
for x in fib(10):
    print(x)

import Decorators

print(Decorators)