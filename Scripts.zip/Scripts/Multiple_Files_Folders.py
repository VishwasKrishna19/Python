import pandas as pd
import openpyxl
import xlrd
import os

os.getcwd()

tst_name = []
simgen_name = []
mapping = "C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\\Sample_tests\\TST_SIMGEN_MAPPING.txt"
#mapping = input("Enter the file name with Path of mapping.txt file (mapping between tst file and simgen file): ")
#path = "C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\\Sample_tests\\AUTT\\Comp_Flt_BG_Iteration_Bit_Test_Logic_Comp_Flt_BG_Iteration_Bit_Test_Logic.tst"
inputpath = input("Drag and Drop the Folder Contains tst files: ")
dict_data = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\\Data_Dictionary_MC21_CPCS.xls'
Template_xls = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\ASTC1217.xls'

'Outputs'
Actual_data = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\Actual.xlsx'
Actual_data1 = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\Actual1.xlsx'
temp_xls = 'C:\\Vishwas\\Task_Assigned\\Initiatives\\POC\Sample_tests\\AUTT\\Temp.xls'


def read_TST_SIMGEN_MAPPING(mapping):
    mappingdata = open(mapping, "r")
    for eachrow in mappingdata:
        tstname = eachrow.split(',')[0]
        tst_name.append(tstname)
        simgenname = eachrow.split(',')[1]
        simgen_name.append(simgenname)

read_TST_SIMGEN_MAPPING(mapping)
print(tst_name, simgen_name)

path = inputpath + tst_name[]