
# script to covert fts scripts to python

import os
import re
import sys

#path = r'C:\Python27\Scripts\SLTP_TOLD_GVI_TKF_ACT_ACC_GO_DIST_1_done'

path = sys.argv[1]

def converttopython(filename):

    new_file = os.path.splitext(filename)[0]+'.py'

    # Read the contents of the file to be modified
    fp = open(filename)
    fp_new = open(new_file,'w')

    lines = fp.readlines()
    new_lines = []

    for line in lines:

        # replace ' in fts to # in python
        line = re.sub(r'^\'', '#', line)

        # replace Include <filename> to import <module> in python
        matchobj = re.search(r'^Include.*', line, re.IGNORECASE)
        if matchobj:
            lib_name = os.path.splitext(matchobj.group().split()[1].strip('"'))[0]
            line = re.sub(matchobj.group(), 'import {}'.format(lib_name), line, re.IGNORECASE)

        # replace all wait commands in fts file to time.sleep in python
        matchobj = re.search(r'^WAIT.*', line, re.IGNORECASE)
        if matchobj:
            time_delay =  matchobj.group().split()[1]
            line = re.sub(matchobj.group(), 'time.sleep({})'.format(int(time_delay)/1000.0), line)

        # append OS.SYSTEM before all CDU commands in fts file
        # prefix = 'OS.SYSTEM'
        matchobj = re.search(r'^(\s*)(CDU.*)', line, re.IGNORECASE)
        if matchobj:
            line = line.replace(matchobj.group(),'{}exec_cmd(\'{}\')'.format(matchobj.group(1),matchobj.group(2)))

        matchobj = re.search(r'^(\s*)Compval\s*(.*)', line, re.IGNORECASE)
        if matchobj:
            line = re.sub(matchobj.group(), '{}Compval({})'.format(matchobj.group(1), matchobj.group(2)), line, re.IGNORECASE)

        matchobj = re.search(r'^(\s*)Read\s*(.*)', line, re.IGNORECASE)
        if matchobj:
            line = re.sub(matchobj.group(), '{}Read({})'.format(matchobj.group(1), matchobj.group(2)), line, re.IGNORECASE)

        matchobj = re.search('^AddResFile(.*)', line, re.IGNORECASE)
        if matchobj:
            line = line.replace(matchobj.group(), 'AddResFile(\'{}\')'.format(matchobj.group(1)))

        matchobj = re.search(r'^(\s*)MsgBox\s*(.*)', line, re.IGNORECASE)
        if matchobj:
            line = re.sub(matchobj.group(), '{}MsgBox({})'.format(matchobj.group(1), matchobj.group(2)), line, re.IGNORECASE)

        # replace all the endif statemnts
        line = re.sub(r'^End[iI]f.*\n', '', line, re.IGNORECASE)

        # replace If with if and add ':' for if block
        matchobj = re.search(r'^If\s+(.*)', line, re.IGNORECASE)
        if matchobj:
            #replace compare = with ==
            ifcnd = re.sub('\s*=\s*'," == ", matchobj.group(1))
            line = re.sub(r'^If\s+(.*)', 'if {}:'.format(ifcnd), line, re.IGNORECASE)

        # Commenting Options & Dim
        matchobj = re.search(r'^(\s*)Options|Dim\s*(.*)', line, re.IGNORECASE)
        if matchobj:
            line = re.sub(matchobj.group(), '#{}'.format(matchobj.group()), line, re.IGNORECASE)

        new_lines.append(line)

    new_lines = ''.join(new_lines)

    myfunc_replace = "def Read(*args):\n\tprint 'Read method invoked with args {}'.format(args) \
                      \n\ndef Compval(*args):\n\t print 'Compval method invoked with args {}'.format(args) \
                      \n\ndef AddResFile(*args):\n\t print 'AddResFile method invoked with args {}'.format(args)\
                      \n\ndef MsgBox(*args):\n\t print 'MsgBox method invoked with args {}'.format(args) \
                      \n\ndef exec_cmd(*args):\n\t print 'Exec_cmd method invoked with args {}'.format(args) \n\n"

    new_lines = re.sub('import', '{}import os\nimport time\nimport'.format(myfunc_replace), new_lines, 1)

    fp_new.write(new_lines)

    fp.close()
    fp_new.close()

for each_file in os.listdir(path):

    if cmp('.fts', os.path.splitext(each_file)[1]) == 0 or cmp('.FTS', os.path.splitext(each_file)[1]) == 0:
        #convert the files that have .fts as extension
        print "File {} Start conversion to Python".format(each_file)
        converttopython(os.path.join(path,each_file))