import os
import sys
import fileinput
import re
import pandas
import pandas as pd
from numpy import *
import csv

CppRead = input("Drag and Drop the folder structure of All the Cpp files or Enter the full folders Name with path: ")
os.getcwd()
if os.path.exists('Cppdata.txt'): os.remove('Cppdata.txt')
for root, dirs, files in os.walk(CppRead):
    for file in files:
        if file.endswith(".cpp"):
            with open(os.path.join(root, file), "r") as data:
                with open('Cppdata.txt', 'a') as wf:
                    line_num = 0
                    booldata = False
                    for cpplines in data:
                        line_num += 1
                        if cpplines.__contains__('return'):
                            nextstring = next(data)
                            nextstring = nextstring.strip()
                            if(nextstring.startswith('//')):
                                next_to_next_line = next(data)
                                if (next_to_next_line.__contains__('break') or next_to_next_line.__contains__('continue')):
                                    print(file)
                                    print(cpplines + next_to_next_line + str(line_num))
                                    wf.writelines(file + '\n' + cpplines + nextstring)
                                    booldata = True
                            elif(nextstring.__contains__('break') or nextstring.__contains__('continue')):
                                print(file)
                                print(cpplines + nextstring + str(line_num))
                                wf.writelines(file + '\n' + cpplines + nextstring)
                                booldata = True

                if(booldata == True):
                    print('No Such Instances in Found in Code')


