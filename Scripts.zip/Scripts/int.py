print(int(5)) #object is integer already. Returns 5
print(int('5')) #object is string. Returns 5
print(int(5.4)) #object is float. Returns 5
print(int(5.9)) #object is float. Returns 5
print(int(-5.9)) #object is float. Returns -5
print(int('5.4')) #object is float. Returns ValueError: invalid literal