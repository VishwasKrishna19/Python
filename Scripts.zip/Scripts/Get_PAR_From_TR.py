import os
import glob

path = r'C:\Vishwas\Task_Assigned\Python\TRs'

def getfilelist(path):
    files = glob.glob(os.path.join(path, '*.*'))
    trtxt_files = [x for x in files if os.path.splitext(x)[1].lower() == '.txt']
    return trtxt_files


trtxt_files = getfilelist(path)
print(trtxt_files)
fwrite = open('TR_Data.csv', "w")
fwrite.write('TR_Number,PAR\n')
filelist = []
current_status = ''
name = ''
PARNo = ''
CrossPAR = ''
CrossPARlist = []
finalstr = ''
for eachfile in trtxt_files:
    filename = os.path.basename(eachfile)
    filename = filename.split('.')[0]
    filecontent = open(eachfile, "r")
    filetext = filecontent.readlines()
    for eachline in filetext:
        if ' Dependent ' in eachline:
            PARNo = eachline.split(' Dependent ')[1]
            PARNo = PARNo.split(' ')[0]
            PARNo = PARNo.strip()
        if '1     (none) ' in eachline:
            CrossPAR = eachline.split(' Cross Reference ')[1]
            CrossPAR = CrossPAR.split(' ')[0]
            CrossPARlist.append(CrossPAR)
        finalstr = filename + ","  + PARNo + "," + ",".join(CrossPARlist) + '\n'
    fwrite.write(finalstr)
    CrossPARlist = []

    filecontent.close()
fwrite.close()