#!/usr/bin/python
import sys, string, os
import getopt

#sim_test_path = '\\777LR_CPOV\\Application\\Test_Proc\\Simulator'
sim_test_path = 'C:\\Vishwas\\Task_Assigned\\Python\\'

print(sim_test_path)
inputfile = "C:\\Vishwas\\Task_Assigned\\Python\\Prem\\A429_AVN_Chan_Sel_Logic_A429_AVN_Chan_Sel_Logic.res"
def main(argv):
    inputfile = ''
    outputfile = ''
    try:
      opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
    except getopt.GetoptError:
      print('test.py -i <inputfile> -o <outputfile>')
      sys.exit(2)    
    for opt, arg in opts:
      if opt == '-h':
         print('test.py -i <inputfile> -o <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg

    build_path = os.path.join(sim_test_path,'InstrumentedBuild')
    results_path = os.path.join(sim_test_path,'InstrumentedResults')
    #print(results_path)
    #parsing the result file for getting the coverage information in the corresponding DAT file
    fileOut = open(os.path.join(results_path,outputfile)+'.dat','w')
    fileIN  = open(os.path.join(results_path,inputfile), 'r')
    line = fileIN.readline()
    while line:
            #parse all the lines and dump the coverage data to a separate file
            parse_str =''
            parse_str = parse_str + line[0]
            return_val = parse_str.isdigit()
            if(return_val == 1):                    
                count = len(line)                    
                new_str = ''
                for i in range (0,count-1):                        
                    new_str =  new_str+str(line[i])
                new_str = new_str+'\n'                    
                fileOut.write(new_str)
                
            line = fileIN.readline()
            
    fileOut.close()
    fileIN.close()   

    #parsing the result file to move the result information
    fileOut = open(os.path.join(results_path,outputfile)+'_only_result.res','w')
    fileIN  = open(os.path.join(results_path,inputfile), 'r')
    lines = fileIN.readlines()
    fileIN.seek(0)
    for i in lines:
            #parse all the lines and retain only the result
            parse_str =''
            parse_str = parse_str + i[0]
            return_val = parse_str.isdigit()
            if(return_val != 1):                
                fileOut.write(i)
                
    fileIN.close()
    fileOut.close()


if __name__ == "__main__":
   main(sys.argv[1:])