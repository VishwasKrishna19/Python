# Question 14
### **Question:**
'''
>***Write a program that accepts a sentence and calculate the number of upper case letters and lower case letters.***
>***Suppose the following input is supplied to the program:***
Hello world!
>***Then, the output should be:***
UPPER CASE 1
LOWER CASE 9
---------------------
### Hints:
>***In case of input data being supplied to the question, it should be assumed to be a console input.***
-------------------
'''

# input_sentence = input("Enter the Sentense")
input_sentence = "ABCDabcd1234"
uppercase = 0
lowercase = 0
otherthancharacter = 0
digit = 0

for eachword in input_sentence:
    if eachword.isupper() :
        uppercase += 1
    elif eachword.islower():
        lowercase += 1
    elif eachword.isdigit():
        digit += 1
    else:
        otherthancharacter += 1

print("Uppercase Character", uppercase)
print("LowerCase Character", lowercase)
print("Digits", digit)
print("Other Character", otherthancharacter)

# Question 15
### **Question:**
'''
>***Write a program that computes the value of a+aa+aaa+aaaa with a given digit as the value of a.***
>***Suppose the following input is supplied to the program:***
9
>***Then, the output should be:***
11106
---------------------
### Hints:
>***In case of input data being supplied to the question, it should be assumed to be a console input.***
-------------------
'''''

# inputnum = input("Enter the Number: ")
inputnum = "9"
inputnum = int(inputnum)

def compute(val):
    val1 = str(val) + str(val)
    val2 = str(val) + str(val) + str(val)
    val3 = str(val) + str(val) + str(val)+ str(val)
    finalval = val + int(val1) + int(val2) + int(val3)
    print(finalval)

compute(9)

# Question 16
### **Question:**
'''
>***Use a list comprehension to square each odd number in a list. The list is input by a sequence of comma-separated numbers.***
>***Suppose the following input is supplied to the program:***
1,2,3,4,5,6,7,8,9
>***Then, the output should be:***
1,9,25,49,81
----------------------
### Hints:
>***In case of input data being supplied to the question, it should be assumed to be a console input.***
'''

# inputnumbers = input("Enter the sequence of numbers: ")
inputnumbers = "1,2,3,4,5,6,7,8,9"

def compute(val):
    for eachval in val.split(','):
        eachval = int(eachval)
        if int(eachval) % 2 == 1:
            eachval =eachval * eachval
            print(eachval)

compute(inputnumbers)

#using List Comprehension
finalval = [str(int(i) ** 2) for i in inputnumbers.split(',') if int(i) %2 ==1]
print(','.join(finalval))

# Question 17
### **Question:**
'''
>***Write a program that computes the net amount of a bank account based a transaction log from console input. The transaction log format is shown as following:***
D 100
W 200
* D means deposit while W means withdrawal.
>***Suppose the following input is supplied to the program:***
D 300
D 300
W 200
D 100
>***Then, the output should be:***
500
'''

inputstr1 = "D 300,D 300,W 200,D 100"
inputstr = inputstr1.split(",")
deposit = 0
withdraw = 0
amount = 0
for eachtrans in inputstr:
    eachtrans = eachtrans.split(' ')
    if eachtrans[0] == 'D':
        deposit += 1
        amount += int(eachtrans[1])
    elif eachtrans[0] == 'W':
        withdraw += 1
        amount -= int(eachtrans[1])
    else:
        print('Nothing')

print(amount)

total = 0
# while True:
#     s = inputstr1.split()
#     if not s:            # break if the string is empty
#         break
#     cm,num = map(str,s)    # two inputs are distributed in cm and num in string data type
#
#     if cm=='D':
#         total+=int(num)
#     if cm=='W':
#         total-=int(num)
#
# print(total)