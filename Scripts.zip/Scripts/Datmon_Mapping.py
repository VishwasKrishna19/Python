import pyodbc

def datmonmapping(server,database,datmonpath):

    driver = '{SQL Server}' # Driver you need to connect to the database

    cnn = pyodbc.connect('DRIVER='+driver+';SERVER='+server+';DATABASE='+database+';Trusted_Connection=yes;')

    dataCursor = cnn.cursor()

    droptable_sql = """
    IF OBJECT_ID('Datmon', 'U') IS NOT NULL 
      DROP TABLE Datmon; 
    """

    dataCursor.execute(droptable_sql)

    createTable_sql = """
    CREATE TABLE Datmon
    (  
        Parameter nvarchar (500)
        ,DatmonPath nvarchar (500)
        ,RangeofArray nvarchar(500)
    ); 
    """

    dataCursor.execute(createTable_sql)

    cnn.commit()

    insertRow_sql = """
    INSERT INTO Datmon(Parameter, DatmonPath, RangeofArray) 
        VALUES (?, ?, ?)
    """

    with open(datmonpath, 'r') as file :
        filedata = file.readlines()

    linenumber = 0
    loopstarted = 0
    loops = 0
    for line in filedata:
        line = line.lstrip()
        line = line.rstrip()
        if line.startswith('For ') and line.__contains__('=') & loopstarted == 0:
            loopstarted = 1
            line = line.split(' ', 1)[1]
            Array = [line.strip()]
            iden = line.partition("To")[0].strip()
            identifier = [iden.partition("=")[0].strip()]
            count = linenumber + 1
            fline = filedata[count].strip()
            while True:
                if fline.startswith('For '):
                    fline = fline.split(' ', 1)[1]
                    Array.append(fline.strip())
                    fiden = fline.partition("To")[0].strip()
                    identifier.append(fiden.partition("=")[0].strip())
                    loopstarted += 1
                elif fline == "Next" and loopstarted == 1:
                    break
                elif fline == "Next":
                    loopstarted -= 1
                elif fline != "" and fline.__contains__('ASCB D') == False:
                    ParameterName = fline.partition("=")[0].strip()
                    Datmonpath = fline.partition("=")[2]
                    Datmonpath = Datmonpath.strip()
                    paramarg = ParameterName.partition("(")[2]
                    paramarg = paramarg.strip(")")
                    paramarg = paramarg.split(",")
                    paramarg = [item.strip() for item in paramarg]
                    argcount = 0
                    ArrayRange = ""
                    while argcount < len(paramarg):
                        index = identifier.index(paramarg[argcount])
                        ArrayRange = ArrayRange + Array[index]
                        argcount += 1
                        if argcount == len(paramarg):
                            continue
                        else:
                            ArrayRange = ArrayRange + ", "
                    dataCursor.execute(insertRow_sql, ParameterName, Datmonpath, ArrayRange)
                count += 1
                fline = filedata[count].strip()
            loops = count
        elif line.__contains__('ASCB D') == False and line.__contains__('=') and loopstarted == 0 and line.startswith('\'') == False:
            if line.startswith('Dim') and line.__contains__(':'):
                line = line.split(' ', 1)[1]
                ParameterName = line.partition(":")[0]
                ParameterName = ParameterName.lstrip()
                ParameterName = ParameterName.rstrip()
            else:
                ParameterName = line.partition("=")[0]
                ParameterName = ParameterName.strip()
            Datmonpath = line.partition("=")[2]
            Datmonpath = Datmonpath.strip()
            dataCursor.execute(insertRow_sql, ParameterName, Datmonpath, "")
        elif linenumber == loops:
            loopstarted = 0
        linenumber += 1
    cnn.commit()