import re
import os
parse = 0
cwd = os.getcwd()
def CR_State():
        #print(cwd)
        path = cwd + "\\CR_log1.txt"
        file = open(path,'r')
        file_status = open("Results/CR_Status.csv",'w')
        file_status.write("CR#,Status#\n")
        for line in file:
                Request_id = re.findall( r"REQUEST ID:", line,re.IGNORECASE )
                Current_Status = re.findall( r"CURRENT STATUS:", line, re.IGNORECASE )
                if Request_id:
                        id = line.split( ":" )[1].strip()
                if Current_Status:
                        status = line.split( ":" )[4].strip()
                        file_status.write(id.strip()+","+status.strip()+"\n")
        file.close()
        file_status.close()
