import os
import re
import codecs


with codecs.open("C:/Users/h126313/Desktop/Python/Script/Comapre/T2L_TGFB_0XXX_Smart_KeyPad.tsf", "r",encoding='UTF8', errors='ignore') as Testfile:
    with open('C:/Users/h126313/Desktop/Python/Script/Comapre/Req_ID.txt', 'w') as req:
        for lines in Testfile:
            if lines.__contains__("CompareObjectID(\""):
                Reqiddetails = re.findall(r'"(.*?)"', lines)
                Reqiddetails = "\n".join(str(e) for e in Reqiddetails)
                print(Reqiddetails)
                req.write(Reqiddetails + '\n')