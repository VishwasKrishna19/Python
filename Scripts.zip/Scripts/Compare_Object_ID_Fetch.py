import os
import re
import codecs

os.getcwd()
inputfolderpath = input("Drag and Drop the folder having Test File: ")
print(inputfolderpath)

with open('C:/Users/h126313/Desktop/Python/Script/Comapre/Req_ID.csv', 'w') as req:
    for root, dirs, files in os.walk(inputfolderpath):
        for file in files:
            if file.endswith(".tsf") or file.endswith(".cpp") or file.endswith(".TSF") or file.endswith(".CPP"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as Testfile:
                        for lines in Testfile:
                            if lines.__contains__("CompareObjectID(\""):
                                Reqiddetails = re.findall(r'"(.*?)"', lines)
                                filename = Testfile.name
                                filename = filename.split('\\')[-1]
                                filename = ',' + filename + '\n'
                                Reqiddetails = filename.join(str(e) for e in Reqiddetails)
                                print(Reqiddetails + filename)
                                req.write(Reqiddetails + filename +'\n')
                            elif lines.__contains__("tio.OutputResult(\""):
                                Reqiddetails = re.findall(r'TSC(.*?)]', lines)
                                filename = Testfile.name
                                filename = filename.split('\\')[-1]
                                filename = ',' + filename + '\n'
                                Reqiddetails = filename.join(str(e) for e in Reqiddetails)
                                print(Reqiddetails + filename)