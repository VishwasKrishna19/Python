#OOP

# Encapsulation is the Bindidng of the Data and will be binding in one class group so that Instances can able to access
# Attributes and Methods

#if we Put underscore in python its a kind of Private Variable in Python
# Double Underscore in Python is called as Dunder Methods
class BigObject(): #Class
    pass

Obj1 = BigObject() #Instance
Obj2 = BigObject() #Instance

print(Obj1)

class PlayerCharacter:
    membership = True #Class object Attribute
    def __init__(self, name, age): #Constructor Method, Automatically Called in this block when we instanciate
        if (self.membership) or (PlayerCharacter.membership):
            self.name = name            #Attributes
            self.age = age

    def run(self):
        print('run') #we get none if Function Doesn't return anything
        return ''
    def introduce(self):
        print(f'My Name is {self.name}')

    def Shout(self):
        print(f'My Name is {self.name} and i am {self.age} years old')

player1 = PlayerCharacter('Vishwas', 31)
player2 = PlayerCharacter('Krishna', 30)
player1.attack = 50
print(player1.name)
print(player1.run())
print(player2.age)
print(player1.attack)
print(player1.membership)
print(player1.introduce())
print(player1.Shout())

player3 = {'name': 'Vishwas', 'age': 31}
print(player3['name'])
print(player3['age'])

player1.Shout = "F**K Y*U"
print(player1.Shout)