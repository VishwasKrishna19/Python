import re
path = "C:/Vishwas/Task_Assigned/TSC2_0/Drop2/Load_7.5/Doors_Trace/objectIds.txt"
fwrite = open("output.csv", "w")
filepath = open(path, 'r')
for line in filepath:
    print(line)
    patteren = re.findall(r'TSC((_\d)?|(\d))_[a-zA-Z_]+(\d+)', line, re.IGNORECASE)
    #patteren2 = re.findall(r'TSC((_\d)?|(\d))_[a-zA-Z_]+(\d+)', line, re.IGNORECASE)
    print(patteren[0][3])
    fwrite.write(patteren[0][3] + '\n')

fwrite.close()