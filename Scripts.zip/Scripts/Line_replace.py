import os
import sys
import re

with open("C:/Users/h126313/Desktop/Python/E2G_MAPC_1020.tsf") as f:
    with open("C:/Users/h126313/Desktop/Python/E2G_MAPC_1020_Updated.tsf", "w") as wf:
        for line in f:
            if line.__contains__('CompareObjectID("DISPLAYS_SW_'):
                line = line.split('Or')
                for n,i in enumerate(line):
                    if i.__contains__('DISPLAYS_SW_HLR'):
                        line[n] = ''
                line1 = "".join(line)
                print(line1 + "Then")
                line = line1 + "Then"
            wf.write(line)