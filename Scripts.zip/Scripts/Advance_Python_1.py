
#zip and Enumerate

l = ['a', 'b', 'c', '1', '2', '3']

for i in range(len(l)):
    print(i, l[i])

for i, v in enumerate(l):
    print(i)

l1 = ['a', 'b', 'c', '1', '2', '3']
l2 = ['1', '2', '3']
l3 = ['1', '2', '3', '4', '5']
dc = {'a':1, 'b':2}
for i in zip(l1, l2, l3, dc):
    print(i)

dc1 = {'a':1, 'b':2}
dc2 = {'c':3, 'd':4}
for i in zip(dc1, dc2):
    print(i)

t1 = (1, 2)
t2 = (3, 4)
for i in zip(t1, t2):
    print(i)

#List Comprehension

l = []

for i in range(10):
    l.append(i)

l2 = [i**2 for i in range(10) if i%2 == 0]
print(l)
print(l2)

lt = []
for i in range(5):
    for j in range(i):
        lt.append(j)

print(lt)

l5 = [j for i in range(5) for j in range(i)]
print(l3)
