#####
###
### Author @ Varun Pandey
### Purpose @ To solve a complex Arithmetic Expression
####

# -*- coding: utf-8 -*-
from __future__ import division
from pyparsing import (Literal, CaselessLiteral, Word, Combine, Group, Optional,
                       ZeroOrMore, Forward, nums, alphas, oneOf)
from re import *
import re, math, os
#from nsp import NumericStringParser
import time, random
import sys
import operator
__author__ = 'Varun Pandey'
__version__ = '$Revision: 0.0 $'
__date__ = '$Date: 2018-04-11 $'
class NumericStringParser(object):

    def pushFirst(self, strg, loc, toks):
        self.exprStack.append(toks[0])

    def pushUMinus(self, strg, loc, toks):
        if toks and toks[0] == '-':
            self.exprStack.append('unary -')
    def __init__(self):
        """
        expop   :: '^'
        multop  :: '*' | '/'
        addop   :: '+' | '-'
        integer :: ['+' | '-'] '0'..'9'+
        atom    :: PI | E | real | fn '(' expr ')' | '(' expr ')'
        factor  :: atom [ expop factor ]*
        term    :: factor [ multop factor ]*
        expr    :: term [ addop term ]*
        """
        point = Literal(".")
        e = CaselessLiteral("E")
        fnumber = Combine(Word("+-" + nums, nums) +
                          Optional(point + Optional(Word(nums))) +
                          Optional(e + Word("+-" + nums, nums)))
        ident = Word(alphas, alphas + nums + "_$")
        plus = Literal("+")
        minus = Literal("-")
        mult = Literal("*")
        div = Literal("/")
        lpar = Literal("(").suppress()
        rpar = Literal(")").suppress()
        addop = plus | minus
        multop = mult | div
        expop = Literal("^")
        pi = CaselessLiteral("PI")
        expr = Forward()
        atom = ((Optional(oneOf("- +")) +
                 (ident + lpar + expr + rpar | pi | e | fnumber).setParseAction(self.pushFirst))
                | Optional(oneOf("- +")) + Group(lpar + expr + rpar)
                ).setParseAction(self.pushUMinus)
        # by defining exponentiation as "atom [ ^ factor ]..." instead of
        # "atom [ ^ atom ]...", we get right-to-left exponents, instead of left-to-right
        # that is, 2^3^2 = 2^(3^2), not (2^3)^2.
        factor = Forward()
        factor << atom + \
            ZeroOrMore((expop + factor).setParseAction(self.pushFirst))
        term = factor + \
            ZeroOrMore((multop + factor).setParseAction(self.pushFirst))
        expr << term + \
            ZeroOrMore((addop + term).setParseAction(self.pushFirst))
        # addop_term = ( addop + term ).setParseAction( self.pushFirst )
        # general_term = term + ZeroOrMore( addop_term ) | OneOrMore( addop_term)
        # expr <<  general_term
        self.bnf = expr
        # map operator symbols to corresponding arithmetic operations
        epsilon = 1e-12
        self.opn = {"+": operator.add,
                    "-": operator.sub,
                    "*": operator.mul,
                    "/": operator.truediv,
                    "^": operator.pow}
        self.fn = {"sin": math.sin,
                   "cos": math.cos,
                   "tan": math.tan,
                   "exp": math.exp,
                   "abs": abs,
                   "trunc": lambda a: int(a),
                   "round": round,
                   "sgn": lambda a: abs(a) > epsilon and cmp(a, 0) or 0}

    def evaluateStack(self, s):
        op = s.pop()
        if op == 'unary -':
            return -self.evaluateStack(s)
        if op in "+-*/^":
            op2 = self.evaluateStack(s)
            op1 = self.evaluateStack(s)
            return self.opn[op](op1, op2)
        elif op == "PI":
            return math.pi  # 3.1415926535
        elif op == "E":
            return math.e  # 2.718281828
        elif op in self.fn:
            return self.fn[op](self.evaluateStack(s))
        elif op[0].isalpha():
            return 0
        else:
            return float(op)

    def eval(self, num_string, parseAll=True):
        self.exprStack = []
        results = self.bnf.parseString(num_string, parseAll)
        val = self.evaluateStack(self.exprStack[:])
        return val

#nsp = NumericStringParser()
#result = nsp.eval('(2935.0797404906616 - 4698.954079969563) * 3437.74677 * (pi / 180) * cos((4208.98945852474) * (pi / 180))')
#print(result)

DIGITS = '0123456789'
OPS = '+-*/^'
OP_FUNCS = {
    '+':lambda x, y:x + y,
    '-':lambda x, y:x - y,
    '*':lambda x, y:x * y,
    '/':lambda x, y:x / y,
    '^':lambda x, y:x ** y,
}
# Uses PEMDAS - parenthesis, exponents, multiplication, division, addition, subtraction
ORDER_OF_OPERATIONS = [
    ['^'],
    ['*', '/'],
    ['+', '-'],
]
VALID_PAIRS = [
    ('NUM', 'OP'),
    ('OP', 'NUM'),
    ('OP', 'OPAREN'),
    ('CPAREN', 'OP'),
    ('OPAREN', 'NUM'),
    ('NUM', 'CPAREN'),
    ('OPAREN', 'OPAREN'),
    ('CPAREN', 'CPAREN'),
]
NUM_MATCH = re.compile(
'(?:[1-9][0-9]*|0)'
'(?:[.][0-9]+)?'
)
class Token():  #This is not really useful but tuples could be less clear
    def __init__(self, type_, info=None):
        self.type = type_
        self.info = info
#    def __str__(self):
#        return '{}:{}'.format(self.type, self.info)
PLACEHOLDER = Token('PLACEHOLDER')
def tokenize(expr):
    tokens = []
    index = 0
    while index<len(expr):
        curr_and_after = expr[index:]
        is_num = NUM_MATCH.match(curr_and_after)
        if expr[index] in OPS:
            tokens.append(Token('OP', expr[index]))
        elif is_num:
            num = is_num.group(0)
            tokens.append(Token('NUM', float(num)))
            length = len(num)
            index += length-1
        elif expr[index] == '(':
            tokens.append(Token('OPAREN'))
        elif expr[index] == ')':
            tokens.append(Token('CPAREN'))
        elif expr[index] == ' ':
          pass
        else:
          raise SyntaxError('Invalid character')
        index += 1
    return tokens
def is_valid(tokens):
    if tokens == []:
        return False

    #This sections tests if parentheses are correctly nested
    nesting = 0
    for token in tokens:
        if token.type == 'OPAREN':
            nesting += 1
        elif token.type == 'CPAREN':
            nesting -= 1
        if nesting<0:
            return False
    if nesting != 0:
        return False

    for index, _ in enumerate(tokens[:-1]):
        #[:-1] because otherwise next wont exist on last token
        curr, next_ = tokens[index], tokens[index+1]
        curr_kind, next_kind = curr.type, next_.type
        possible_valid_pairs = []
        for valid_pair in VALID_PAIRS:
            possible_valid_pairs.append((curr_kind, next_kind) == valid_pair)
            #Test if it's equal to a valid pair
        if not any(possible_valid_pairs):
            return False

    return True

def to_nested(tokens):
    assert(is_valid(tokens))
    out = []
    index = 0
    while index<len(tokens):
        if tokens[index].type == 'OPAREN':
            nesting = 1
            in_parens = []
            while nesting:
                index += 1
                if tokens[index].type == 'OPAREN':
                    nesting += 1
                elif tokens[index].type == 'CPAREN':
                    nesting -= 1
                in_parens.append(tokens[index])
            in_parens=in_parens[:-1]  #Remove final closing paren
            out.append(in_parens)
        else:
            out.append(tokens[index])
        index += 1
    return out
def has_op(tokens, op):
    return any([token.type == 'OP' and token.info == op for token in tokens])
def eval_tokens(tokens):
    newTokens = []
    for item in tokens:
        if type(item) == list:
          #Parenthesised expressions are lists of tokens
            newTokens.append(Token('NUM', eval_tokens(item)))
        else:
            newTokens.append(item)
    tokens = newTokens
    for ops_to_evaluate in ORDER_OF_OPERATIONS:
        newTokens = []
        while any([has_op(tokens, op) for op in ops_to_evaluate]):
          #While any of the ops exists in the expression
            for index, token in enumerate(tokens):
                if token.type == 'OP' and token.info in ops_to_evaluate:
                    where = index
                    func = OP_FUNCS[token.info] #Get a function for the operation
                    break
            fst, snd = tokens[where-1].info, tokens[where+1].info
            before, after = tokens[:where-1], tokens[where+2:]
            result = Token('NUM', func(fst, snd))
            tokens = before+[result]+after  #Recombine everything

    assert(len(tokens) == 1)  #Should always be true but for debugging it's useful
    assert(tokens[0].type == 'NUM')
    return tokens[0].info
def eval_expr(expr):
    # print("Inside eval exp = ", expr.encode('utf-8'))
    tokens = tokenize(expr)
    nested = to_nested(tokens)
    return eval_tokens(nested)

def paren_checker(string):
    openBraceCnt = string.count("(")
    closeBraceCnt = string.count(")")

    # check for the match
    if openBraceCnt == closeBraceCnt:
        return True
    else:
        le = len(string)

        # to balance out the logic
        if openBraceCnt > closeBraceCnt:
            string = string[1:le] #string + ")"
        else:
            string = string[1:(le-1)] #"(" + string

        return string

def trigonometric(exp):

    expList = []

    expList = exp.split(" ")

    #exp = str(exp,encoding='utf-8')
    #print(exp)
    #exp = exp.replace(u'\\xe2\\x80\\x93',"-").decode('utf-8')

    print(exp)
    print(expList)

    internalExp = []
    paraList = []

    trigFoundCount = -1
    res = ""

    nspClass = NumericStringParser()

    try:
        if ' cos ' in exp or ' sin ' in exp or ' tan ' in exp:
            print(exp)

            flagStartReading = False
            for count, data in enumerate(expList):

                if data == '':
                    continue

                if data == "cos" or data == "sin" or data == "tan":
                    flagStartReading = True
                    trigFoundCount = count
                    continue

                if flagStartReading:
                    if data == "(":
                        paraList.append("(")
                    elif data == ")":
                        # pop the last element of paralist to know when the internal expression is completed
                        #   as soon as the flagStartReading is True and paraList becomes empty, it means that
                        #   internal expression parsing is completed, and that expression can be passed on the
                        #   actual internal expression calculator to calculate the value
                        i = len(paraList) - 1 # last element index
                        try:
                            paraList.pop(i)
                        except:
                            continue
                    # keep creating the internal expression
                    internalExp.append(data)

                    # when paraList becomes empty, implies that the internal expression is completely parsed
                    if len(paraList) == 0:
                        print("*********** " + str(internalExp))

                        # to avoid errors while calculating data like : ((12)*(3.14/180)), so as to remove extra braces
                        #   at starting and ending
                        #if internalExp[0] == "(" and internalExp[len(internalExp)-1] == ")":   ==> commented by Varun so as to avoid error
                        #    internalExp = internalExp[1:-1]
                        internalExp = eliminateRedundantBraces(internalExp)

                        #print("Mod *********** " + ''.join(internalExp))
                        print("Mod *********** " + ''.join(internalExp))
                        # input()
                        internalResult = nspClass.eval(internalExp)#eval_expr(eliminateRedundantBraces(''.join(internalExp)))

                        # now calculate the data after passing the argument to Trigonometry function
                        if (expList[trigFoundCount] == "cos"):
                            trigResult = math.cos(internalResult)
                        elif (expList[trigFoundCount] == "sin"):
                            trigResult = math.sin(internalResult)
                        elif (expList[trigFoundCount] == "tan"):
                            trigResult = math.tan(internalResult)

                        # finally merge the trigonometry result with the actual expression
                        remaingingExp = ''.join(expList[0: trigFoundCount])
                        finalExp = remaingingExp + str(trigResult)

                        # check if the braces are matching or not, add the missing brace if not matching
                        d = paren_checker(finalExp)


                        # d only stores the updated final value of string when the braces are not matching
                        if d == True:
                            e = eliminateRedundantBraces(finalExp)
                            print("********* Final 1= ", e)

                            res =  nspClass.eval(e)# eval_expr(e) - Commented by Varun
                            print("********* Final Result = ", res)
                        else:
                            e = eliminateRedundantBraces(d)
                            print("********* Final 2= ", e)
                            res = nspClass.eval(e)# eval_expr(e) - Commented by Varun
                            print("********* Final Result = ", res)

        # to indicate that everything has gone fine
        return [True,res]
    except:
        return [False,"NA"]

def breakLogicExpression(exp):
    intermediateExpList = []
    paraList = []
    intermediateExp = ""

    expList = exp.split(" ")
    for cnt, data in enumerate(expList):
        if data == '':
            continue

        if data == "(":
            paraList.append(data)
            intermediateExp = intermediateExp + data + " "
        elif data == ")":
            # paralist is not empty
            if len(paraList):
                paraList.pop(len(paraList) - 1)  # pop the previous opening brace (

            intermediateExp = intermediateExp + data + " "

            # if  len(paraList)is empty, it means we found an intermediate expression
            if len(paraList) == 0:

                # before adding it to list, make sure that the expression inside the trigonometry function does not
                #   have redundant brackets
                d = intermediateExp.strip().split(" ")

                '''if d[0] == "sin" or d[0] == "cos" or d[0] == "tan":
                    print("Redundant removed = ",eliminateRedundantBraces(''.join(d[1:])))
                    input()
                    intermediateExp = d[0] + " ( "+eliminateRedundantBraces(''.join(d[1:])) + " ) "'''
                intermediateExpList.append(intermediateExp.strip())
                print("***** intermediateExp = ", intermediateExp)

                #input()
                # clear the previous data
                intermediateExp = ""
        else:
            intermediateExp = intermediateExp + data + " "

    return intermediateExpList


def eliminateRedundantBraces(x):
    *n,= re.sub('\D','',x);x=sub('\d','9',x);v,i,r,l=eval(x),0,lambda d,a,s:d.replace(s,"?",a).replace(s,"",1).replace("?",s),lambda:len(findall('\(',x))
    while i<l():
        j=0
        while j<l():
            h=r(r(x,i,"("),j,")")
            try:
                if eval(h)==v:i=j=-1;x=h;break
            except:0
            j+=1
        i+=1
    return sub('9','%s',x)%tuple(n)

def createTruthTable(initExp,outputVar, varList, flagReadHealFile, opMinrange, opMaxrange, path, opDataType):

    # delete if already present (required when using for multiple iterations)
    #if os.path.isfile('airthematic_Eval_out.txt'):
    #    os.unlink('airthematic_Eval_out.txt')

    resultFile = open(path + r'\airthematic_Eval_out.txt', 'w')
    retValue = ""

    minList = []
    maxList = []
    resolutionList = []

    outputVarRange = []
    flagOutputNotFound = True

    # as of now, it is not fixed that what needs to be done for terms which are not present in Heal Files.
    #   Hence as a workaround, we will check if FloatIntUInt.txt is present in the same path.
    #   If FloatIntUInt.txt is not present, make the maxList assuming it to max limit of 100 per variable
    #   and do calculation
    if not os.path.isfile("FloatIntUInt.txt"):
        maxList = [255] * len(varList)
        print("Taking default Values. Not from Heal Files, with all variables being assumed with a range of [0-255]")

    # implies that we need to read the Heal File, all the variables are present in Heal File
    elif flagReadHealFile:

        if len(diff) == 0:
            # assuming it is in the same path
            # now search the heal file for those input variables
            with open(path + "\FloatIntUInt.txt", "r") as file:
                for cnt, line in enumerate(file):
                    if cnt == 0:
                        continue
                    for var in varList:
                        d = line.lower().strip('"').split(",")
                        #if var in d[0]:
                        if var == d[0].strip('"'):
                            # do something
                            if not (d[2] == ''):
                                minList.append(d[2])
                            else:
                                #minList.append("NA")
                                minList.append("0")
                            if not (d[3] == ''):
                                maxList.append(d[3])
                            else:
                                #maxList.append("NA")
                                maxList.append("0")
                            if not (d[4] == ''):
                                resolutionList.append(d[4])
                            else:
                                #resolutionList.append("NA")
                                resolutionList.append("0")

                        if outputVar in d[0] and flagOutputNotFound:
                            # adding min and max range of output variable
                            outputVarRange.append(d[2])
                            outputVarRange.append(d[3])
                            flagOutputNotFound = False  # i.e. the output variable is now found

    else:  # this will be required when the variables are not present in the Heal Files
            #  or when the Heal file does not exists in the path provided
        maxList = [255] * len(varList)

    print(minList)
    print(maxList)
    print(resolutionList)

    #midList = [(float(x)+float(y))/2 for x,y in zip(minList, maxList)]
    #print(midList)

    # this will be required when the variables are not present in the Heal Files
    #if len(maxList) == 0:
    #    maxList = [100] * len(varList)

    zeroList = [0] * len(maxList)

    '''for x, y in zip(zeroList, maxList):
        print(x, y)
        x = int(x)
        y = int(y)
        print(random.randint(int(x),int(y)))
    input()'''

    # not considering the min range into account
    #randomList = [random.uniform(float(x),float(y)) for x,y in zip(minList, maxList)]
    if 'int' in opDataType:
        randomList = [random.randint(int(float(x)),int(float(y))) for x,y in zip(zeroList, maxList)]
    else:
        randomList = [random.uniform(float(x), float(y)) for x, y in zip(minList, maxList)]
    #randomList = [random.uniform(int(x),int(y)) for x,y in zip(zeroList, maxList)]
    #print(randomList)

    print(zeroList)
    print(maxList)

    # check if the input variables are found in Heal Files
    if len(maxList) > 0:
        resultFile.write("Inputs\n")
        # replace the variable with their values
        for cnt, variable in enumerate(varList):
            initExp = initExp.replace(variable,str(randomList[cnt]))

            # update airthematic_Eval_out.txt
            resultFile.write(variable + " : " + str(randomList[cnt]) + "\n")

        initExp = re.sub(r"\bdegrees_to_radians\b", '(pi/180) * ', initExp.lower())
        print("Expression with Values replaced = ", initExp)

        #ToDO : break the expression in sub-units and then check for redundant braces, and reform the expression
        # now evaluate the expression ==> not required now
        nspClass = NumericStringParser()

        spltExp = []
        validArcSinCos = False
        # check if there are any arccos [-1 to 1], arcsin [-1 to 1] or arctan [Universal any range] functions
        if 'arccos' in initExp.lower() or 'arcsin' in initExp.lower() or 'arctan' in initExp.lower():
            if 'arccos' in initExp.lower():
                spltExp = initExp.lower().split('arccos')

                insideArc = spltExp[1:][0].strip()
                # first evaluate the expression inside arccos
                result = nspClass.eval(insideArc)
                if -1<= result <= 1: # i.e. for acrcos requirement
                    arcCosResult = math.acos(result)

                    # once the above result is calculated merge with the other statement
                    initExp = spltExp[0] + str(arcCosResult)
                    print("Replaced Expression with ArcCos Calculated Expression = ", initExp)
                    validArcSinCos = True
                else:
                    resultFile.write(outputVar + " = NOT DEFINED ; <ERROR> : Input to ArcCos based on the calculated inputs is not valid\n")
            else:
                validArcSinCos = True

            if 'arcsin' in initExp.lower():
                spltExp = initExp.lower().split('arcsin')

                le = len(spltExp)
                # first evaluate the expression inside arcsin
                result = nspClass.eval(spltExp[1:][0].strip())
                if -1<= result <= 1: # i.e. for acrsin requirement
                    arcSinResult = math.asin(result)

                    # once the above result is calculated merge with the other statement
                    initExp = spltExp[0] + str(arcSinResult)
                    print("Replaced Expression with Arcsin Calculated Expression = ", initExp)
                    validArcSinCos = True
                else:
                    resultFile.write(outputVar + " = NOT DEFINED ; <ERROR> : Input to ArcSin based on the calculated inputs is not valid\n")
            else:
                validArcSinCos = True

            if 'arctan' in initExp.lower():
                spltExp = initExp.lower().split('arctan')

                # first evaluate the expression inside arctan
                result = nspClass.eval(spltExp[1:][0].strip())

                arcTanResult = math.atan(result)
                # once the above result is calculated merge with the other statement
                initExp = spltExp[0] + str(arcTanResult)
                print("Replaced Expression with Arctan Calculated Expression = ", initExp)
                validArcSinCos = True
        else:
            validArcSinCos = True

        if validArcSinCos:
            # print(nspClass.eval(initExp))
            result = nspClass.eval(initExp)#startEval(initExp)        ==> Commented by Varun, as nsp offers a better solution

            if 'int' in opDataType:
                result = int(result)
            resultFile.write("Output\n")
            if flagOutputNotFound:
                # return the values, when it is not found in Heal file, this also will assume a range of 0-255
                # opMinrange, opMaxrange
                if float(opMinrange) <= float(result) <= float(opMaxrange):
                    retValue = str(opMinrange) + "," + "Not_Found" + "," + str(opMaxrange)
                    resultFile.write(outputVar + " : " + str(result) + "\n")
                else:
                    retValue = str(opMinrange) + "," + "Overflow" + "," + str(opMaxrange)
                    resultFile.write(outputVar + " : " + str(result))
                #return (retValue)
            else:
                print(float(result))
                if float(outputVarRange[0]) <= float(result) <= float(outputVarRange[1]):
                    resultFile.write(outputVar + " : " + str(result) + "\n")
                    # return the values
                    retValue = str(outputVarRange[0]) + "," + "Valid" + "," + str(outputVarRange[1])
                    # return (retValue)
                else:
                    resultFile.write(outputVar + " : " + str(result) + "; # NOTE : <ERROR> Output Variable does"
                                                                       " not fall in Output Range. "
                                                                       "May cause an ovverrun. Point of concern\n")

                    # return the values, when it does not fall in the range
                    retValue = str(outputVarRange[0]) + "," + "Overflow" + "," + str(outputVarRange[1])
                    # return (retValue)
    else:
        resultFile.write("<Error> : Input/Output Variables not found in Heal Files. Either these are Internal"
                         " Variables or they are required to be added manually in FloatIntUInt.txt")

        # resultFile.close()
    resultFile.close()
    return (retValue)


#ToDo - check for utf errors
def startEval(exp):
    #exp = "(75-45)*0.088*0.49999999999999994"  # ==> Working
    #print(eliminateRedundantBraces(exp))
    #input()
    #exp = "(5*2) - (10/2) * (100/2-1)"  # ==> Working
    #exp = "5*2+10/2*(100/2-1)"  # ==> Working
    #exp = "5*1+10/2*3/2+1" # ==> Working

    #exp = "5*1.3+10/2*3.1/2+1" # ==> Working

    #exp = "(10 - 8) * 3437.74677 * (PI / 180) * cos ((12) * (PI / 180))" # ==> Working

    #exp = "((12) * (PI / 180))"
    #print(exp.encode('utf-8'))
    #input()
    #exp = "3437.74677 * (PI / 180) * (12 - 10)" # ==> Working

    #exp = "((12 * 0.05196) * COS (Degrees_To_Radians (30))) - (((75 - 45) * 0.088) * SIN (Degrees_To_Radians (30)))" # ==> Working
    #exp = "((12 * 0.05196) * COS (Degrees_To_Radians (30))) - (((75 - 45) * 0.088) * SIN (Degrees_To_Radians (30))) + (((85 - 40) * 0.088) * TAN (Degrees_To_Radians (30)))" # ==> Working
    #exp = "(((12 - 10) * 0.088) * COS (Degrees_To_Radians (30))) + ((12 * 0.05196) * SIN (Degrees_To_Radians (30)))" # ==> Working
    #exp = "sin(12 * (PI / 180)) * sin(20 * (PI / 180)) + (cos((25)*(PI / 180)) *cos(20 * (PI / 180)) * cos((12 - 10) * (PI / 180)))" # ==> Not Working

    # replace pi with its numerical value
    # Note: By default the trigonometric functions take radians as input, however if there is an explicit conversion
    #   of degree to radians by using (pi/180), then we will convert it to its corresponding values
    #   else the input of any trigonometric function will be considered as a RADIAN input only
    exp = exp.replace("(", " ( ").replace(")", " ) ").lower().replace("pi", str(math.pi))
    # exp = exp.replace("*", " * ").replace("/", " / ").replace("+"," + ").replace("-"," - ")

    expList = []
    intermediateExpList = []
    # check the parenthesis in the expression
    if(paren_checker(exp)): # Process the expression only when the parenthesis are matching
        # check if it is a trigonometric expression
        if " cos " in exp or " sin " in exp or " tan " in exp:

            print(expList)
            #input()

            # return code and result data
            [code, res ] = trigonometric(exp)

            if (code):# is evaluated, no need to break the logic statement
                print("Expression evaluated normally", str(res))
                return res
            else:
                # to explicitly take care of the stuffs when the angle provided is not in Radians
                exp = exp.replace('degrees_to_radians', '( pi / 180 ) * ').replace('rad', '( pi / 180 ) * ').replace("pi", str(math.pi))
                print(exp)

                # check if there are expressions which can be evaluated separately E.G.
                #   x = (A+B) - (D-E), where in (A+B) and (D-E) can be evaluated individually and can be used to calculated
                #       the final value
                intermediateExpList = breakLogicExpression(exp)

                print(intermediateExpList)
                #input()
        else:
            # directly evaluate the expression
            result = eval_expr(eliminateRedundantBraces(exp))
            print("*** Normal Expression = ", str(result))
            return result

        # process the result of the broken statements
        resList = [] # to store the results from intermediate expression
        if len(intermediateExpList) > 0:
            for c, ele in enumerate(intermediateExpList):
                # check if the expression being passed is starting with an operator
                if (str(ele).strip().startswith("+") or str(ele).strip().startswith("-") or
                        str(ele).strip().startswith("*") or str(ele).strip().startswith("/")):
                    # which ever element is there append it to resultList, so as to make a final evaluated expression
                    #   at last
                    ele = str(ele).strip()
                    resList.append(ele[0])
                    expLen = len(ele)
                    ele = ele[1:expLen-1]

                    # and pass the modified expression to calculate
                    [code, res] = trigonometric(ele)
                    print("****** Interm res 2 = ",str(res))
                    #input()
                    resList.append(res)
                else:
                    [code, res] = trigonometric(ele)
                    resList.append(res)

            # once all the intermediate list is parsed, evaluate the final simplified expression
            nspClass = NumericStringParser()
            print(resList)
            e = ' '.join(map(str,resList))
            print("**** Final Expression to be evaluated = ",e)
            # print("*** Final Result of Evaluated Exp =", str(eval_expr(e))) - Commented by Varun
            output = str(nspClass.eval(e))
            print("*** Final Result of Evaluated Exp =", output)
            return output
    else:
        err = "Mismatch in opening and closing braces. Check the expression"
        print(err)
        return err

    #print(" Calculated Value = " + str(eval_expr(exp)))
    #result = eval_expr(input('Enter an arithmetic expression: '))
    #print len(paraList)
if __name__ == "__main__":

    exp = sys.argv[1]
    path = sys.argv[2]

    #exp = "FMSEastWestMiles# = (FreezePos_Lon – Longitude) * 3437.74677 * (PI / 180) * cos((FreezePos_Lat) * (PI / 180))"
    #exp = "tactical_Output_ETOPS_Mode# = (ciocal_ETOPS_Enabled * 2) + (ciocal_ETOPS_Confirmed * 1)"
    #exp = "tactical_inavLateralMapHalfRangePilotSecFplan# = (RequestLateralMapHalfRange.LatMapHalfRangeKnobDelta +  tactical_inavLateralMapHalfRangePilotSecFplan)"
    #exp = "tactical_pfd2SvsBrightness# = tactical_pfd2SvsBrightness + 5 X SvBrightness.knobClicks"
    #exp = "FMSTotalMiles# = sin((FreezePos_Lat) * (PI / 180)) * sin(Latitude * (PI / 180)) + (cos((FreezePos_Lat)*(PI / 180)) *cos(Latitude * (PI / 180)) * cos((FreezePos_Lon – Longitude)*(PI / 180)))"
    #exp = "FMSTotalMiles# = 60 * arccos(sin((FreezePos_Lat) * (PI / 180)) * sin(Latitude * (PI / 180)) + (cos((FreezePos_Lat)*(PI / 180)) *cos(Latitude * (PI / 180)) * cos((FreezePos_Lon – Longitude)*(PI / 180))))"
    #exp = "FMSTotalMiles# = 60 * arcsin(sin((FreezePos_Lat) * (PI / 180)) * sin(Latitude * (PI / 180)) + (cos((FreezePos_Lat)*(PI / 180)) *cos(Latitude * (PI / 180)) * cos((FreezePos_Lon – Longitude)*(PI / 180))))"
    #exp = "FMSTotalMiles# = 60 * arctan(sin((FreezePos_Lat) * (PI / 180)) * sin(Latitude * (PI / 180)) + (cos((FreezePos_Lat)*(PI / 180)) *cos(Latitude * (PI / 180)) * cos((FreezePos_Lon – Longitude)*(PI / 180))))"
    #exp = "FMSTotalMiles# = 60*arctan(sin((FreezePos_Lat)*(PI/180))*sin(Latitude*(PI/180))+(cos((FreezePos_Lat)*(PI/180))*cos(Latitude*(PI/180))*cos((FreezePos_Lon–Longitude)*(PI/180))))"
    #exp = "tactical_Output_ETOPS_Mode# = (x+y)"

    # important to remove the encoded string
    exp = exp.replace(u'–', '-').replace(' X ',"*")
    exp = exp.replace('-',' - ').replace('*'," * ").replace("+"," + ").replace("/"," / ")
    print(exp.encode('utf-8'))

    # check if the path provided is a Valid Path
    if os.path.isdir(path):
        if os.path.isfile(path + r'\airthematic_Eval_out.txt'):
            os.unlink(path + r'\airthematic_Eval_out.txt')
    else:
        print("PATH DOES not exists. Taking Script Path")
        path = os.path.dirname(os.path.abspath(__file__))

    resultFile = open(path + r'\airthematic_Eval_out.txt', 'a')
    retValue = ""

    if (exp.count("(") == exp.count(")")):

        exp = exp.lower()
        outputVarList = []
        outputVar = str(exp.split("#")[0]).split("=")[0].strip()
        print(outputVar)
        outputVarList.append(outputVar)

        # store the initial expression, will be used at final replacement of variable with their corresponding values
        initExp = exp.split("=")[1].strip()
        print(initExp)

        exp = initExp
        exp = re.sub(r"\bcos\b", '', exp.lower())
        exp = re.sub(r"\bsin\b", '', exp.lower())
        exp = re.sub(r"\btan\b", '', exp.lower())
        exp = re.sub(r"\bpi\b", '', exp.lower())
        exp = re.sub(r"\brad\b", '', exp.lower())
        exp = re.sub(r"\barccos\b", '', exp.lower())
        exp = re.sub(r"\barcsin\b", '', exp.lower())
        exp = re.sub(r"\barctan\b", '', exp.lower())

        exp = str(exp).lower().replace("*", "").replace("+", "").replace("–", "").replace("/", "").replace("-", "")
        exp = exp.replace('degrees_to_radians', '')
        exp = exp.replace("(", "").replace(")", "").split(" ")

        varList = []
        # get the variables in the expression
        for cnt, data in enumerate(exp):
            if data == '':
                continue
            # check if the element is a numeric value
            try:
                if float(data) + 1.0:  # only possible when its a numerical value
                    continue
            except:
                if data not in varList:
                    varList.append(data)
        print("Expression = ", exp)
        print("Variables List = ", varList)

        # setting it to default range, will be used when the output variable is not found in heal File
        opMinrange = 0
        opMaxrange = 255
        opDataType = ""

        flagReadHealFile = False    # by default, assumed that we don't read the Heal File

        # get all the variables in a list
        try:
            varInFloatFile = [line.lower().split(",")[0].strip('"') for line in open(path + r"\FloatIntUInt.txt") if not ('busname' in line.lower())]

            # if we see that we are able to find the output Variable in Heal file, then calculate its range else
            #   assume its default range as [0-255] to calculate the value
            healFile = open(path + r"\FloatIntUInt.txt",'r')

            for line in healFile:
                if outputVar == line.lower().split(",")[0].strip('"'):
                    opDataType = line.split(",")[1].strip('"').lower()
                    opMinrange = line.split(",")[2]
                    opMaxrange = line.split(",")[3]
                    break
            healFile.close()
            print(varInFloatFile)

            print(opDataType)
            #print(lineInFloatFile)
            #input()
            # check if the variables present in expression are found in Heal file,
            #   if not, calculate on random value [0-255]
            diff = set(varList).difference(varInFloatFile)
            print(varList)

            outputDiff = set(outputVarList).difference(varInFloatFile)


            # implies that all the variables of expression are present in the Heal File
            if len(diff) == 0:
                flagReadHealFile = True

        except:
            print("Heal File is not found. Hence Taking default Ranges of output as [0-255]")
            # since we didn't found Heal file, due to any reason we will assume that the datatype of Variable is Int
            opDataType = "int"

        ret = createTruthTable(initExp.lower(), outputVar, varList, flagReadHealFile, opMinrange, opMaxrange, path, opDataType)

        cnt = 1
        while(ret.split(",")[1] == "Overflow") and cnt < 10000:  # assuming that it will calculate within 10000 iteration
            print(" Overflow Found, recalculating the expression ")

            # call it again
            ret = createTruthTable(initExp.lower(), outputVar, varList, flagReadHealFile, opMinrange, opMaxrange, path, opDataType)

            cnt+=1

        #print("# Number of Iterations to arrive at the value within range of Output Var", outputVar,"with Range[",
        #     str(opMinrange),",",str(opMaxrange),"] is = ", str(cnt),file=resultFile)

    else:
        resultFile.write("<Error> : Mismatch in opening and closing braces. Check the expression")

    resultFile.close()

    #startEval(exp.split("=")[1])
    #main()