import string
import os
import sys
import re
import shutil

fileListName = "C:/Vishwas/TASKS_ASSIGNED/TSC2_0/Python_Tools_TSC2/Create_TSp/FileList.txt"
fileList = open(fileListName, "r")

while True:
    fileLine = fileList.readline()
    lineLength = len(fileLine)
    if fileLine == '':
        break
    else:
        tsfFileNameWithExt = fileLine[0:17]
        tsfFileNameWithoutExt = fileLine[0:13]

        if (os.path.exists(tsfFileNameWithoutExt) != True):
            os.mkdir(tsfFileNameWithoutExt)

        if (os.path.exists("/" + tsfFileNameWithoutExt + "/" + tsfFileNameWithExt) != True):
            shutil.copyfile("C:/Vishwas/TASKS_ASSIGNED/TSC2_0/Python_Tools_TSC2/Create_TSp/" + tsfFileNameWithExt,
                            tsfFileNameWithoutExt + "/" + tsfFileNameWithExt)

        tsfFile = open(tsfFileNameWithoutExt + "/" + tsfFileNameWithExt, "r")
        tspFile = open(tsfFileNameWithoutExt + "/" + tsfFileNameWithoutExt + ".tsp", "w")
        configFile = open(tsfFileNameWithoutExt + "/" + "Config_file.txt", "w")

        tspFile.write("1.0\n")
        while True:
            tsfLine = tsfFile.readline()

            if ("DEFINE " in tsfLine):
                break
            else:
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\QualifiedSupport.tsf\n0, 1, 0\n")
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\ComConstantsAndFunctions.tsf\n0, 0, 0\n")
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\GGF_ComConstantsAndFunctions.tsf\n0, 0, 0\n")
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\MauCard.tsf\n0, 0, 0\n")
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\T2_ASCB_Mapping.tsf\n0, 0, 0\n")
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\T2_Touch_Automation.tsf\n0, 0, 0\n")
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\T2_HLR_Support_Functions.tsf\n0, 0, 0\n")
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\Support_Files\T2_WidgetTypeFunctions.tsf\n0, 0, 0\n")
                tspFile.write("\"C:\Vishwas\TASKS_ASSIGNED\TSC2_0\Python_Tools_TSC2\Create_TSp\"" + tsfFileNameWithExt + "\n0, 0, 0\n"")

        configFile.writelines(
            "<Config>\n<g__thisInstance_check>2</g__thisInstance_check>\n<g__thisInstance_path></g__thisInstance_path>\n<TestEnvironment>12</TestEnvironment>\n")
        configFile.writelines("<CtAuto></CtAuto>\n<CtAutoTarget></CtAutoTarget>\n")
        configFile.writelines("<EASE_WARM>2</EASE_WARM>\n<Software_Version>EDS_PRD_TSC2_00_001</Software_Version>\n")
        configFile.writelines(
            "<ExecutorName>Vishwas Krishna</ExecutorName>\n<VC_BCT_Flag_Enabled>1</VC_BCT_Flag_Enabled>\n<TargetName>tsc1</TargetName>\n")
        configFile.writelines(
            "<ResourceName>VECTOR_SPACE_TGF</ResourceName>\n<SC_Variable_Path>dtmon\TscGraphics\vcast_dump_coverage_exe</SC_Variable_Path>\n</Config>")
        # configFile.write(fileLine[18:lineLength])

        tsfFile.close()
        tspFile.close()
        configFile.close()

fileList.close()
