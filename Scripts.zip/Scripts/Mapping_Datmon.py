input = "C:\\Vishwas\\Task_Assigned\\Python\\Mapping\\TS_TGF_TFM_DatmonMapping.tsf"
output = "C:\\Vishwas\\Task_Assigned\\Python\\Mapping\\result.txt"
filein = open(input, "r")
fileout = open(output, "w")

for eachline in filein:
    if eachline.__contains__('['):
        if 'Dim' in eachline:
            arrayline = eachline.split('Dim')[1]
            arrayline = arrayline.split(':')[0]
        else:
            arrayline = eachline.split('=')[0]
        arrayline = arrayline.strip()
        arrayline = arrayline + '\n'
        fileout.write(arrayline)
        print(arrayline)