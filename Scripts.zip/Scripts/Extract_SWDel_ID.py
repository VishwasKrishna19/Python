import string
import os
import sys
import re
import xlsxwriter
import xlrd
import glob
import math
import datetime
#i = 0
#Irow = 0
#Icol = 0
#Filename = "Output_file"
#xlsname = Filename + "." + "xlsx"
#workbook = xlsxwriter.Workbook(xlsname)
#worksheet = workbook.add_worksheet()
source = sys.argv[1]
dir = source + "/" + '*'
files = glob.glob(dir)
log1 = open("out.txt",'w')
for file in files:
   #print f
   filename = file.rsplit('\\')
   print (filename)
   log = open(file, 'r')
   line = log.readline()
   log1.write(filename[-1])
   while line:
     if "SW Delivery ID" in line:
        log1.write(line)
        line = line.strip()
        #Icol = 0
        #worksheet.write(Irow, Icol, filename[3])
        #Icol += 1
        #worksheet.write(Irow, Icol+1, line)
        break
     line = log.readline()
   #Irow += 1
   log.close()
log1.close()

		
