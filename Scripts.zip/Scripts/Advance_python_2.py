#Json Pickle Generator and Decorator

#Json: Java Script Object Notation

# KeyValue pair, List
# {
#     "a": 1
#     "b": "abc"
#     "c": false
#      1: "Value"
# }

import json

json_file = r'C:\Users\H126313\PycharmProjects\Projects\Projects\test.json'

with open(json_file, "r"):
    print(json_file)