import csv
import os
import re

with open("C:/Users/h126313/Desktop/Python/TBIUpdater/T2L_TFMB_0170.sum") as f:
    with open("C:/Users/h126313/Desktop/Python/TBIUpdater/T2L_TFMB_0170.tbi", 'w') as wf:
        parsing = False
        for line in f:
            if line.__contains__("Analysis Details"): # Or whatever test is needed
                parsing = False
                # Reads text until the end of the block:
            if line.__contains__("Justification for Test By Inspection"):
                parsing = True
            if parsing:
                wf.write(line)
