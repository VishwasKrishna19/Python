# Given the below class:
class Cat:
    species = 'mammal'

    def __init__(self, name, age):
        self.name = name
        self.age = age

# 1 Instantiate the Cat object with 3 cats
obj1 = Cat("Cat1", 2)
obj2 = Cat("Cat2", 3)
obj3 = Cat("Cat3", 4)

# 2 Create a function that finds the oldest cat
def getoldesetcat(*args):
    return max(args)

# 3 Print out: "The oldest cat is x years old.". x will be the oldest cat age by using the function in #2
print(f'The oldest cat is {getoldesetcat(obj1.age, obj2.age, obj3.age)} Years old')