result = "Hello World!".isalnum()
print(result)

result = "Hello World!".isalpha()
print(result)

result = "hello".islower()
print(result)

result = "HELLO".isupper()
print(result)

result = "Hello World!".istitle()
print(result)

result = " 	".isspace()
print(result)

result = "5.5".isdigit()
print(result)

result = "5.5".isdecimal()
print(result)

result = "5.55".isnumeric()
print(result)

result = "hello".startswith("h")
print(result)

result = "hello".endswith("o")
print(result)