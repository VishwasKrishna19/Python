import os
import re

with open("C:/Users/h126313/Desktop/Python/Req_Format/req_text.txt", 'r',encoding="utf-8") as req_doors:
    with open("C:/Users/h126313/Desktop/Python/Req_Format/req_Doors_Detail.txt", 'w', newline='', encoding="utf-8") as Req_Detail:
        for line in req_doors:
            line = line.rstrip('\n')
            print(line)
            if line.startswith('TSC_2_HLR_'):
                #regex = re.findall('TSC_2_HLR_([0-9]+)', line)
                Regex = line.split('TSC_2_HLR_')[1]
                #regex = "".join(regex)
                #print(regex)
                line = line + ',' + '/EPIC_2_TSC/4_Item/Software/HLR/TSC2_HLR' + ',' + Regex + '\n'
            if line.__contains__('_TINK_') and line.__contains__('LLR'):
                if line.startswith('TSC2_LLR_UDPAGM_TINK_'):
                    Regex = line.split('_TINK_')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TSC_001_Appx_A_UDPAGM_Tink' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_UDPTSC_TINK'):
                    Regex = line.split('_TINK')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TSC_001_Appx_D_UDPTSC_Tink' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TFM_TINK_'):
                    Regex = line.split('_TINK_')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TSC_001_Appx_F_TFM_Tink' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TGF_TINK_'):
                    Regex = line.split('_TINK_')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TSC_001_Appx_C_TGF_Tink' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_UDPAGM_PIXIE_'):
                    Regex = line.split('_PIXIE_')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TSC_001_Appx_B_UDPAGM_Pixie' + ',' + Regex + '\n'
            if line.__contains__('LLR'):
                if line.startswith('TSC2_LLR_TGF_Checklist'):
                    Regex = line.split('TSC2_LLR_TGF_Checklist')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TGF_Checklist' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TGF_Others'):
                    Regex = line.split('TSC2_LLR_TGF_Others')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TGF_Others' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TGF_FMS_PERF'):
                    Regex = line.split('TSC2_LLR_TGF_FMS_PERF')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TGF_FMS_PERF' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TGF_TUI_'):
                    Regex = line.split('TSC2_LLR_TGF_TUI_')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TGF_TUI' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TGF_Datalink'):
                    Regex = line.split('TSC2_LLR_TGF_Datalink')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TGF_Datalink' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_UDPAGM'):
                    Regex = line.split('TSC2_LLR_UDPAGM')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/UDPAGM' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_UDPTSC'):
                    Regex = line.split('TSC2_LLR_UDPTSC')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/UDPTSC' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TGF_General_Ext'):
                    Regex = line.split('TSC2_LLR_TGF_General_Ext')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TGF_General_Ext' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TGF_General'):
                    Regex = line.split('TSC2_LLR_TGF_General')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TGF_General' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TFM'):
                    Regex = line.split('TSC2_LLR_TFM')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TFM' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TGF_Radios'):
                    Regex = line.split('TSC2_LLR_TGF_Radios')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TGF_Radios' + ',' + Regex + '\n'
                if line.startswith('TSC2_LLR_TscUdpLib'):
                    Regex = line.split('TSC2_LLR_TscUdpLib')[1]
                    print(Regex)
                    line = line + ',' + '/EPIC_2_TSC/4_Item/Software/LLR/TscUdpLib' + ',' + Regex + '\n'

            Req_Detail.write(line)