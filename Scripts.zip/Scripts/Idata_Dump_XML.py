from lxml import etree
from io import StringIO, BytesIO

inputxml = input("Give the XML Path: ")
print(inputxml)

root = tree = etree.parse(StringIO(inputxml))
etree.tostring(tree.getroot())