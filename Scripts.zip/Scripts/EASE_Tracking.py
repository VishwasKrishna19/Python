#*********************************************************************************#
#Author : Vishwas Krishna
#Date	: 24 Mar 2020
#Purpose: To create the EASE Tracking sheet from the summaries
#*********************************************************************************#

import os
import csv
import codecs

sumread = input("Drag and Drop the folder Containing Sum files: ")
os.getcwd()
Test_Name = ""
object_ID = ""
listdata = []

def Remove(duplicate):
    final_list = []
    for num in duplicate:
        if num not in final_list:
            final_list.append(num)
    return final_list

if os.path.exists('EASE_Tracking.csv'): os.remove('EASE_Tracking.csv')
with open("EASE_Tracking.csv", 'a', newline='', encoding="utf-8") as traceout:
    w = csv.writer(traceout)
    w.writerow(["File_Name", "Test_Name",  "Object_ID", "EASE_BENCH"])
    for root, dirs, files in os.walk(sumread):
        for file in files:
            if file.endswith(".sum") or file.endswith(".tbi"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as sum:
                    for line in sum:
                        if line.startswith("**      Test Station being used is:"):
                            EASE_BENCH = line.split(":")[1]
                            EASE_BENCH = EASE_BENCH.strip()
                            EASE_BENCH_Data = "Yes"
                            if EASE_BENCH == "IE4LLB5AEDT0021" or EASE_BENCH == "AZ75TSDT316" : #Hardcode the Bench Details
                                EASE_BENCH_Data = "NO"
                        if line.__contains__('[TP_'):
                            object_ID = line.split("::")[2]
                            object_ID = object_ID.split("]")[0]
                        if line.__contains__('TestName') and line.__contains__(":"):
                            Test_Name = line.split(":")[1]
                            Test_Name = Test_Name.strip()
                            sumname = sum.name
                            sumname = sumname.split('\\')[-1]
                            print(sumname)
                        if Test_Name != "" and object_ID != "":
                            outdata = sumname + ";" + Test_Name + ";" + object_ID + ";" + EASE_BENCH_Data
                            listdata.append(outdata)

        #print(listdata)
        finallsit = Remove(listdata)
        #print(finallsit)
        for eachelement in finallsit:
            sumname_Final = eachelement.split(";")[0]
            Test_Name_Final = eachelement.split(";")[1]
            object_ID_final = eachelement.split(";")[2]
            EASE_BENCH_Data_final = eachelement.split(";")[3]
            finaldata = sumname_Final + "," + Test_Name_Final + "," + object_ID_final + "," + EASE_BENCH_Data_final + "\n"
            traceout.write(finaldata)
