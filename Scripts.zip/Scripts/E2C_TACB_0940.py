import InitialSupport

from InitialSupport import *
TestName = "E2C_TACB_0940"
Startsum(TestName)
#========================================================================================
# CONTROL ABSTRACTION LAYER FUNCTION SOFTWARE TEST PLAN/PROCEDURES
Output ("================================================================================")
Output ("TestName        : E2C_TACB_0940")
Output ("================================================================================")
Output ("================================================================================")
Output ("				MODIFICATION HISTORY")
Output ("================================================================================")
Output ("Version   Date           Author              Change Description       CH_DOC")
Output ("-------   ----           ------              ------------------       -------")
Output ("01        18-May-17      Avinash             Load 3.5: Initial          EDS_CALF_EJETE2_VR_1135")
Output ("                                             Development                                       ")
Output ("================================================================================")
#========================================================================================
#                                TEST ENVIRONMENT SPECIFICATION
#========================================================================================
#
#========================================================================================
#					GENERAL COMMENTS
#----------------------------------------------------------------------------------------
#The delay used before verify statement is due to faster execution of test steps on Windows computer where the test file is executed than the inputs sent to target system via ASCB bus based on the scheduling as per requirements.
#This inclusion of delay in no way impact the actual outputs but only supports in accurate comparison of actual and expected output.
#========================================================================================
#				GENERAL SET-UP COMMANDS
#----------------------------------------------------------------------------------------
#The following files are included in the project, and they will occur in the following order:
#	1. QualifiedSupport.tsf
#	2. ComConstantsAndFunctions.tsf
#	3. E2C_TACTICAL_ASCB_Mapping.tsf
#	4. calftac_Vars_DatMon.tsf
#	5. Control_com_Init.tsf
#	6. DebounceTestingConstantsAndFunctions.tsf
#	7. E2C_TACB_0940.tsf

#========================================================================================
#					DEFINE VARIABLES
#----------------------------------------------------------------------------------------
global WriteDelay
global ReadDelay
global g__thisInstance_1
global TestNum
global TestCase
global TestNumber
global Current_Index
global Current_Valid
global Current_Changed
global Expected_Index
global Expected_Valid
global Expected_Changed
global Max
global MaxMinus
global Min
global MinPlus
global MidVal
global TemplateClass
global foundValidSource
global source_index
global valid_index
global current_source
global Config_NumberofSources 
global Config_UsePreferredSource
global Config_NoneoftheAboveAvail
global Config_ManualOverrideAvail
global Input_ManualOverrideActive
global Input_OverrideIndex
global Config_DynamicOrderingAvail
global Input_DynamicOrder(2 )
global SOURCE_1
global SOURCE_2
global Input_Valid( 2 )
#----------------------------------------------------------------------------------------

#========================================================================================
#					INITIAL CONDITIONS
#----------------------------------------------------------------------------------------
ObjectID_Level_Test() # Object ID level testing
Output ("")

#***********************************************************************

WriteDelay = 2
ReadDelay = 2

#--------- Constant Definitions -------

SOURCE_1 = 0
SOURCE_2 = 1

#--------- Global Variable Data Definitions for Internal Constants -------

SS_VerifyReadReturnValue(g__thisInstance, g__thisInstance_1)

Output ("g__thisInstance = ")



########################################################################
########################################################################

# Initialization subroutines for:
#	Process Name:	Control
#	Glossary Term:	ciocal_TcasSourceSel

########################################################################
########################################################################



#***************** Sub Set_Invalid_Control_ciocal_TcasSourceSel ********************


def Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)

	#Set all source variables to invalid values

	Set_Invalid_Control_ciocal_TcasSourceSel_1(TestNum)

	Set_Invalid_Control_ciocal_TcasSourceSel_2(TestNum)


 #Set_Invalid_Control_ciocal_TcasSourceSel



#***************** Sub Set_Valid_Control_ciocal_TcasSourceSel_1 ********************


def Set_Valid_Control_ciocal_TcasSourceSel_1(TestNum)

	#Set all SOURCE_1 variables to valid values
	VerifyWrite ( ciocal_TcasControl_Good_1, 3, TestNum )
	VerifyWrite ( ciocal_TcasControlStatus_Valid_1, 1, TestNum )
Delay WriteDelay

 #Set_Valid_Control_ciocal_TcasSourceSel_1




#***************** Sub Set_Invalid_Control_ciocal_TcasSourceSel_1 ********************


def Set_Invalid_Control_ciocal_TcasSourceSel_1(TestNum)

	#Set all SOURCE_1 variables to invalid values
	VerifyWrite ( ciocal_TcasControl_Good_1, 0, TestNum )
	VerifyWrite ( ciocal_TcasControlStatus_Valid_1, 0, TestNum )
Delay WriteDelay


 #Set_Invalid_Control_ciocal_TcasSourceSel_1




#***************** Sub Set_Valid_Control_ciocal_TcasSourceSel_2 ********************


def Set_Valid_Control_ciocal_TcasSourceSel_2(TestNum)

	#Set all SOURCE_2 variables to valid values
	VerifyWrite ( ciocal2_TcasControl_Good_1, 3, TestNum )
	VerifyWrite ( ciocal2_TcasControlStatus_Valid_1, 1, TestNum )
Delay WriteDelay

 #Set_Valid_Control_ciocal_TcasSourceSel_2




#***************** Sub Set_Invalid_Control_ciocal_TcasSourceSel_2 ********************


def Set_Invalid_Control_ciocal_TcasSourceSel_2(TestNum)

	#Set all SOURCE_2 variables to invalid values
	VerifyWrite ( ciocal2_TcasControl_Good_1, 0, TestNum )
	VerifyWrite ( ciocal2_TcasControlStatus_Valid_1, 0, TestNum )
Delay WriteDelay


 #Set_Invalid_Control_ciocal_TcasSourceSel_2


########################################################################
########################################################################




#	-------------------------------------------Truth Table-------------------------------------------------------
#	
#	
#	Given Input:
#	ciocal1_TcasControl_Good =   #fresh and valid#   AND  ciocal1_TcasControlStatus_Valid =   #valid#   
#	
#	Processed Input:
#	( ciocal1_TcasControl_Good =   #fresh and valid#   AND  ciocal1_TcasControlStatus_Valid =   #valid#    )
#	
#	Key:
#	A | ( ciocal1_TcasControl_Good=#fresh and valid# )
#	B | ( ciocal1_TcasControlStatus_Valid=#valid# )
#	
#	Test Cases:
#	##| A  B  | = Output
#	------------
#	1 | T  T  | T (Index = 0, Validity = 1)
#	2 | T  F  | F (Index = 0, Validity = 0)
#	3 | F  T  | F (Index = 0, Validity = 0)
#	4 | F  F  | F (Index = 0, Validity = 0)

#********************* Test Case Subprogram Definition ***********************


def ciocal_TcasSourceSel_1_TestCases ( )

TestNumber = 0


#Parameter Value Settings

#Parameter: 1
#	TestNum
#		ciocal_TcasSourceSel_1-1 - ciocal_TcasSourceSel_1-TotalTestCases
#Parameter: 2
#	ciocal1_TcasControl_Good
#		invalid and stale = 0
#		valid but stale = 1
#		fresh but invalid = 2
#		fresh and valid = 3
#Parameter: 3
#	ciocal1_TcasControlStatus_Valid
#		Invalid = 0
#		Valid = 1

TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a1::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a1::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_1 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_1-1", 3, 1 )
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a2::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a2::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_1 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_1-2", 3, 0 )
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a3::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a3::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_1 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_1-3", 0, 1 )
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a4::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a4::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_1 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_1-4", 0, 0 )
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a5::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a5::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_1 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_1-5", 1, 1 ) # Robustness test case - Coverage: ciocal1_TcasControl_Good
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a6::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a6::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_1 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_1-6", 2, 1 ) # Robustness test case - Coverage: ciocal1_TcasControl_Good


 # ciocal_TcasSourceSel_1_TestCases



#********************* Subprogram Definition ***********************


def ciocal_TcasSourceSel_1 ( TestNum , VALUE_0, VALUE_1 )


	#Parameter value settings:
	#	VALUE_0 = ciocal1_TcasControl_Good
	#	VALUE_1 = ciocal1_TcasControlStatus_Valid

#---------------Initialize Input Logic to Invalid ---------------


Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)




#--------------- Get Current Source Selection Outputs ---------------


Delay ReadDelay

SS_VerifyReadReturnValue ( g_ciocal_TcasSourceSel__Index, Current_Index )

SS_VerifyReadReturnValue( g_ciocal_TcasSourceSel__Valid, Current_Valid )

SS_VerifyReadReturnValue( g_ciocal_TcasSourceSel__Changed, Current_Changed)



#--------------- Initialize Validity Array ---------------


#Source Selection Logic =
#  ciocal1_TcasControl_Good  = #fresh and valid# AND  ciocal1_TcasControlStatus_Valid = #valid#




If ( VALUE_0 =   3  AND  VALUE_1 =   1   ):
	Input_Valid (0) = 1
Else
	Input_Valid (0) = 0
#End If


Input_Valid (1) = 0



#--------------- Determine SelectedSource Results ---------------




Config_ManualOverrideAvail = False
Input_ManualOverrideActive = False
Input_OverrideIndex = 0


Config_DynamicOrderingAvail = False

foundValidSource = False

source_index = 0

valid_index = 0

current_source = Current_Index

Config_NumberofSources = 1 # set to number-of-sources - 1 since sources go from 0-x

Config_UsePreferredSource = False
Config_NoneoftheAboveAvail = False

If (Config_ManualOverrideAvail And ( Input_ManualOverrideActive )): 
	Expected_Index =  Input_OverrideIndex
Else 

	If (Not (Current_Valid = 1)  Or Config_UsePreferredSource ): 
		foundValidSource = False

			#starts at 0 because _index values go from 0-7 (max)
		For source_index = 0 To Config_NumberofSources

			If ( Config_DynamicOrderingAvail ):
				valid_index = Input_DynamicOrder(source_index)
			Else
				valid_index = source_index
			#End If

			If ( Input_Valid(valid_index) = 1 ):
				Expected_Index = valid_index
				foundValidSource = True
				Exit For
			#End If
		Next

		If (NOT (foundValidSource )):

			If ( Config_NoneoftheAboveAvail ):

				If ( Config_DynamicOrderingAvail ):
					valid_index = Input_DynamicOrder(Config_NumberofSources)
				Else
					valid_index = Config_NumberofSources
				#End If

				Expected_Index = valid_index
			Else
				Expected_Index = current_source
			#End If
		#End If

	Else
		Expected_Index = current_source
	#End If

#End If

Expected_Valid = Input_Valid( Expected_Index )

If ( current_source = Expected_Index ):
	Expected_Changed = 0  #false
Else 
	Expected_Changed = 1  #true
#End If 


#--------------- Source Selection Inputs ---------------


VerifyWrite ( ciocal_TcasControlStatus_Valid_1, VALUE_1, TestNum )
VerifyWrite ( ciocal_TcasControl_Good_1, VALUE_0, TestNum )
Delay WriteDelay


#--------- Comparison of Actual VS Expected Outputs -------

Delay ReadDelay


SS_VerifyReadChkValue( g_ciocal_TcasSourceSel__Index, Expected_Index, 0, TestNum )


SS_VerifyReadChkValue( g_ciocal_TcasSourceSel__Valid, Expected_Valid, 0, TestNum )


If Expected_Changed = 1:
     SetPulseStart_Internal(g_ciocal_TcasSourceSel__Changed, 0, 4, 0)
Else
     SetNoChangeStart_Internal(g_ciocal_TcasSourceSel__Changed, 4)
#End If

If (Expected_Changed = 1):
     ValidatePulseEnd_Internal(4, 1, 12.5, g_ciocal_TcasSourceSel__Changed)
Else
     ValidateNoChangeEnd_Internal(4, 0, g_ciocal_TcasSourceSel__Changed)
#End If



 # ciocal_TcasSourceSel_1



#******************* End Subprogram Definition ***********************





#	-------------------------------------------Truth Table-------------------------------------------------------
#	
#	
#	Given Input:
#	ciocal2_TcasControl_Good =   #fresh and valid#   AND  ciocal2_TcasControlStatus_Valid =   #valid#   
#	
#	Processed Input:
#	( ciocal2_TcasControl_Good =   #fresh and valid#   AND  ciocal2_TcasControlStatus_Valid =   #valid#    )
#	
#	Key:
#	A | ( ciocal2_TcasControl_Good=#fresh and valid# )
#	B | ( ciocal2_TcasControlStatus_Valid=#valid# )
#	
#	Test Cases:
#	##| A  B  | = Output
#	------------
#	1 | T  T  | T (Index = 1, Validity = 1)
#	2 | T  F  | F (Index = 1, Validity = 0)
#	3 | F  T  | F (Index = 1, Validity = 0)
#	4 | F  F  | F (Index = 1, Validity = 0)

#********************* Test Case Subprogram Definition ***********************


def ciocal_TcasSourceSel_2_TestCases ( )

TestNumber = 0


#Parameter Value Settings

#Parameter: 1
#	TestNum
#		ciocal_TcasSourceSel_2-1 - ciocal_TcasSourceSel_2-TotalTestCases
#Parameter: 2
#	ciocal2_TcasControl_Good
#		invalid and stale = 0
#		valid but stale = 1
#		fresh but invalid = 2
#		fresh and valid = 3
#Parameter: 3
#	ciocal2_TcasControlStatus_Valid
#		Invalid = 0
#		Valid = 1

TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a7::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a7::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_2 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_2-1", 3, 1 )
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a8::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a8::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_2 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_2-2", 3, 0 )
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a9::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a9::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_2 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_2-3", 0, 1 )
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a10::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a10::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_2 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_2-4", 0, 0 )
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a11::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a11::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_2 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_2-5", 1, 1 ) # Robustness test case - Coverage: ciocal2_TcasControl_Good
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a12::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a12::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_2 ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_2-6", 2, 1 ) # Robustness test case - Coverage: ciocal2_TcasControl_Good


 # ciocal_TcasSourceSel_2_TestCases



#********************* Subprogram Definition ***********************


def ciocal_TcasSourceSel_2 ( TestNum , VALUE_0, VALUE_1 )


	#Parameter value settings:
	#	VALUE_0 = ciocal2_TcasControl_Good
	#	VALUE_1 = ciocal2_TcasControlStatus_Valid

#---------------Initialize Input Logic to Invalid ---------------


Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)




#--------------- Get Current Source Selection Outputs ---------------


Delay ReadDelay

SS_VerifyReadReturnValue ( g_ciocal_TcasSourceSel__Index, Current_Index )

SS_VerifyReadReturnValue( g_ciocal_TcasSourceSel__Valid, Current_Valid )

SS_VerifyReadReturnValue( g_ciocal_TcasSourceSel__Changed, Current_Changed)



#--------------- Initialize Validity Array ---------------


#Source Selection Logic =
#  ciocal2_TcasControl_Good  = #fresh and valid# AND  ciocal2_TcasControlStatus_Valid = #valid#




Input_Valid (0) = 0

If ( VALUE_0 =   3  AND  VALUE_1 =   1   ):
	Input_Valid (1) = 1
Else
	Input_Valid (1) = 0
#End If




#--------------- Determine SelectedSource Results ---------------




Config_ManualOverrideAvail = False
Input_ManualOverrideActive = False
Input_OverrideIndex = 0


Config_DynamicOrderingAvail = False

foundValidSource = False

source_index = 0

valid_index = 0

current_source = Current_Index

Config_NumberofSources = 1 # set to number-of-sources - 1 since sources go from 0-x

Config_UsePreferredSource = False
Config_NoneoftheAboveAvail = False

If (Config_ManualOverrideAvail And ( Input_ManualOverrideActive )): 
	Expected_Index =  Input_OverrideIndex
Else 

	If (Not (Current_Valid = 1)  Or Config_UsePreferredSource ): 
		foundValidSource = False

			#starts at 0 because _index values go from 0-7 (max)
		For source_index = 0 To Config_NumberofSources

			If ( Config_DynamicOrderingAvail ):
				valid_index = Input_DynamicOrder(source_index)
			Else
				valid_index = source_index
			#End If

			If ( Input_Valid(valid_index) = 1 ):
				Expected_Index = valid_index
				foundValidSource = True
				Exit For
			#End If
		Next

		If (NOT (foundValidSource )):

			If ( Config_NoneoftheAboveAvail ):

				If ( Config_DynamicOrderingAvail ):
					valid_index = Input_DynamicOrder(Config_NumberofSources)
				Else
					valid_index = Config_NumberofSources
				#End If

				Expected_Index = valid_index
			Else
				Expected_Index = current_source
			#End If
		#End If

	Else
		Expected_Index = current_source
	#End If

#End If

Expected_Valid = Input_Valid( Expected_Index )

If ( current_source = Expected_Index ):
	Expected_Changed = 0  #false
Else 
	Expected_Changed = 1  #true
#End If 


#--------------- Source Selection Inputs ---------------


VerifyWrite ( ciocal2_TcasControlStatus_Valid_1, VALUE_1, TestNum )
VerifyWrite ( ciocal2_TcasControl_Good_1, VALUE_0, TestNum )
Delay WriteDelay


#--------- Comparison of Actual VS Expected Outputs -------

Delay ReadDelay


SS_VerifyReadChkValue( g_ciocal_TcasSourceSel__Index, Expected_Index, 0, TestNum )


SS_VerifyReadChkValue( g_ciocal_TcasSourceSel__Valid, Expected_Valid, 0, TestNum )


If Expected_Changed = 1:
     SetPulseStart_Internal(g_ciocal_TcasSourceSel__Changed, 0, 4, 0)
Else
     SetNoChangeStart_Internal(g_ciocal_TcasSourceSel__Changed, 4)
#End If

If (Expected_Changed = 1):
     ValidatePulseEnd_Internal(4, 1, 12.5, g_ciocal_TcasSourceSel__Changed)
Else
     ValidateNoChangeEnd_Internal(4, 0, g_ciocal_TcasSourceSel__Changed)
#End If



 # ciocal_TcasSourceSel_2



#******************* End Subprogram Definition ***********************





#	-------------------------------------------Truth Table-------------------------------------------------------
#  Note : Verifying General Source Selection Algorithm with multiple Sources.
#	
#	
#	Given Input:
#	( Validity_1 , Validity_2 ) 
#	
#	Processed Input:
#	( ( Validity_1 , Validity_2 )  )
#	
#	Key:
#	A | ( Validity_1 )
#	B | ( Validity_2 )
#	
#	Test Cases:
#	##| A  B | = Output
#	------------
#	1 | F  F | F  (Index = #Previous Index#, Validity = 0)
#	2 | F  T | T  (Index = 1, Validity = 1)
#	3 | T  T | T  (Index = 0, Validity = 1)

#********************* Test Case Subprogram Definition ***********************


def ciocal_TcasSourceSel_General_TestCases ( )

TestNumber = 0


#Parameter Value Settings

#Parameter: 1
#	TestNum
#		ciocal_TcasSourceSel_General-1 - ciocal_TcasSourceSel_General-TotalTestCases
#Parameter: 2
#	Validity_1
#		Invalid = 0
#		Valid = 1
#Parameter: 3
#	Validity_2
#		Invalid = 0
#		Valid = 1

TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a13::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a13::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_General ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_General-1", 0, 0 ) 
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a14::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a14::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_General ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_General-2", 0, 1 ) 
TestNumber = TestNumber + 1
Output (" ")
Output ("[TP_1::TC a15::SDD_CALF_9951] -   SSAutoGeneratedTest")
Output ("[TP_1::TC a15::DISPLAYS_SW_HLR_12388924] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
ciocal_TcasSourceSel_General ( "TestCase " & TestNumber & " "&   "ciocal_TcasSourceSel_General-3", 1, 1 ) 


 # ciocal_TcasSourceSel_General_TestCases



#********************* Subprogram Definition ***********************


def ciocal_TcasSourceSel_General ( TestNum , VALUE_0, VALUE_1 )


	#Parameter value settings:
	#	VALUE_0 = Validity_1
	#	VALUE_1 = Validity_2

#---------------Initialize Input Logic to Invalid ---------------


Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)




#--------------- Get Current Source Selection Outputs ---------------


Delay ReadDelay

SS_VerifyReadReturnValue ( g_ciocal_TcasSourceSel__Index, Current_Index )

SS_VerifyReadReturnValue( g_ciocal_TcasSourceSel__Valid, Current_Valid )

SS_VerifyReadReturnValue( g_ciocal_TcasSourceSel__Changed, Current_Changed)




If ( VALUE_0 = 1 ):
	Input_Valid (0) = 1
Else
	Input_Valid (0) = 0
#End If

If ( VALUE_1 = 1 ):
	Input_Valid (1) = 1
Else
	Input_Valid (1) = 0
#End If



#--------------- Determine SelectedSource Results ---------------




Config_ManualOverrideAvail = False
Input_ManualOverrideActive = False
Input_OverrideIndex = 0


Config_DynamicOrderingAvail = False

foundValidSource = False

source_index = 0

valid_index = 0

current_source = Current_Index

Config_NumberofSources = 1 # set to number-of-sources - 1 since sources go from 0-x

Config_UsePreferredSource = False
Config_NoneoftheAboveAvail = False

If (Config_ManualOverrideAvail And ( Input_ManualOverrideActive )): 
	Expected_Index =  Input_OverrideIndex
Else 

	If (Not (Current_Valid = 1)  Or Config_UsePreferredSource ): 
		foundValidSource = False

			#starts at 0 because _index values go from 0-7 (max)
		For source_index = 0 To Config_NumberofSources

			If ( Config_DynamicOrderingAvail ):
				valid_index = Input_DynamicOrder(source_index)
			Else
				valid_index = source_index
			#End If

			If ( Input_Valid(valid_index) = 1 ):
				Expected_Index = valid_index
				foundValidSource = True
				Exit For
			#End If
		Next

		If (NOT (foundValidSource )):

			If ( Config_NoneoftheAboveAvail ):

				If ( Config_DynamicOrderingAvail ):
					valid_index = Input_DynamicOrder(Config_NumberofSources)
				Else
					valid_index = Config_NumberofSources
				#End If

				Expected_Index = valid_index
			Else
				Expected_Index = current_source
			#End If
		#End If

	Else
		Expected_Index = current_source
	#End If

#End If

Expected_Valid = Input_Valid( Expected_Index )

If ( current_source = Expected_Index ):
	Expected_Changed = 0  #false
Else 
	Expected_Changed = 1  #true
#End If 


#--------------- Initialize General Logic ---------------




If ( VALUE_0 = 1):
	Set_Valid_Control_ciocal_TcasSourceSel_1(TestNum)
Delay (0.2)
Else
	Set_Invalid_Control_ciocal_TcasSourceSel_1(TestNum)
#End If


If ( VALUE_1 = 1):
	Set_Valid_Control_ciocal_TcasSourceSel_2(TestNum)
Delay (0.2)
Else
	Set_Invalid_Control_ciocal_TcasSourceSel_2(TestNum)
#End If




#--------- Comparison of Actual VS Expected Outputs -------

Delay ReadDelay


SS_VerifyReadChkValue( g_ciocal_TcasSourceSel__Index, Expected_Index, 0, TestNum )


SS_VerifyReadChkValue( g_ciocal_TcasSourceSel__Valid, Expected_Valid, 0, TestNum )


If Expected_Changed = 1:
     SetPulseStart_Internal(g_ciocal_TcasSourceSel__Changed, 0, 4, 0)
Else
     SetNoChangeStart_Internal(g_ciocal_TcasSourceSel__Changed, 4)
#End If

If (Expected_Changed = 1):
     ValidatePulseEnd_Internal(4, 1, 12.5, g_ciocal_TcasSourceSel__Changed)
Else
     ValidateNoChangeEnd_Internal(4, 0, g_ciocal_TcasSourceSel__Changed)
#End If



 # GeneralSourceSelection



#******************* End Subprogram Definition ***********************

def ciocal_TcasSourceSel_DataMap_TestCases()


	#Test Data Maps for Source 1

	TestNum = "DataMaps_Source_1"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_1(TestNum)
Delay (0.2)

	CompareDataMaps_Source_ciocal_TcasSourceSel_1(TestNum)

	#Test Data Maps for Source 2

	TestNum = "DataMaps_Source_2"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_2(TestNum)
Delay (0.2)

	CompareDataMaps_Source_ciocal_TcasSourceSel_2(TestNum)

#Parameter Group Statuses Robustness Test Cases

	#Test Data Maps for Source 1

	TestNum = "DataMaps_Source_1_Robustness"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_1(TestNum)
Delay (0.2)

	PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_0(TestNum)

	#Test Data Maps for Source 2

	TestNum = "DataMaps_Source_2_Robustness"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_2(TestNum)
Delay (0.2)

	PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_0(TestNum)

#Parameter Group Statuses Robustness Test Cases

	#Test Data Maps for Source 1

	TestNum = "DataMaps_Source_1_Robustness"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_1(TestNum)
Delay (0.2)

	PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_1(TestNum)

	#Test Data Maps for Source 2

	TestNum = "DataMaps_Source_2_Robustness"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_2(TestNum)
Delay (0.2)

	PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_1(TestNum)

#Parameter Group Statuses Robustness Test Cases

	#Test Data Maps for Source 1

	TestNum = "DataMaps_Source_1_Robustness"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_1(TestNum)
Delay (0.2)

	PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_2(TestNum)

	#Test Data Maps for Source 2

	TestNum = "DataMaps_Source_2_Robustness"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_2(TestNum)
Delay (0.2)

	PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_2(TestNum)

#Parameter Group Statuses Robustness Test Cases

	#Test Data Maps for Source 1

	TestNum = "DataMaps_Source_1_Robustness"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_1(TestNum)
Delay (0.2)

	PGS_DataMapsTestCases_ciocal_TcasSourceSel_1_3(TestNum)

	#Test Data Maps for Source 2

	TestNum = "DataMaps_Source_2_Robustness"

	Set_Invalid_Control_ciocal_TcasSourceSel(TestNum)
Delay (0.2)

	Set_Valid_Control_ciocal_TcasSourceSel_2(TestNum)
Delay (0.2)

	PGS_DataMapsTestCases_ciocal_TcasSourceSel_2_3(TestNum)


 # ciocal_TcasSourceSel_DataMap_TestCases



#******************* End Subprogram Definition ***********************



#--------- Comparison of Data Maps -------




#********************* Subprogram Definition ***********************


def CompareDataMaps_Source_ciocal_TcasSourceSel_1 ( TestNum  )


	#Parameter value settings:

	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )
	# Writing glossary term ciocal_AdsbInStatus to its sources

	 # Writing ciocal_AdsbInStatus to source 2
	 VerifyWrite ( ciocal2_AdsbInStatus_1, 0, TestNum )

	 # Writing ciocal_AdsbInStatus to source 1
Output (" ")
Output ("[TP_1::TC a16::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AdsbInStatus_1, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AdsbInStatus, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a17::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AdsbInStatus_1, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AdsbInStatus, 1, 0, TestNum )

	# Writing glossary term ciocal_AvailabilityOfAirb to its sources

	 # Writing ciocal_AvailabilityOfAirb to source 2
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 0, TestNum )

	 # Writing ciocal_AvailabilityOfAirb to source 1
Output (" ")
Output ("[TP_1::TC a18::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a19::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 1, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a20::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 2, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 2, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a21::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 3, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a22::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 4, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 4, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a23::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 5, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 5, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a24::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 6, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 6, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a25::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 7, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 7, 0, TestNum )

	# Writing glossary term ciocal_AvailabilityOfSurf to its sources

	 # Writing ciocal_AvailabilityOfSurf to source 2
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 0, TestNum )

	 # Writing ciocal_AvailabilityOfSurf to source 1
Output (" ")
Output ("[TP_1::TC a26::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a27::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 1, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a28::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 2, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 2, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a29::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 3, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a30::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 4, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 4, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a31::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 5, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 5, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a32::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 6, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 6, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a33::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 7, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 7, 0, TestNum )

	# Writing glossary term ciocal_AvailabilityOfVsa to its sources

	 # Writing ciocal_AvailabilityOfVsa to source 2
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 0, TestNum )

	 # Writing ciocal_AvailabilityOfVsa to source 1
Output (" ")
Output ("[TP_1::TC a34::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a35::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 1, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a36::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 2, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 2, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a37::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 3, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a38::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 4, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 4, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a39::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 5, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 5, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a40::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 6, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 6, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a41::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 7, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 7, 0, TestNum )

	# Writing glossary term ciocal_TaRaPresent to its sources

	 # Writing ciocal_TaRaPresent to source 2
	 VerifyWrite ( ciocal_TaRaPresent_2, 0.00, TestNum )

	 # Writing ciocal_TaRaPresent to source 1

	 # Test values of Parameter #ciocal_TaRaPresent# (Max value 255, Min Value 0 and resolution 1 )

	  Min = 0
	  MinPlus = ( 0+(1))
	  MidVal = Int(( 255+(0))/2)
	  MaxMinus = ( 255-(1))
	  Max = 255
Output (" ")
Output ("[TP_1::TC a42::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_1, Min, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, Min, 1.00, TestNum )

Output (" ")
Output ("[TP_1::TC a43::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_1, MinPlus, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, MinPlus, 1.00, TestNum )

Output (" ")
Output ("[TP_1::TC a44::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_1, MidVal, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, MidVal, 1.00, TestNum )

Output (" ")
Output ("[TP_1::TC a45::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_1, MaxMinus, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, MaxMinus, 1.00, TestNum )

Output (" ")
Output ("[TP_1::TC a47::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
Output (" ")
Output ("[TP_1::TC a46::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_1, Max, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, Max, 1.00, TestNum )

	# Writing glossary term ciocal_TcasControlStatus_Valid to its sources
	global EXPECTEDVALUE_ciocal_TcasControlStatus_Valid

	SS_VerifyReadReturnValue ( ciocal_TcasControlStatus_Valid_1, EXPECTEDVALUE_ciocal_TcasControlStatus_Valid)

	SS_VerifyReadChkValue( g_ciocal_TcasControlStatus_Valid, EXPECTEDVALUE_ciocal_TcasControlStatus_Valid,  0, TestNum )
	# Writing glossary term ciocal_TcasInTest to its sources

	 # Writing ciocal_TcasInTest to source 2
	 VerifyWrite ( ciocal2_TcasInTest_1, 0, TestNum )

	 # Writing ciocal_TcasInTest to source 1
Output (" ")
Output ("[TP_1::TC a48::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasInTest_1, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TcasInTest, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a49::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasInTest_1, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TcasInTest, 1, 0, TestNum )



 # CompareDataMaps_Source_ciocal_TcasSourceSel_1



#******************* End Subprogram Definition ***********************



#********************* Subprogram Definition ***********************


def CompareDataMaps_Source_ciocal_TcasSourceSel_2 ( TestNum  )


	#Parameter value settings:

	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )
	# Writing glossary term ciocal_AdsbInStatus to its sources

	 # Writing ciocal_AdsbInStatus to source 1
	 VerifyWrite ( ciocal_AdsbInStatus_1, 0, TestNum )

	 # Writing ciocal_AdsbInStatus to source 2
Output (" ")
Output ("[TP_1::TC a50::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_AdsbInStatus_1, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AdsbInStatus, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a51::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_AdsbInStatus_1, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AdsbInStatus, 1, 0, TestNum )

	# Writing glossary term ciocal_AvailabilityOfAirb to its sources

	 # Writing ciocal_AvailabilityOfAirb to source 1
	 VerifyWrite ( ciocal_AvailabilityOfAirb_1, 0, TestNum )

	 # Writing ciocal_AvailabilityOfAirb to source 2
Output (" ")
Output ("[TP_1::TC a52::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a53::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 1, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a54::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 2, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 2, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a55::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 3, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a56::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 4, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 4, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a57::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 5, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 5, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a58::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 6, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 6, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a59::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfAirb_2, 7, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfAirb, 7, 0, TestNum )

	# Writing glossary term ciocal_AvailabilityOfSurf to its sources

	 # Writing ciocal_AvailabilityOfSurf to source 1
	 VerifyWrite ( ciocal_AvailabilityOfSurf_1, 0, TestNum )

	 # Writing ciocal_AvailabilityOfSurf to source 2
Output (" ")
Output ("[TP_1::TC a60::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a61::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 1, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a62::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 2, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 2, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a63::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 3, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a64::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 4, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 4, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a65::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 5, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 5, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a66::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 6, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 6, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a67::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfSurf_2, 7, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfSurf, 7, 0, TestNum )

	# Writing glossary term ciocal_AvailabilityOfVsa to its sources

	 # Writing ciocal_AvailabilityOfVsa to source 1
	 VerifyWrite ( ciocal_AvailabilityOfVsa_1, 0, TestNum )

	 # Writing ciocal_AvailabilityOfVsa to source 2
Output (" ")
Output ("[TP_1::TC a68::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a69::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 1, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a70::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 2, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 2, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a71::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 3, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a72::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 4, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 4, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a73::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 5, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 5, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a74::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 6, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 6, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a75::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_AvailabilityOfVsa_2, 7, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_AvailabilityOfVsa, 7, 0, TestNum )

	# Writing glossary term ciocal_TaRaPresent to its sources

	 # Writing ciocal_TaRaPresent to source 1
	 VerifyWrite ( ciocal_TaRaPresent_1, 0.00, TestNum )

	 # Writing ciocal_TaRaPresent to source 2

	 # Test values of Parameter #ciocal_TaRaPresent# (Max value 255, Min Value 0 and resolution 1 )

	  Min = 0
	  MinPlus = ( 0+(1))
	  MidVal = Int(( 255+(0))/2)
	  MaxMinus = ( 255-(1))
	  Max = 255
Output (" ")
Output ("[TP_1::TC a76::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_2, Min, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, Min, 1.00, TestNum )

Output (" ")
Output ("[TP_1::TC a77::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_2, MinPlus, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, MinPlus, 1.00, TestNum )

Output (" ")
Output ("[TP_1::TC a78::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_2, MidVal, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, MidVal, 1.00, TestNum )

Output (" ")
Output ("[TP_1::TC a79::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_2, MaxMinus, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, MaxMinus, 1.00, TestNum )

Output (" ")
Output ("[TP_1::TC a81::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
Output (" ")
Output ("[TP_1::TC a80::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TaRaPresent_2, Max, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TaRaPresent, Max, 1.00, TestNum )

	# Writing glossary term ciocal_TcasControlStatus_Valid to its sources
	global EXPECTEDVALUE_ciocal_TcasControlStatus_Valid

	SS_VerifyReadReturnValue ( ciocal2_TcasControlStatus_Valid_1, EXPECTEDVALUE_ciocal_TcasControlStatus_Valid)

	SS_VerifyReadChkValue( g_ciocal_TcasControlStatus_Valid, EXPECTEDVALUE_ciocal_TcasControlStatus_Valid,  0, TestNum )
	# Writing glossary term ciocal_TcasInTest to its sources

	 # Writing ciocal_TcasInTest to source 1
	 VerifyWrite ( ciocal_TcasInTest_1, 0, TestNum )

	 # Writing ciocal_TcasInTest to source 2
Output (" ")
Output ("[TP_1::TC a82::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasInTest_1, 0, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TcasInTest, 0, 0, TestNum )

Output (" ")
Output ("[TP_1::TC a83::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasInTest_1, 1, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	SS_VerifyReadChkValue( g_ciocal_TcasInTest, 1, 0, TestNum )



 # CompareDataMaps_Source_ciocal_TcasSourceSel_2



#******************* End Subprogram Definition ***********************



#********************* Subprogram Definition ***********************


def PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_0 ( TestNum  )


	#Parameter value settings:


	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )



	# Writing glossary term ciocal_Label162Status_SSM robustness test value

	 # Writing ciocal_Label162Status_SSM to source 2
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 2, TestNum )

	 # Writing ciocal_Label162Status_SSM to source 1
	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a84::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 1, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 2, 0, TestNum )
	 #Testcase for robust Test value 3 for discrete SSM
Output (" ")
Output ("[TP_1::TC a85::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 3, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 0 if the test value is 3.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 0, 0, TestNum )



	# Writing glossary term ciocal_Label163Status_SSM robustness test value

	 # Writing ciocal_Label163Status_SSM to source 2
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 2, TestNum )

	 # Writing ciocal_Label163Status_SSM to source 1
	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a86::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 1, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 2, 0, TestNum )
	 #Testcase for robust Test value 3 for discrete SSM
Output (" ")
Output ("[TP_1::TC a87::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 3, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 0 if the test value is 3.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 0, 0, TestNum )



	# Writing glossary term ciocal_TcasControl_Good robustness test value

	 # Writing ciocal_TcasControl_Good to source 2
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 1, TestNum )

	 # Writing ciocal_TcasControl_Good to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a88::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasControl_Good_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	 #Test values of Discrete good terms are changed to 1 if the test value is 3.
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 1, 0, TestNum )

	 #Testcase for robust Test value 0
Output (" ")
Output ("[TP_1::TC a89::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasControl_Good_1, 0, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 0, 0, TestNum )



	# Writing glossary term ciocal_TcasDiscreteData_Good robustness test value

	 # Writing ciocal_TcasDiscreteData_Good to source 2
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 1, TestNum )

	 # Writing ciocal_TcasDiscreteData_Good to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a90::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	 #Test values of Discrete good terms are changed to 1 if the test value is 3.
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 1, 0, TestNum )

	 #Testcase for robust Test value 0
Output (" ")
Output ("[TP_1::TC a91::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 0, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 0, 0, TestNum )


 # PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_0



#******************* End Subprogram Definition ***********************



#********************* Subprogram Definition ***********************


def PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_0 ( TestNum  )


	#Parameter value settings:


	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )



	# Writing glossary term ciocal_Label162Status_SSM robustness test value

	 # Writing ciocal_Label162Status_SSM to source 1
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 2, TestNum )

	 # Writing ciocal_Label162Status_SSM to source 2
	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a92::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 1, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 2, 0, TestNum )
	 #Testcase for robust Test value 3 for discrete SSM
Output (" ")
Output ("[TP_1::TC a93::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 3, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 0 if the test value is 3.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 0, 0, TestNum )



	# Writing glossary term ciocal_Label163Status_SSM robustness test value

	 # Writing ciocal_Label163Status_SSM to source 1
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 2, TestNum )

	 # Writing ciocal_Label163Status_SSM to source 2
	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a94::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 1, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 2, 0, TestNum )
	 #Testcase for robust Test value 3 for discrete SSM
Output (" ")
Output ("[TP_1::TC a95::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 3, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 0 if the test value is 3.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 0, 0, TestNum )



	# Writing glossary term ciocal_TcasControl_Good robustness test value

	 # Writing ciocal_TcasControl_Good to source 1
	 VerifyWrite ( ciocal_TcasControl_Good_1, 1, TestNum )

	 # Writing ciocal_TcasControl_Good to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a96::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	 #Test values of Discrete good terms are changed to 1 if the test value is 3.
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 1, 0, TestNum )

	 #Testcase for robust Test value 0
Output (" ")
Output ("[TP_1::TC a97::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 0, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 0, 0, TestNum )



	# Writing glossary term ciocal_TcasDiscreteData_Good robustness test value

	 # Writing ciocal_TcasDiscreteData_Good to source 1
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 1, TestNum )

	 # Writing ciocal_TcasDiscreteData_Good to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a98::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	 #Test values of Discrete good terms are changed to 1 if the test value is 3.
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 1, 0, TestNum )

	 #Testcase for robust Test value 0
Output (" ")
Output ("[TP_1::TC a99::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 0, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 0, 0, TestNum )


 # PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_0



#******************* End Subprogram Definition ***********************




#********************* Subprogram Definition ***********************


def PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_1 ( TestNum  )


	#Parameter value settings:


	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )




	# Writing glossary term ciocal_Label162Status_SSM robustness test value

	 # Writing ciocal_Label162Status_SSM to source 2
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 3, TestNum )

	 # Writing ciocal_Label162Status_SSM to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a100::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 2, TestNum )
	 Delay WriteDelay
	 #Test values of SSM glossary terms are changed to 1 if the test value is 2.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 1, 0, TestNum )
	 #Testcase for robust Test value 1
Output (" ")
Output ("[TP_1::TC a101::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 1, TestNum )
	 Delay WriteDelay
	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 2, 0, TestNum )



	# Writing glossary term ciocal_Label163Status_SSM robustness test value

	 # Writing ciocal_Label163Status_SSM to source 2
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 3, TestNum )

	 # Writing ciocal_Label163Status_SSM to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a102::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 2, TestNum )
	 Delay WriteDelay
	 #Test values of SSM glossary terms are changed to 1 if the test value is 2.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 1, 0, TestNum )
	 #Testcase for robust Test value 1
Output (" ")
Output ("[TP_1::TC a103::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 1, TestNum )
	 Delay WriteDelay
	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 2, 0, TestNum )



	# Writing glossary term ciocal_TcasControl_Good robustness test value

	 # Writing ciocal_TcasControl_Good to source 2
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 2, TestNum )

	 # Writing ciocal_TcasControl_Good to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a104::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasControl_Good_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 1, 0, TestNum )
	 #Testcase for robust Test value 1
Output (" ")
Output ("[TP_1::TC a105::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasControl_Good_1, 1, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 0, 0, TestNum )



	# Writing glossary term ciocal_TcasDiscreteData_Good robustness test value

	 # Writing ciocal_TcasDiscreteData_Good to source 2
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 2, TestNum )

	 # Writing ciocal_TcasDiscreteData_Good to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a106::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 1, 0, TestNum )
	 #Testcase for robust Test value 1
Output (" ")
Output ("[TP_1::TC a107::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 1, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 0, 0, TestNum )


 # PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_1



#******************* End Subprogram Definition ***********************




#********************* Subprogram Definition ***********************


def PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_1 ( TestNum  )


	#Parameter value settings:


	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )




	# Writing glossary term ciocal_Label162Status_SSM robustness test value

	 # Writing ciocal_Label162Status_SSM to source 1
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 3, TestNum )

	 # Writing ciocal_Label162Status_SSM to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a108::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 2, TestNum )
	 Delay WriteDelay
	 #Test values of SSM glossary terms are changed to 1 if the test value is 2.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 1, 0, TestNum )
	 #Testcase for robust Test value 1
Output (" ")
Output ("[TP_1::TC a109::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 1, TestNum )
	 Delay WriteDelay
	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 2, 0, TestNum )



	# Writing glossary term ciocal_Label163Status_SSM robustness test value

	 # Writing ciocal_Label163Status_SSM to source 1
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 3, TestNum )

	 # Writing ciocal_Label163Status_SSM to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a110::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 2, TestNum )
	 Delay WriteDelay
	 #Test values of SSM glossary terms are changed to 1 if the test value is 2.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 1, 0, TestNum )
	 #Testcase for robust Test value 1
Output (" ")
Output ("[TP_1::TC a111::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 1, TestNum )
	 Delay WriteDelay
	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 2, 0, TestNum )



	# Writing glossary term ciocal_TcasControl_Good robustness test value

	 # Writing ciocal_TcasControl_Good to source 1
	 VerifyWrite ( ciocal_TcasControl_Good_1, 2, TestNum )

	 # Writing ciocal_TcasControl_Good to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a112::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 1, 0, TestNum )
	 #Testcase for robust Test value 1
Output (" ")
Output ("[TP_1::TC a113::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 1, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 0, 0, TestNum )



	# Writing glossary term ciocal_TcasDiscreteData_Good robustness test value

	 # Writing ciocal_TcasDiscreteData_Good to source 1
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 2, TestNum )

	 # Writing ciocal_TcasDiscreteData_Good to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a114::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 3, TestNum )
	 Delay WriteDelay

Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 1, 0, TestNum )
	 #Testcase for robust Test value 1
Output (" ")
Output ("[TP_1::TC a115::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 1, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 0, 0, TestNum )


 # PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_1



#******************* End Subprogram Definition ***********************




#********************* Subprogram Definition ***********************


def PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_2 ( TestNum  )


	#Parameter value settings:


	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )



	# Writing glossary term ciocal_Label162Status_SSM robustness test value

	 # Writing ciocal_Label162Status_SSM to source 2
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 3, TestNum )

	 # Writing ciocal_Label162Status_SSM to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a116::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 1, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
	 Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 2, 0, TestNum )
	 #Testcase for robust Test value 2
Output (" ")
Output ("[TP_1::TC a117::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 2, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 1 if the test value is 2.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 1, 0, TestNum )



	# Writing glossary term ciocal_Label163Status_SSM robustness test value

	 # Writing ciocal_Label163Status_SSM to source 2
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 3, TestNum )

	 # Writing ciocal_Label163Status_SSM to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a118::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 1, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
	 Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 2, 0, TestNum )
	 #Testcase for robust Test value 2
Output (" ")
Output ("[TP_1::TC a119::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 2, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 1 if the test value is 2.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 1, 0, TestNum )



	# Writing glossary term ciocal_TcasControl_Good robustness test value

	 # Writing ciocal_TcasControl_Good to source 2
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 1, TestNum )

	 # Writing ciocal_TcasControl_Good to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a120::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasControl_Good_1, 3, TestNum )
	 Delay WriteDelay
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 1, 0, TestNum )

	 #Testcase for robust Test value 2
Output (" ")
Output ("[TP_1::TC a121::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasControl_Good_1, 2, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 0, 0, TestNum )



	# Writing glossary term ciocal_TcasDiscreteData_Good robustness test value

	 # Writing ciocal_TcasDiscreteData_Good to source 2
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 1, TestNum )

	 # Writing ciocal_TcasDiscreteData_Good to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a122::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 3, TestNum )
	 Delay WriteDelay
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 1, 0, TestNum )

	 #Testcase for robust Test value 2
Output (" ")
Output ("[TP_1::TC a123::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 2, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 0, 0, TestNum )


 # PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_1_2



#******************* End Subprogram Definition ***********************




#********************* Subprogram Definition ***********************


def PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_2 ( TestNum  )


	#Parameter value settings:


	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )



	# Writing glossary term ciocal_Label162Status_SSM robustness test value

	 # Writing ciocal_Label162Status_SSM to source 1
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 3, TestNum )

	 # Writing ciocal_Label162Status_SSM to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a124::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 1, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
	 Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 2, 0, TestNum )
	 #Testcase for robust Test value 2
Output (" ")
Output ("[TP_1::TC a125::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 2, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 1 if the test value is 2.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 1, 0, TestNum )



	# Writing glossary term ciocal_Label163Status_SSM robustness test value

	 # Writing ciocal_Label163Status_SSM to source 1
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 3, TestNum )

	 # Writing ciocal_Label163Status_SSM to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a126::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 1, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 2 if the test value is 1.
	 Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 2, 0, TestNum )
	 #Testcase for robust Test value 2
Output (" ")
Output ("[TP_1::TC a127::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 2, TestNum )
	 Delay WriteDelay

	 #Test values of SSM glossary terms are changed to 1 if the test value is 2.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 1, 0, TestNum )



	# Writing glossary term ciocal_TcasControl_Good robustness test value

	 # Writing ciocal_TcasControl_Good to source 1
	 VerifyWrite ( ciocal_TcasControl_Good_1, 1, TestNum )

	 # Writing ciocal_TcasControl_Good to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a128::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 3, TestNum )
	 Delay WriteDelay
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 1, 0, TestNum )

	 #Testcase for robust Test value 2
Output (" ")
Output ("[TP_1::TC a129::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 2, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasControl_Good, 0, 0, TestNum )



	# Writing glossary term ciocal_TcasDiscreteData_Good robustness test value

	 # Writing ciocal_TcasDiscreteData_Good to source 1
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 1, TestNum )

	 # Writing ciocal_TcasDiscreteData_Good to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a130::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 3, TestNum )
	 Delay WriteDelay
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 1, 0, TestNum )

	 #Testcase for robust Test value 2
Output (" ")
Output ("[TP_1::TC a131::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 2, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_TcasDiscreteData_Good, 0, 0, TestNum )


 # PGS_DataMapsRobustTestCases_ciocal_TcasSourceSel_2_2



#******************* End Subprogram Definition ***********************




#********************* Subprogram Definition ***********************


def PGS_DataMapsTestCases_ciocal_TcasSourceSel_1_3 ( TestNum  )


	#Parameter value settings:


	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )



	# Writing glossary term ciocal_Label162Status_SSM robustness test value

	 # Writing ciocal_Label162Status_SSM to source 2
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 2, TestNum )

	 # Writing ciocal_Label162Status_SSM to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a132::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 1, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 2, 0, TestNum )
	 #Testcase for valid Test value 0
Output (" ")
Output ("[TP_1::TC a133::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 0, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 3 if the test value is 0.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 3, 0, TestNum )



	# Writing glossary term ciocal_Label163Status_SSM robustness test value

	 # Writing ciocal_Label163Status_SSM to source 2
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 2, TestNum )

	 # Writing ciocal_Label163Status_SSM to source 1

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a134::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 1, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 2, 0, TestNum )
	 #Testcase for valid Test value 0
Output (" ")
Output ("[TP_1::TC a135::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 0, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 3 if the test value is 0.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 3, 0, TestNum )



	# Writing glossary term ciocal_TcasControl_Good robustness test value

	 # Writing ciocal_TcasControl_Good to source 2
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 1, TestNum )

	 # Writing ciocal_TcasControl_Good to source 1

Output (" ")
Output ("[TP_1::TC a136::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasControl_Good_1, 0, TestNum )
	 Delay WriteDelay
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_tcascontrol_good, 0, 0, TestNum )

	 #Testcase for valid Test value 3
Output (" ")
Output ("[TP_1::TC a137::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasControl_Good_1, 3, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_tcascontrol_good, 1, 0, TestNum )



	# Writing glossary term ciocal_TcasDiscreteData_Good robustness test value

	 # Writing ciocal_TcasDiscreteData_Good to source 2
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 1, TestNum )

	 # Writing ciocal_TcasDiscreteData_Good to source 1

Output (" ")
Output ("[TP_1::TC a138::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 0, TestNum )
	 Delay WriteDelay
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_tcasdiscretedata_good, 0, 0, TestNum )

	 #Testcase for valid Test value 3
Output (" ")
Output ("[TP_1::TC a139::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 3, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_tcasdiscretedata_good, 1, 0, TestNum )


 # PGS_DataMapsTestCases_ciocal_TcasSourceSel_1_3



#******************* End Subprogram Definition ***********************




#********************* Subprogram Definition ***********************


def PGS_DataMapsTestCases_ciocal_TcasSourceSel_2_3 ( TestNum  )


	#Parameter value settings:


	Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum )



	# Writing glossary term ciocal_Label162Status_SSM robustness test value

	 # Writing ciocal_Label162Status_SSM to source 1
	 VerifyWrite ( ciocal_Label162Status_SSM_1, 2, TestNum )

	 # Writing ciocal_Label162Status_SSM to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a140::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 1, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 2, 0, TestNum )
	 #Testcase for valid Test value 0
Output (" ")
Output ("[TP_1::TC a141::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label162Status_SSM_2, 0, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 3 if the test value is 0.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label162Status_SSM, 3, 0, TestNum )



	# Writing glossary term ciocal_Label163Status_SSM robustness test value

	 # Writing ciocal_Label163Status_SSM to source 1
	 VerifyWrite ( ciocal_Label163Status_SSM_1, 2, TestNum )

	 # Writing ciocal_Label163Status_SSM to source 2

	 #Testcase for toggling purpose
Output (" ")
Output ("[TP_1::TC a142::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 1, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 2 if the test value is 1.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 2, 0, TestNum )
	 #Testcase for valid Test value 0
Output (" ")
Output ("[TP_1::TC a143::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_Label163Status_SSM_2, 0, TestNum )
	 Delay WriteDelay

	 #Test values of Discrete SSM glossary terms are changed to 3 if the test value is 0.
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_Label163Status_SSM, 3, 0, TestNum )



	# Writing glossary term ciocal_TcasControl_Good robustness test value

	 # Writing ciocal_TcasControl_Good to source 1
	 VerifyWrite ( ciocal_TcasControl_Good_1, 1, TestNum )

	 # Writing ciocal_TcasControl_Good to source 2

Output (" ")
Output ("[TP_1::TC a144::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 0, TestNum )
	 Delay WriteDelay
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_tcascontrol_good, 0, 0, TestNum )

	 #Testcase for valid Test value 3
Output (" ")
Output ("[TP_1::TC a145::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 3, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_tcascontrol_good, 1, 0, TestNum )



	# Writing glossary term ciocal_TcasDiscreteData_Good robustness test value

	 # Writing ciocal_TcasDiscreteData_Good to source 1
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 1, TestNum )

	 # Writing ciocal_TcasDiscreteData_Good to source 2

Output (" ")
Output ("[TP_1::TC a146::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 0, TestNum )
	 Delay WriteDelay
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_tcasdiscretedata_good, 0, 0, TestNum )

	 #Testcase for valid Test value 3
Output (" ")
Output ("[TP_1::TC a147::SDD_CALF_9951] -   SSAutoGeneratedTest")

Output ("-------------------------------------------------------------")
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 3, TestNum )
	 Delay WriteDelay

	 #Below delay is added for Debounce parameter
Delay (0.400)
Delay ReadDelay
	 SS_VerifyReadChkValue( g_ciocal_tcasdiscretedata_good, 1, 0, TestNum )


 # PGS_DataMapsTestCases_ciocal_TcasSourceSel_2_3



#******************* End Subprogram Definition ***********************






#********************* Subprogram Definition ***********************


def Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel ( TestNum  )


	#Parameter value settings:


	# Writing glossary term ciocal_TcasControl_Good #Fresh&Valid# value
	 VerifyWrite ( ciocal_TcasControl_Good_1, 3, TestNum )
	 VerifyWrite ( ciocal2_TcasControl_Good_1, 3, TestNum )
Delay (0.400)

	# Writing glossary term ciocal_TcasDiscreteData_Good #Fresh&Valid# value
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_1, 3, TestNum )
	 VerifyWrite ( ciocal_TcasDiscreteData_Good_2, 3, TestNum )
Delay (0.400)


 # Set_DotGood_ForEachTestCase_ciocal_TcasSourceSel



#******************* End Subprogram Definition ***********************







#===================================================================================================
#                                    TEST CASES AND PROCEDURE                                       
#===================================================================================================
#***************************************************************************************************
If (  CompareObjectID("DISPLAYS_SW_HLR_123456") Or CompareObjectID("SDD_MWF_1234")): 
#=================================================================================================
#--------------------------------------

#ciocal_TcasSourceSel_1-1
# Input Condition  : Set 
#				  ciocal1_TcasControl_Good =3
#				  ciocal1_TcasControlStatus_Valid =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 0
#		ciocal_TcasSourceSel_Valid = 1
#		ciocal_TcasSourceSel_Changed = 1
#--------------------------------------

#ciocal_TcasSourceSel_1-2
# Input Condition  : Set 
#				  ciocal1_TcasControl_Good =3
#				  ciocal1_TcasControlStatus_Valid =0
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 0
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#--------------------------------------

#ciocal_TcasSourceSel_1-3
# Input Condition  : Set 
#				  ciocal1_TcasControl_Good =0
#				  ciocal1_TcasControlStatus_Valid =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 0
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#--------------------------------------

#ciocal_TcasSourceSel_1-4
# Input Condition  : Set 
#				  ciocal1_TcasControl_Good =0
#				  ciocal1_TcasControlStatus_Valid =0
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 0
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#--------------------------------------

#ciocal_TcasSourceSel_1-5
# Input Condition  : Set 
#				 ciocal1_TcasControl_Good =1
#				 ciocal1_TcasControlStatus_Valid =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 0
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#--------------------------------------

#ciocal_TcasSourceSel_1-6
# Input Condition  : Set 
#				 ciocal1_TcasControl_Good =2
#				 ciocal1_TcasControlStatus_Valid =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 0
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#Note : .Change parameter will be 1 if Sources has been changed in the same frame else it will be 0.
#--------------------------------------
#=================================================================================================

	ciocal_TcasSourceSel_1_TestCases()

#=================================================================================================
#--------------------------------------

#ciocal_TcasSourceSel_2-1
# Input Condition  : Set 
#				  ciocal2_TcasControl_Good =3
#				  ciocal2_TcasControlStatus_Valid =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 1
#		ciocal_TcasSourceSel_Valid = 1
#		ciocal_TcasSourceSel_Changed = 1
#--------------------------------------

#ciocal_TcasSourceSel_2-2
# Input Condition  : Set 
#				  ciocal2_TcasControl_Good =3
#				  ciocal2_TcasControlStatus_Valid =0
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 1
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#--------------------------------------

#ciocal_TcasSourceSel_2-3
# Input Condition  : Set 
#				  ciocal2_TcasControl_Good =0
#				  ciocal2_TcasControlStatus_Valid =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 1
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#--------------------------------------

#ciocal_TcasSourceSel_2-4
# Input Condition  : Set 
#				  ciocal2_TcasControl_Good =0
#				  ciocal2_TcasControlStatus_Valid =0
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 1
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#--------------------------------------

#ciocal_TcasSourceSel_2-5
# Input Condition  : Set 
#				 ciocal2_TcasControl_Good =1
#				 ciocal2_TcasControlStatus_Valid =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 1
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#--------------------------------------

#ciocal_TcasSourceSel_2-6
# Input Condition  : Set 
#				 ciocal2_TcasControl_Good =2
#				 ciocal2_TcasControlStatus_Valid =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 1
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 0
#Note : .Change parameter will be 1 if Sources has been changed in the same frame else it will be 0.
#--------------------------------------
#=================================================================================================

	ciocal_TcasSourceSel_2_TestCases()

#=================================================================================================
#--------------------------------------

#ciocal_TcasSourceSel_General-1
# Input Condition  : Set 
#				 Validity_1 =0
#				 Validity_2 =0
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = Previous Index
#		ciocal_TcasSourceSel_Valid = 0
#		ciocal_TcasSourceSel_Changed = 1
#--------------------------------------

#ciocal_TcasSourceSel_General-2
# Input Condition  : Set 
#				 Validity_1 =0
#				 Validity_2 =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 1
#		ciocal_TcasSourceSel_Valid = 1
#		ciocal_TcasSourceSel_Changed = 1
#--------------------------------------

#ciocal_TcasSourceSel_General-3
# Input Condition  : Set 
#				 Validity_1 =1
#				 Validity_2 =1
# 
# Expected Results : Verify
#		ciocal_TcasSourceSel_Index = 0
#		ciocal_TcasSourceSel_Valid = 1
#		ciocal_TcasSourceSel_Changed = 1
#Note : .Change parameter will be 1 if Sources has been changed in the same frame else it will be 0.
#--------------------------------------
#=================================================================================================

	ciocal_TcasSourceSel_General_TestCases()


#End If

#*************************************************************************************************
If ( CompareObjectID("DISPLAYS_SW_HLR_123456") Or CompareObjectID("SDD_MWF_1234")): 
#=================================================================================================
# Input Condition  : Set 
# 1. Source 1 = valid 
# Expected Results : Verify
# value from Source 1 Parameter is transfer to glossary parameter.
# Input Condition  : Set 
# 2. Source 2 = valid 
# Expected Results : Verify
# value from Source 2 Parameter is transfer to glossary parameter.
#-------------------------------------------------------------------------------------------------
#=================================================================================================

	ciocal_TcasSourceSel_DataMap_TestCases()
#End If

#*************************************************************************************************


	

#----------------------------------------------------------------------------------------------------
ReportSummary()
#----------------------------------------------------------------------------------------------------
#====================================================================================================