#Author: Vishwas Krishna
#Purpose: Changing the Object ID

import os
import openpyxl
import re

Mapping_File = input("Enter the full path of Mapping file: ")
wb = openpyxl.load_workbook(Mapping_File)
sheet = wb.get_sheet_by_name('Sheet1')

Texttofind_Array = []
TexttoReplace_Array = []
def TextToFind(Texttofind_Array, TexttoReplace_Array):
    for row in range (1,sheet.max_row+1):
        Texttofind = str(sheet.cell(row=row, column=1).value).strip()
        TexttoReplace = str(sheet.cell(row=row, column=2).value).strip()
        Texttofind = Texttofind
        TexttoReplace = TexttoReplace
        if (Texttofind == 'None'):
            #print("End of File")
            return Texttofind_Array, TexttoReplace_Array
        Texttofind_Array.append(Texttofind)
        TexttoReplace_Array.append(TexttoReplace)

texttofind = TextToFind(Texttofind_Array, TexttoReplace_Array)

def convert(list):
    return (*list, )
checkWords = convert(Texttofind_Array)
print(checkWords)
repWords = convert(TexttoReplace_Array)
print(repWords)

sourcepath = os.listdir('InputPath/')

for file in sourcepath:
    inputfile = 'InputPath/' + file
    destinationPath = 'OutputPath/' + file
    f2 = open(destinationPath, 'w')
    print("Conversion is Ongoing on: " + inputfile)
    with open(inputfile, 'r') as inputfile:
        for line in inputfile:
            for check, rep in zip(checkWords, repWords):
                regex = re.compile(check + r'\b')
                line = regex.sub(rep, line)
                #line = line.replace(check, rep)
            f2.write(line)
    f2.close()