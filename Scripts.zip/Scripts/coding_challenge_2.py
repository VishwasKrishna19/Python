# Question 4
'''
>***Write a program which accepts a sequence of comma-separated numbers from console and generate a list and a tuple which contains every number.Suppose the following input is supplied to the program:***
34,67,55,33,12,98

>***Then, the output should be:***

['34', '67', '55', '33', '12', '98']
('34', '67', '55', '33', '12', '98')
'''

#seq = input("Enter the Sequence of numbers : ")
seq = "1,2,3,4"
seqval = seq.split(",")
print(list(seqval))
print(tuple(seqval))


### **Question:**
'''
>***Define a class which has at least two methods:***
>* ***getString: to get a string from console input*** 
>* ***printString: to print the string in upper case.*** 

>***Also please include simple test function to test the class methods.***

### Hints:
>***Use __init__ method to construct some parameters***
'''

class Example(str):
    def __init__(self, str):
        self.str = ""

    def getString(self):
        self.str = consinput

    def printString(self, str):
        print(f'Entered String is "{str.upper()}"')

#consinput = input("Enter the String :")
consinput = "vishwas krishna"

exmp1 = Example(consinput)
exmp1.getString()
exmp1.printString(consinput)

### **Question:**
'''
>***Write a program that calculates and prints the value according to the given formula:***
>***Q = Square root of [(2 * C * D)/H]***
>***Following are the fixed values of C and H:***
>***C is 50. H is 30.***
>***D is the variable whose values should be input to your program in a comma-separated sequence.For example
Let us assume the following comma separated input sequence is given to the program:***
100,150,180
>***The output of the program should be:***
18,22,24
'''
import math
C = 50
H = 30
#D = input("Enter the Sequence of Values: ")
D = "100,150,180"
D = D.split(",")
li = list(D)
li1 = []
for eachval in li:
    Q = round(math.sqrt((2 * C * int(eachval)) / H))
    li1.append(str(Q))

print(",".join(li1))

c = 50
h = 30
value = []
items = [x for x in "100,150,180".split(',')]
for d in items:
    value.append(str(int(round(math.sqrt(2*c*float(d)/h)))))

print(','.join(value))

### **Question:**
'''
>***Write a program which takes 2 digits, X,Y as input and generates a 2-dimensional array. The element value in the i-th row and j-th column of the array should be i * j.***
***Note: i=0,1.., X-1; j=0,1,¡­Y-1. Suppose the following inputs are given to the program: 3,5***
>***Then, the output of the program should be:***
[[0, 0, 0, 0, 0], [0, 1, 2, 3, 4], [0, 2, 4, 6, 8]]
'''

# input_str = input("Enter the 2 Digit input with comma separated: ")
input_str = "2,4"
input_str = input_str.split(",")
rownum = int(input_str[0])
colnum = int(input_str[1])
multidim = [[0 for col in range(colnum)] for row in range(rownum)]
for row in range(rownum):
    for col in range(colnum):
        multidim[row][col] = row * col

print(multidim)

### **Question:**
'''
>***Write a program that accepts a comma separated sequence of words as input and prints the words in a comma-separated sequence after sorting them alphabetically.***
>***Suppose the following input is supplied to the program:***
without,hello,bag,world
>***Then, the output should be:***
bag,hello,without,world
'''

# sequence = input("Enter the Sequence of the Letters with comma separated: ")
sequence = "without,hello,bag,world"
seq1 = sequence.split(",")
print(seq1)
seq1.sort()
print(",".join(seq1))

### **Question:**
'''
>***Write a program that accepts sequence of lines as input and prints the lines after making all characters in the sentence capitalized.***
>***Suppose the following input is supplied to the program:***
Hello world
Practice makes perfect
>***Then, the output should be:***
HELLO WORLD
PRACTICE MAKES PERFECT
'''

# inputseq = input("Enter the Sequence of words: ")
# inputseq = inputseq.split()
# inputseq.upper()
# print(inputseq)
lst = []
while True:
    # x = input("Enter the Sequence of words: ")
    x = "practice makes perfect"
    if len(x) == 0:
        break;
    lst.append(x.upper())
    print(lst)
    break


for line in lst:
    print(line)

### **Question**
'''
>***Write a program that accepts a sequence of whitespace separated words as input and prints the words after removing all duplicate words and sorting them alphanumerically.***
>***Suppose the following input is supplied to the program:***
hello world and practice makes perfect and hello world again
>***Then, the output should be:***
again and hello makes perfect practice world
'''

y = "hello world and practice makes perfect and hello world again"
ydata = y.split()
print(ydata)
newset  = set(ydata)
print(newset)
zdata = list(newset)
print(zdata)
zdata.sort()
print(zdata)
print(",".join(zdata))

# Question 11

### **Question**
'''
>***Write a program which accepts a sequence of comma separated 4 digit binary numbers as its input and then check whether they are divisible by 5 or not. The numbers that are divisible by 5 are to be printed in a comma separated sequence.***
>***Example:***
0100,0011,1010,1001
>***Then the output should be:***
1010
>***Notes: Assume the data is input by console.***
'''

numinput = "0100,0011,1010,1001, 1111"
numinput = numinput.split(",")
def binaryToDecimal(n):
    return int(n,2)

list2 = []
for eachval in numinput:
    x1 = binaryToDecimal(eachval)
    if x1 % 5 == 0:
        list2.append(eachval)

list2 = ",".join(list2)
print(list2)

# Question 12
'''
### **Question:**
>***Write a program, which will find all such numbers between 1000 and 3000 (both included) such that each digit of the number is an even number.The numbers obtained should be printed in a comma-separated sequence on a single line.***
----------------------
### Hints:
>***In case of input data being supplied to the question, it should be assumed to be a console input.***
'''
lst = []
for i in range(1000, 3001):
    flag = 1
    for j in str(i):
        if ord(j)%2 != 0:
            flag = 0
    if flag == 1:
        lst.append(str(i))

print(",".join(lst))

def check(element):
    return all(ord(i)%2 == 0 for i in element)  # all returns True if all digits i is even in element

lst = [str(i) for i in range(1000,3001)]
lst = list(filter(check,lst))                   # filter removes element from list if check condition fails
print(",".join(lst))


# Question 13

### **Question:**
'''
>***Write a program that accepts a sentence and calculate the number of letters and digits.***
>***Suppose the following input is supplied to the program:***
hello world! 123
>***Then, the output should be:***
LETTERS 10
DIGITS 3
'''

word = "hello world! 123"
digi = []
digicount = 0
lett = []
lettercount = 0
for eachval1 in word:
    if eachval1.isdigit() == 1:
        digi.append(eachval1)
        digicount += 1
    elif eachval1.isalpha() == 1:
        lett.append(eachval1)
        lettercount += 1

print("Number of Digits are " + str(digicount))
print(f'Number of Letters are {lettercount}')

letter, digit = 0, 0

for i in word:
    letter += i.isalpha()  # returns True if alphabet
    digit += i.isnumeric()  # returns True if numeric

print("LETTERS %d\nDIGITS %d" % (letter, digit))  # two different types of formating method is shown in both solution





