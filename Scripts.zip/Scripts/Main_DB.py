import os
import errno
import json
from xml.etree import ElementTree as ET
import pyodbc
import socket

import PortToSQL as PTS
import ASCB_Mapping as ASCBM
import Datmon_Mapping as DMP
import Common_Functions as CMF
basePath = os.path.dirname(__file__)

def make_sure_path_exists(path):
    try:
        os.makedirs(path)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
         raise

make_sure_path_exists(os.path.abspath(os.path.join(basePath, "..", "Data")))

inputpath = os.path.abspath(os.path.join(basePath, "..", "Data", "Output.json"))
file = open(inputpath,'r')
inputscontent = file.read()
file.close()
inputs = json.loads(inputscontent)
if inputs['ConfigPath'] != None:

    ConfigPath = str((inputs['ConfigPath']).strip())
    DBname = ConfigPath.rpartition("\\")[2]
    DBname = DBname.partition(".")[0]

    # Getting the host name
    server = socket.gethostname()
    driver = '{SQL Server}'  # Driver you need to connect to the database

    cnn = pyodbc.connect('DRIVER=' + driver + ';SERVER=' + server + ';Trusted_Connection=yes;', autocommit=True)

    dataCursor = cnn.cursor()

    try:
        dataCursor.execute('CREATE DATABASE ' + DBname)
    except:
        pass

    cnn.commit()
    cnn.close()

    tree = ET.parse(ConfigPath)
    root = tree.getroot()
    ASCBdbPath = ''
    ASCBPath = ''
    DatmonPath = ''
    CommonFuncitonsPath = ''
    for child in root:
        if child.tag == "ASCBdbPath":
            ASCBdbPath = child.text
            ASCBdbPath = ASCBdbPath.strip()
            if ASCBdbPath != "":
                PTS.portdbtosql(server,DBname,ASCBdbPath)
            break
    for child in root:
        if child.tag == "ASCBPath":
            ASCBPath = child.text
            ASCBPath = ASCBPath.strip()
            if ASCBdbPath != "" and ASCBPath != '':
                ASCBM.ascbmapping(server,DBname,ASCBPath)
        if child.tag == "DatmonPath":
            DatmonPath = child.text
            DatmonPath = DatmonPath.strip()
            if DatmonPath != "":
                DMP.datmonmapping(server,DBname,DatmonPath)
        if child.tag == "CommonFuncitonsPath":
            CommonFuncitonsPath = child.text
            CommonFuncitonsPath = CommonFuncitonsPath.strip()
            if CommonFuncitonsPath != "":
                CMF.commonfunctions(server,DBname,CommonFuncitonsPath)



