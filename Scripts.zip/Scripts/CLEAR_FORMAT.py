import sys
import docx, os, re, subprocess, shutil

filename = 'C:/Vishwas/TASKS_ASSIGNED/SVV_Summit_2019/Clear_Format/Sample.docx'
doc = docx.Document(filename)
fullText = []
for para in doc.paragraphs:
        fullText.append(para.text)
data = '\n'.join(fullText)
print(data)

if data.__contains__('shall') or data.__contains__('Shall'):
    Requirement_Tag = re.search(r"\[([A-Za-z0-9_ ]+)\]", data)
    Requirement_Tag = Requirement_Tag.group(1)
    print(Requirement_Tag)

InputSection = data.split('shall')[0]
InputSection = InputSection.split(',')[0]

if InputSection.startswith('If'):
    InputSection  = InputSection.split('If')[1]

InputSection = InputSection.replace('‘', '\'')
InputSection = InputSection.replace('’', '\'')
print(InputSection)

outputsection = data.split(',')[1]
outputsection = re.sub('\[([A-Za-z0-9_ ]+)\]', '', outputsection)
outputsection = outputsection.replace('shall  ', '')
outputsection = outputsection.replace('‘', '\'')
outputsection = outputsection.replace('’', '\'')
outputsection = outputsection.lstrip('\n')
print(outputsection)

Clear_Format = 'REQ : ' + Requirement_Tag + '\n' + 'IF (' + InputSection + ')' + '\n' + 'THEN' + '\n\t' + outputsection + '\n' + 'ENDIF'
print(Clear_Format)

with open("C:/Vishwas/TASKS_ASSIGNED/SVV_Summit_2019/Clear_Format/Req.txt", 'w', encoding="utf-8") as output:
    output.write(Clear_Format)