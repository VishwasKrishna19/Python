import InitialSupport

from InitialSupport import *
TestName = "ANE_S11B_0001"
Startsum(TestName)
#==================================================================================================
#                             ELECTRONIC CHECKLIST FUNCTION SOFTWARE TEST PLAN/PROCEDURE                              
#==================================================================================================

Output ("===========================================================================================")
Output "Test Name       : ANE_S11B_0001        \                                                    "
Output ("ParagraphTitle  : Auto Complete Time Attribute                                             ")
Output ("ParagraphTitle  : Auto Alert Display                                                       ")
Output ("ParagraphTitle  : Floating Cursor                                                          ")
Output ("ParagraphTitle  : IsDual                                                                   ")
Output ("ParagraphTitle  : CSV Enable                                                               ")
Output ("ParagraphTitle  : Reset Enable                                                             ")
Output ("ParagraphTitle  : Alert Latch Enabled                                                      ")
Output ("ParagraphTitle  : Cursor On Checked Item                                                   ")
Output ("ParagraphTitle  : Db Menu Continue                                                         ")
Output ("ParagraphTitle  : Sensor Latch Enable                                                      ")
Output ("ParagraphTitle  : Aircraft Type Attribute                                                  ")
Output ("ParagraphTitle  : Aircraft Prefix Attribute                                                ")
Output ("ParagraphTitle  : Max DB file name Attribute                                               ")
Output ("ParagraphTitle  : Max Display character Attribute                                          ")
Output ("ParagraphTitle  : Max Display Line Attribute                                               ")
Output ("ParagraphTitle  : ECL Database I/O Attribute                                               ")
Output ("ParagraphTitle  : Scroll Enable Attribute                                                  ")
Output ("ParagraphTitle  : Auto Hyperlink Attribute                                                 ")
Output ("ParagraphTitle  : Auto Page Enable Attribute                                               ")
Output ("ParagraphTitle  : General Menu Attribute                                                   ")
Output ("ParagraphTitle  : Auto Database Loading Attribute                                          ")
Output ("===========================================================================================")
Output ("                                   MODIFICATION HISTORY                                    ")
Output ("===========================================================================================")
Output ("Version   Date        Author           Change Description           CH_DOC                 ")
Output ("-------   ---------   --------------   --------------------------   -----------------------")
#Output "01        08-May-17   Sankararao A     Load 3.4.1.1: Initial        EPICEDS_EC_AN132_PAR_12/EPICEDS_EC_AN132_PAR_2"
#Output "                                       Development.                 EDS_ECL_AN132_TR_1    "
#Output "02        23-May-17   Sankararao A     Load 3.4.1.1 Rework: Updated      EPICEDS_EC_AN132_PAR_12/EPICEDS_EC_AN132_PAR_2"
#Output "                                       Result Variable default values.   EDS_ECL_AN132_TR_1"
Output ("03        12-Jul-17   Sankararao A     Load 3.4.1.1 Rework: Updated      EPICEDS_EC_AN132_PAR_12/EPICEDS_EC_AN132_PAR_2")
Output ("                                       Shall tag name properly.          EDS_ECL_AN132_TR_1")
Output ("===========================================================================================")

#==================================================================================================
#                               REQUIREMENT TAGS (PARAGRAPH AND SHALL)                             
#==================================================================================================
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT AUTO COMPLETE TIME ATT]                     ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT AUTO ALERT DISPLAY ATT]                     ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT FLOATING CURSOR ATT]                        ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT ISDUAL ATT]                                 ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT CSV ENABLE ATT]                             ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT RESET ENABLE ATT]                           ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT ALERT LATCH ENABLED ATT]                    ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT CURSOR ON CHECKED ITEM ATT]                 ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT DB MENU CONTINUE ATT]                       ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT SENSOR LATCH ENABLE ATT]                    ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL DB AIRCRAFT TYPE ATT]                           ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL DB AIRCRAFT PREFIX ATT]                         ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL MAX DB FILE NAME ATT]                           ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL MAX DIS CHAR ATT]                               ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL MAX DIS LINE ATT]                               ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL DB IO ATT]                                      ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL DB AUTO PAGE SCROLL ATT]                        ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL DB AUTO HYPERLINK ATT]                          ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL DB AUTO PAGE ATT]                               ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL DB GEN MENU ATT]                                ")
Output ("Primary Paragraph Tag   : [PTAG::SRD B ECL INT AUTO DB LOAD ATT]                           ")
Output ("===========================================================================================")
#------------------------------------------------
# TestCase::Shall Tag  
#------------------------------------------------
# [TC a::SRD B ECL INT AUTO COMPLETE TIME ATT 10]
# [TC b::SRD B ECL INT AUTO ALERT DISPLAY ATT 10]
# [TC c::SRD B ECL INT FLOATING CURSOR ATT 10]
# [TC d::SRD B ECL INT ISDUAL ATT 05]
# [TC e::SRD B ECL INT CSV ENABLE ATT 05]
# [TC f::SRD B ECL INT RESET ENABLE ATT 05]
# [TC g::SRD B ECL INT ALERT LATCH ENABLED ATT 10]
# [TC h::SRD B ECL INT CURSOR ON CHECKED ITEM ATT 10]
# [TC i::SRD B ECL INT DB MENU CONTINUE ATT 10]
# [TC j::SRD B ECL INT SENSOR LATCH ENABLE ATT 05]
# [TC k::SRD B ECL DB AIRCRAFT TYPE ATT 10]
# [TC l::SRD B ECL DB AIRCRAFT PREFIX ATT 10]
# [TC m::SRD B ECL MAX DB FILE NAME ATT 10]
# [TC n::SRD B ECL MAX DIS CHAR ATT 10]
# [TC o::SRD B ECL MAX DIS LINE ATT 10]
# [TC p::SRD B ECL DB IO ATT 10]
# [TC q::SRD B ECL DB AUTO PAGE SCROLL ATT 10]
# [TC r::SRD B ECL DB AUTO HYPERLINK ATT 10]
# [TC s::SRD B ECL DB AUTO PAGE ATT 10]
# [TC t::SRD B ECL DB GEN MENU ATT 10]
# [TC u::SRD B ECL INT AUTO DB LOAD ATT 10]
#------------------------------------------
#==================================================================================================
#                                  TEST ENVIRONMENT SPECIFICATION
#==================================================================================================
# Modified Program Core ecl.exe shall be used in MAU mini bench (original 
# ecl.exe shall be replaced by custom version should be loaded into proc1 
# Ecl_Vars.txt shall be used In DatMon process.
#
# Environment               : MAU Mini-bench with a Proc card || EASE bench
# ESCAPE Configuration DB   : ApexDFZ_Configuration_Data.mdb
# ESCAPE Configuration Name : ECL_V_V_real || Apex_Mini_bench || ApexDFZ_EASE
# DatMon                    : Dtmon.exe is required to be loaded and
#                             configured for the Ecl process.
#==================================================================================================
#                                         GENERAL COMMENTS
#==================================================================================================
# This TSF file cannot be executed in the normal Bench setup. For this file to be executed, the 
# Modified Program Core ecl.exe which is present in ecl_CORE_stub.zip
# which located in PVCS at path EDS_ECL:_AN132\AN132\TEST\TEST_MISC\
#==================================================================================================
#                                      GENERAL SET-UP COMMANDS
#==================================================================================================
# Following files are to be included in the project and should be in the following order:
#-----------------------------
# QualifiedSupport.tsf
# ComConstantsAndFunctions.tsf
# AN_ECL_DatmonMapping.tsf
# ANE_S11B_0001.tsf   
#-----------------------------

#==================================================================================================
#                                         DEFINE VARIABLES
#==================================================================================================
global TestStepNumber
global Result

#==================================================================================================
#                                            TEST CASES
#==================================================================================================


TestCase = "a"
Output ("")
Output ("===========================================================================================")
Output (" Test Case: a - SRD B ECL DB AIRCRAFT TYPE ATT 10                                          ")
Output ("===========================================================================================")
Output ("")
TestStepNumber = 0

#==================================================================================================
# Test Step    : a_1
# Description  : Check the AircraftType# attribute.
# Pass Criteria: Verify that AircraftType# attribute is set to #AircraftAN132#.
#               Where the enumeration value of AircraftAN132 is equal to 22#.
# ----------------------------------------------------------------------------------------
TestStepNumber = TestStepNumber + 1
TestStep = TestCase & "_" & TestStepNumber

Result = VerifyReadChkValue(tst_AircraftType,22.0,0,"AircraftType_"+TestStep )

# ----------------------------------------------------------------------------------------
#Test Step     : a_2
# Description  : Check the AutoDbLoad# attribute in the checklist database file.
# Pass Criteria: Verify that AutoDbLoad# attribute is set to True
# ----------------------------------------------------------------------------------------

TestStepNumber = TestStepNumber + 1
TestStep = Testcase & "_" & TestStepNumber

Result = VerifyReadChkValue(tst_AutoDbLoad,1,0,"AutoDbLoad_"+TestStep)

#----------------------------------------------------------------------------------------
# Test Step    : a_3
# Description  : Check the AutoPageEnabled# attribute.
# Pass Criteria: Verify that AutoPageEnabled# attribute is set to True
# ----------------------------------------------------------------------------------------
TestStepNumber = TestStepNumber + 1
TestStep = Testcase & "_" & TestStepNumber
global oput_AutoPageEnabled
oput_AutoPageEnabled = 0

Result = VerifyReadChkValue(tst_AutoPageEnabled,1,0,"AutoPageEnabled_"+TestStep)

#==================================================================================================
#                                       PRINT FINAL RESULTS
#==================================================================================================
ReportSummary()
