#-------------------------------------------------------------------------------------------------------------------------------------
#Author: Vishwas Krishna
#Purpose: Parse the tsf and cpp file and generate the Trace report (Trace.csv) that can be directly used to port to doors
#-------------------------------------------------------------------------------------------------------------------------------------

import os
import sys
import csv
import codecs
import time
import re

tesfiles = input("Drag and Drop the folder Containing tsf: ")
os.getcwd()
if os.path.exists('Trace.csv'): os.remove('Trace.csv')
with open("Trace.csv", 'a', newline='', encoding="utf-8") as traceout:
    w = csv.writer(traceout)
#Header Section in Trace.csv output file
    w.writerow(["Test Name", "Object ID", "File Name"])
    for root, dirs, files in os.walk(tesfiles):
        TestName = ''
        for file in files:
            if file.endswith(".tsf") or file.endswith(".cpp") or file.endswith(".TSF"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as testfiles:
                    for line in testfiles:
                        if file.endswith(".cpp"):
                            if line.__contains__('TestName:'):
                                TestName = line.split(':')[1]
                                TestName = TestName.split('"')[0]
                                TestName = TestName.rstrip()
                                TestName = TestName.lstrip()
                                print(TestName)
		            	#Identifying the Test Case, Test Procedure and Test Results
                        if line.__contains__('tio.OutputResult'):
                            sumname = testfiles.name
                            sumname = sumname.split('\\')[-1]
                            splitVal = re.findall('IR_TSC_\w+', line)
                            if (splitVal != []):
                                splitVal = "".join(splitVal)
                                print(splitVal)
				            #Writing the Data in format
                                outdata = TestName + ','+ str(splitVal) + ',' + sumname + '\n'
                                print(outdata)
                                traceout.write(outdata)
print("All Trace Extractions are Completed")
time.sleep(2)
exit(0)