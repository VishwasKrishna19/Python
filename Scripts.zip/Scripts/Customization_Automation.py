with open('C:/Users/h126313/Desktop/Python/Customisation/Struct.txt', 'r') as input:
    with open('C:/Users/h126313/Desktop/Python/Customisation/output.txt', 'w') as output:
        for line in input:
            elemetname = line.split('->')[1]
            elemetname = elemetname.split(' = ')[0]
            elemetname_declare = 'EDS::uint8_t ' + elemetname + '_Pixie'
            print(elemetname_declare)
            elementname_pixie = elemetname + '_Pixie'
            structname = line.split(' = ')[0]
            structname = structname.lstrip()
            #print(structname)
            final_data = elementname_pixie + '=' + structname + '\n'
            print(final_data)
            output.write(final_data)
            #structname = line.split('->')[0]
            #print(structname)