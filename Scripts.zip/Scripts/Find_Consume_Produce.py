#-------------------------------------------------------------------------------------------------------------------------------------
#Author: Saranya M
#Purpose: To Identify the Process,Testname,Parameter,Consume or Produce
#-------------------------------------------------------------------------------------------------------------------------------------

import os
import sys
import csv
import codecs
import time
import re

tesfiles = input("Drag and Drop the folder Containing tsf: ")
os.getcwd()
if os.path.exists('Details.csv'): os.remove('Details.csv')
with open("Details.csv", 'a', newline='', encoding="utf-8") as Tinkout:
    w = csv.writer(Tinkout)
    w.writerow(["Testname", "Process", "Parameter", "Consume_Produce"])
    Testname = ''
    for root, dirs, files in os.walk(tesfiles):
        for file in files:
            if file.endswith(".cpp"):
                with codecs.open(os.path.join(root, file), "r", encoding='UTF8', errors='ignore') as testfiles:
                    for line in testfiles:
                        if line.startswith("static"):
                            if line.__contains__('VerifySupport'):
                                Testname=line.split('("')[-1].split('"')[0]
                                print(Testname)
                        if line.startswith("process_handle_t"):
                            Process=line.split('process_handle_t')[-1].split('_')[0].lstrip()
                            print(Process)
                        if line.__contains__('Title'):
                            Parameter,Consume_Produce=line.split('Title:')[-1].split('"')[0].strip().split('Structure,')
                            print(Parameter)
                            print(Consume_Produce.lstrip())
                            outdata = Testname + ',' + Process + ',' + Parameter + ',' + Consume_Produce.lstrip() +  '\n'
                            Tinkout.write(outdata)
print("All Tink Details Extractions are Completed")
time.sleep(2)
exit(0)




