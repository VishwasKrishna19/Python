
import pandas as pd

s = pd.Series([1,2,3,'mango', '5.0'])

print(type(s))
print(s)
print(s[1])

#create series
s2 = pd.Series([1,2,3,4,5], index=['first', 'two', 'x', 'y', 'z'])
print(s2.iloc[3])
print(s2)
print(s2[2])
print('**************************************')
s3 = pd.Series([1,2,3,4,5,6])
print(s3[[1,3, 5]])