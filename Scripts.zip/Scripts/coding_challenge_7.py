# Question 31

### **Question:**
#>***Define a function which can print a dictionary where the keys are numbers between 1 and 20 (both included) and the values are square of keys.***
#----------------------
#### Hints:
#Use dict[key]=value pattern to put entry into a dictionary.Use ** operator to get power of a number.Use range() for loops.

dict = {}
def createdict():
    for i in range(21):
        key = i
        value = i**2
        dict[key] = value

createdict()
print(dict)
for c in dict.values():
    print(c)

def printDict():
    dict = {i:i**2 for i in range(1, 21)}
    #dict = {i: i**2 for i in range(1, 21)}
    print(dict.keys())      # print keys of a dictionary

printDict()

# Question 33
### **Question:**
#>***Define a function which can generate and print a list where the values are square of numbers between 1 and 20 (both included).***
#----------------------
#### Hints:
#Use ** operator to get power of a number.Use range() for loops.Use list.append() to add values into a list.
lis = []
def suqareval():
    for i in range(21):
        lis.append(i**2)
        firstfive = lis[:5]
        print(firstfive)

suqareval()
print(lis)

val = [i**2 for i in range(21)]
print(val)

# Question 38

### **Question:**

#>***With a given tuple (1,2,3,4,5,6,7,8,9,10), write a program to print the first half values in one line and the last half values in one line.***
#----------------------
#### Hints:
#>***Use [n1:n2] notation to get a slice from a tuple.***

tup = (1,2,3,4,5,6,7,8,9,10)
n = len(tup)
n1 = n/2
print(int(n1))
lis1= []
for i in range(int(n1)):
    val = tup[i]
    lis1.append(val)
lis2 = []

for i in range(int(n1), n):
    val2 = tup[i]
    lis2.append(val2)

print(lis1)
print(lis2)

# Question 41

### **Question:**

#>***Write a program which can map() to make a list whose elements are square of elements in [1,2,3,4,5,6,7,8,9,10].***
#----------------------
#### Hints:
#>***Use map() to generate a list.Use lambda to define anonymous functions.***

mylist = [1,2,3,4,5,6,7,8,9,10]
squarednum = map(lambda x: x*2, mylist)
print(list(squarednum))

mylist = [1,2,3,4,5,6,7,8,9,10]
squarednum = map(lambda x: x*2, filter(lambda x: x%2 == 0, mylist))
evenNumbers =map(lambda x: x**2, filter(lambda x: x%2 ==0, mylist))

print(list(evenNumbers))

# Question 43

### **Question:**
#>***Write a program which can filter() to make a list whose elements are even number between 1 and 20 (both included).***
#----------------------
#### Hints:
#>***Use filter() to filter elements of a list.Use lambda to define anonymous functions.***

evenum = filter(lambda x:x%2 == 0, range(21))
oddnum = filter(lambda x:x%2 == 1, range(21))
print(list(evenum))
print(list(oddnum))

# Question 44

### **Question:**
#>***Write a program which can map() to make a list whose elements are square of numbers between 1 and 20 (both included).***
#---------------
### Hints:
#>***Use map() to generate a list. Use lambda to define anonymous functions.***

def squ(x):
    return x*x

squarednum = list(map(squ, range(21)))
print(squarednum)
