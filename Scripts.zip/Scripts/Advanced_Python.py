
#Lambda function: small/ One operation Function

def check_string_in(child):
    return child in 'abc'

print(check_string_in('c'))

def square(n):
    return n*2

#functional programming
#map, reduce, filter ( function as a argument)

l = ['a', 'b', 'c', 'd']
s = 'abc'

#map is like transform a iterable
l2 = list(map(check_string_in, l))
print(l2)

l3 = [1, 2, 3, 4, 5]
print(list(map(square, l3)))
print(list(map(lambda n:n*2, l3)))

#############################################

#lambda [args] : a + b (use any operation apart from =)

a = lambda: True #lambda with no arguments that return True Always
b = lambda x:x**2 #lambda with single arguments
c = lambda x, y: x + y # lambda can take 2 arguments
d = lambda *x: sum(x)
e = lambda x=5: x**2
print(a())
print(b(5))
print(d(1,2,3,4,5))
print(e(6))

#map - transforming the iterables
# reduce -
# filter - Filter out iterables memners satisfies the special property

s = 'sajfhdsjghfdghfdhwueryrew'
out = list(filter(lambda a:a > 'i', s))
print(out)